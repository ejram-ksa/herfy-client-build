from __future__ import annotations
import hashlib, json, os, sys, tempfile, unittest, zipfile
from pathlib import Path
RUNTIME = Path(__file__).resolve().parents[1] / "runtime"
sys.path.insert(0,str(RUNTIME))

from services.updates.manifest_parser import parse_manifest
from services.updates.package_verifier import verify_downloaded_package
from services.updates.installer_runner import InstallerRunner
from services.updates.result_store import UpdateTransactionStore
from services.updates.models import UpdateTransaction

def payload(**changes):
    base={
      "schema_version":1,"version":"2.18.1","package_type":"patch",
      "filename":"HerfyTrackingSystem_2.18.1_patch.zip",
      "download_url":"https://herfy.online/update.zip",
      "sha256":"a"*64,"size_bytes":10,"mandatory":False,
      "publication_status":"published","minimum_supported_version":"2.18.0",
      "released_at":"2026-07-25T00:00:00+00:00"
    }
    base.update(changes)
    return base

class UpdateTests(unittest.TestCase):
    def test_manifest_strict_contract(self):
        self.assertEqual(parse_manifest(payload(),current_version="2.18.0").package_type,"patch")
        bad=[
          {"publication_status":"pending"},{"sha256":""},{"sha256":"x"*64},
          {"size_bytes":0},{"version":"2.18.0"},{"package_type":"msi"},
          {"filename":"../evil.zip"},{"download_url":"http://host/a.zip"},
          {"filename":"x.exe"},
        ]
        for change in bad:
            with self.subTest(change=change):
                with self.assertRaises((ValueError,TypeError)):
                    parse_manifest(payload(**change),current_version="2.18.0")

    def test_package_verification(self):
        with tempfile.TemporaryDirectory() as td:
            path=Path(td)/"x.zip"; path.write_bytes(b"abc")
            digest=hashlib.sha256(b"abc").hexdigest()
            m=parse_manifest(payload(filename="x.zip",sha256=digest,size_bytes=3),current_version="2.18.0")
            verify_downloaded_package(path,m)
            path.write_bytes(b"bad")
            with self.assertRaises(ValueError): verify_downloaded_package(path,m)

    def test_installer_runner_rejects_zip(self):
        m=parse_manifest(payload(),current_version="2.18.0")
        with self.assertRaises(ValueError):
            InstallerRunner().build_command(Path("x.zip"),m,install_root=Path("."),target_pid=1,transaction_id="t")

    def test_transaction_store_is_atomic_and_roundtrips(self):
        with tempfile.TemporaryDirectory() as td:
            s=UpdateTransactionStore(Path(td))
            tx=UpdateTransaction("t","2.18.0","2.18.1","patch","a"*64,"C:/App","detected","x","x",1,False,"u")
            s.save(tx)
            self.assertEqual(s.load(),tx)
            self.assertFalse(s.path.with_suffix(".json.tmp").exists())

if __name__=="__main__":
    unittest.main()
