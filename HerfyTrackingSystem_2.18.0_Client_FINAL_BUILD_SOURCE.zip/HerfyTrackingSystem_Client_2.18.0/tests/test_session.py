from __future__ import annotations
import json
import sys
import tempfile
import unittest
from datetime import datetime, timedelta
from pathlib import Path

RUNTIME = Path(__file__).resolve().parents[1] / "runtime"
sys.path.insert(0, str(RUNTIME))

from domain.session_models import LogoutReason, UserSession
from services.session.session_service import SessionService, SessionState
from services.session.session_store import SessionStore

class FakeProtector:
    def protect(self, plaintext: bytes) -> bytes:
        return b"x" + plaintext[::-1]
    def unprotect(self, ciphertext: bytes) -> bytes:
        if not ciphertext.startswith(b"x"):
            raise ValueError("invalid")
        return ciphertext[1:][::-1]

def make_session(*, remember: bool = True, user_id: str = "u1") -> UserSession:
    return UserSession(
        session_id="s1", user_id=user_id, username="18016",
        display_name="System User", roles=("system",),
        permissions=frozenset({"tracking.read"}), access_token="access-secret",
        refresh_token="refresh-secret", created_at=datetime.now().astimezone(),
        expires_at=datetime.now().astimezone() + timedelta(hours=1),
        remember_session=remember,
    )

class SessionTests(unittest.TestCase):
    def test_non_remembered_session_never_writes_tokens(self):
        with tempfile.TemporaryDirectory() as td:
            store = SessionStore(Path(td), FakeProtector())
            service = SessionService(store)
            service.establish(make_session(remember=False))
            self.assertFalse(store.secret_path.exists())
            self.assertFalse(store.metadata_path.exists())

    def test_remembered_session_uses_separate_encrypted_secret(self):
        with tempfile.TemporaryDirectory() as td:
            store = SessionStore(Path(td), FakeProtector())
            service = SessionService(store)
            service.establish(make_session())
            self.assertTrue(store.secret_path.exists())
            self.assertNotIn(b"access-secret", store.secret_path.read_bytes())
            self.assertNotIn("access-secret", store.metadata_path.read_text("utf-8"))
            loaded = store.load()
            self.assertEqual(loaded.user_id, "u1")

    def test_restore_requires_server_validator_and_user_match(self):
        with tempfile.TemporaryDirectory() as td:
            store = SessionStore(Path(td), FakeProtector())
            SessionService(store).establish(make_session())
            service = SessionService(store)
            restored = service.restore(lambda value: value)
            self.assertEqual(restored.user_id, "u1")
            service2 = SessionService(store)
            bad = service2.restore(lambda value: make_session(user_id="u2"))
            self.assertIsNone(bad)
            self.assertEqual(service2.state, SessionState.SIGNED_OUT)

    def test_manual_logout_clears_persistent_session(self):
        with tempfile.TemporaryDirectory() as td:
            store = SessionStore(Path(td), FakeProtector())
            service = SessionService(store)
            service.establish(make_session())
            calls = []
            service.logout(
                reason=LogoutReason.MANUAL,
                stop_user_tasks=lambda: calls.append("stop"),
                revoke_remote=lambda s: calls.append("revoke"),
                clear_user_cache=lambda u: calls.append("cache"),
                clear_user_notifications=lambda u: calls.append("notifications"),
            )
            self.assertIsNone(service.current)
            self.assertFalse(store.secret_path.exists())
            self.assertEqual(calls, ["stop", "revoke", "cache", "notifications"])

if __name__ == "__main__":
    unittest.main()
