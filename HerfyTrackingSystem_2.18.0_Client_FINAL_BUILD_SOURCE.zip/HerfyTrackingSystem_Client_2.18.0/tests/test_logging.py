from __future__ import annotations
import logging, os, sys, tempfile, unittest
from pathlib import Path
RUNTIME=Path(__file__).resolve().parents[1]/"runtime"
sys.path.insert(0,str(RUNTIME))

class LogTests(unittest.TestCase):
    def test_redaction_and_single_filename(self):
        import settings.logging_setup as ls
        with tempfile.TemporaryDirectory() as td:
            old=ls.log_path
            ls.log_path=lambda:Path(td)/"logs"/"herfy.log"
            try:
                ls.configure_root_logging()
                logging.getLogger("test").error("access_token=secret Authorization: BearerSecret password=hunter2")
                ls.flush_root_logging()
                files=list(Path(td).rglob("*"))
                actual=[p for p in files if p.is_file()]
                self.assertEqual([p.name for p in actual],["herfy.log"])
                text=actual[0].read_text("utf-8")
                self.assertNotIn("secret",text)
                self.assertNotIn("hunter2",text)
            finally:
                ls.log_path=old

if __name__=="__main__":
    unittest.main()
