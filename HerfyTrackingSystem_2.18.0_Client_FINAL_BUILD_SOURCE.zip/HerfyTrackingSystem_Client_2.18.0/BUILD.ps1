param([switch]$Clean)
Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"
$ProjectRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$BuildScript = Join-Path $ProjectRoot "build\tools\build\build.ps1"
if (-not (Test-Path -LiteralPath $BuildScript -PathType Leaf)) {
    throw "Missing build script: $BuildScript"
}
& powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File $BuildScript -Clean:$Clean
exit $LASTEXITCODE
