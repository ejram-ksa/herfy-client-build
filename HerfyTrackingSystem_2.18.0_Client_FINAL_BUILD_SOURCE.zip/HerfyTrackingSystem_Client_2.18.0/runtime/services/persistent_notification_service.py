from __future__ import annotations
from collections.abc import Callable
from domain.notification_models import AppNotification
from data.notification_repository import NotificationRepository

class PersistentNotificationService:
    def __init__(self, repository: NotificationRepository, current_user_id: Callable[[], str | None]) -> None:
        self._repository = repository
        self._current_user_id = current_user_id
        self._listeners: list[Callable[[int], None]] = []

    def subscribe_badge(self, callback: Callable[[int], None]) -> None:
        self._listeners.append(callback)
        callback(self.unread_count())

    def add(self, value: AppNotification) -> bool:
        self._require_current(value.user_id)
        inserted = self._repository.add(value)
        if inserted:
            self._emit()
        return inserted

    def list_current(self) -> list[AppNotification]:
        user_id = self._require_current()
        return self._repository.list_for_user(user_id)

    def unread_count(self) -> int:
        user_id = self._current_user_id()
        return self._repository.unread_count(user_id) if user_id else 0

    def badge_text(self) -> str:
        count = self.unread_count()
        if count <= 0:
            return ""
        return "99+" if count > 99 else str(count)

    def mark_read(self, notification_id: str) -> None:
        self._repository.mark_read(self._require_current(), notification_id)
        self._emit()

    def mark_all_read(self) -> None:
        self._repository.mark_all_read(self._require_current())
        self._emit()

    def delete(self, notification_id: str) -> None:
        self._repository.delete(self._require_current(), notification_id)
        self._emit()

    def clear_current_view(self) -> None:
        self._emit(force=0)

    def _require_current(self, expected: str | None = None) -> str:
        current = self._current_user_id()
        if not current:
            raise PermissionError("No authenticated user")
        if expected is not None and expected != current:
            raise PermissionError("Notification belongs to another user")
        return current

    def _emit(self, force: int | None = None) -> None:
        count = self.unread_count() if force is None else force
        for callback in tuple(self._listeners):
            callback(count)
