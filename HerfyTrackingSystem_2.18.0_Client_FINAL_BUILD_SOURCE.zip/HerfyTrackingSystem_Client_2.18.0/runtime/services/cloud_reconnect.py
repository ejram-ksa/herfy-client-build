from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class CloudReconnectFlowDecision:
    should_invalidate_cache: bool
    should_refresh_usage: bool
    should_emit_data_refresh: bool


class CloudReconnectFlowService:
    """Decide the one local-first action sequence after connectivity changes."""

    @staticmethod
    def evaluate(
        *,
        online: bool,
        previous_online: bool,
        session_active: bool,
        login_hydrate_pending: bool = False,
    ) -> CloudReconnectFlowDecision:
        reconnect = (
            bool(online) and (not bool(previous_online)) and bool(session_active)
        )
        hydrate_in_progress = bool(login_hydrate_pending)
        return CloudReconnectFlowDecision(
            should_invalidate_cache=reconnect,
            should_refresh_usage=reconnect and not hydrate_in_progress,
            should_emit_data_refresh=reconnect and not hydrate_in_progress,
        )
