from __future__ import annotations

import logging
from typing import Any

from core.booleans import parse_bool
from core.errors import SERVICE_OPERATION_EXCEPTIONS
from services.startup_registration import sync_startup_from_preferences

logger = logging.getLogger(__name__)


def _read_bool_setting(db_manager: Any, key: str, default: bool = False) -> bool:
    if db_manager is None:
        return bool(default)
    try:
        value = db_manager.get_setting(key, "True" if default else "False")
        return parse_bool(value, default)
    except SERVICE_OPERATION_EXCEPTIONS:
        logger.exception("Failed to read startup setting: %s", key)
        return bool(default)


def normalize_startup_preferences(
    db_manager: Any, *, persist: bool = False
) -> dict[str, bool]:
    """Read and normalize persisted startup preferences in one place."""
    normalized = {
        "enable_tray_background": True,
        "start_with_windows": _read_bool_setting(db_manager, "start_with_windows"),
        "tray_show_message_on_minimize": _read_bool_setting(
            db_manager, "tray_show_message_on_minimize"
        ),
    }
    if persist and db_manager is not None:
        try:
            for key, value in normalized.items():
                db_manager.set_setting(key, "True" if value else "False")
        except SERVICE_OPERATION_EXCEPTIONS:
            logger.exception("Failed to persist normalized startup preferences")
    return normalized


def sync_startup_from_settings(db_manager: Any) -> bool:
    if db_manager is None:
        return False
    try:
        return sync_startup_from_preferences(
            normalize_startup_preferences(db_manager, persist=True)
        )
    except SERVICE_OPERATION_EXCEPTIONS:
        logger.exception("Failed to sync startup settings")
        return False


def apply_startup_preferences(db_manager: Any) -> bool:
    return sync_startup_from_settings(db_manager)
