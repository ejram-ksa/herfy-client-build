from __future__ import annotations
import logging
import threading
from enum import Enum
from typing import Callable
from domain.session_models import LogoutReason, UserSession
from .session_store import SessionStore

logger = logging.getLogger(__name__)

class SessionState(str, Enum):
    SIGNED_OUT = "signed_out"
    RESTORING = "restoring_session"
    SIGNED_IN = "signed_in"
    LOGGING_OUT = "logging_out"

class SessionService:
    """Single source of truth for the authenticated user."""
    def __init__(self, store: SessionStore) -> None:
        self._store = store
        self._session: UserSession | None = None
        self._state = SessionState.SIGNED_OUT
        self._lock = threading.RLock()
        self._generation = 0

    @property
    def state(self) -> SessionState:
        return self._state

    @property
    def current(self) -> UserSession | None:
        with self._lock:
            return self._session

    @property
    def generation(self) -> int:
        return self._generation

    def establish(self, session: UserSession) -> None:
        with self._lock:
            self._generation += 1
            self._session = session
            self._state = SessionState.SIGNED_IN
            if session.remember_session:
                self._store.save(session)
            else:
                self._store.clear()
        logger.info("Authenticated session established user_id=%s", session.user_id)

    def restore(self, validator: Callable[[UserSession], UserSession]) -> UserSession | None:
        with self._lock:
            self._state = SessionState.RESTORING
        candidate = self._store.load()
        if candidate is None:
            self._state = SessionState.SIGNED_OUT
            return None
        try:
            verified = validator(candidate)
            if verified.user_id != candidate.user_id:
                raise PermissionError("Restored session user mismatch")
            self.establish(verified)
            return verified
        except (OSError, ValueError, PermissionError, RuntimeError):
            self._store.clear()
            with self._lock:
                self._session = None
                self._state = SessionState.SIGNED_OUT
                self._generation += 1
            logger.warning("Stored session rejected and removed", exc_info=True)
            return None

    def logout(
        self,
        *,
        reason: LogoutReason,
        stop_user_tasks: Callable[[], None],
        revoke_remote: Callable[[UserSession], None] | None = None,
        clear_user_cache: Callable[[str], None] | None = None,
        clear_user_notifications: Callable[[str], None] | None = None,
    ) -> None:
        with self._lock:
            self._state = SessionState.LOGGING_OUT
            session = self._session
            self._generation += 1
        stop_user_tasks()
        if session and revoke_remote:
            try:
                revoke_remote(session)
            except (OSError, RuntimeError, ValueError):
                logger.warning("Remote session revocation failed", exc_info=True)
        self._store.clear()
        if session and clear_user_cache:
            clear_user_cache(session.user_id)
        if session and clear_user_notifications:
            clear_user_notifications(session.user_id)
        with self._lock:
            self._session = None
            self._state = SessionState.SIGNED_OUT
        logger.info("Session cleared reason=%s", reason.value)
