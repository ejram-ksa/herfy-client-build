from __future__ import annotations
from services.session.session_service import SessionService

class AuthorizationService:
    def __init__(self, sessions: SessionService) -> None:
        self._sessions = sessions

    def has_permission(self, permission: str) -> bool:
        session = self._sessions.current
        return bool(session and str(permission) in session.permissions)

    def has_any_permission(self, *permissions: str) -> bool:
        return any(self.has_permission(value) for value in permissions)

    def has_role(self, role: str) -> bool:
        session = self._sessions.current
        return bool(session and str(role) in session.roles)

    def require_permission(self, permission: str) -> None:
        if not self.has_permission(permission):
            raise PermissionError(f"Permission required: {permission}")
