from __future__ import annotations
import base64
import ctypes
import json
import os
from dataclasses import asdict
from datetime import datetime
from pathlib import Path
from typing import Protocol, Any
from domain.session_models import UserSession

class SecretProtector(Protocol):
    def protect(self, plaintext: bytes) -> bytes: ...
    def unprotect(self, ciphertext: bytes) -> bytes: ...

class DPAPISecretProtector:
    """Windows DPAPI bound to the current Windows user."""
    class DATA_BLOB(ctypes.Structure):
        _fields_ = [("cbData", ctypes.c_uint32), ("pbData", ctypes.POINTER(ctypes.c_ubyte))]

    def _blob(self, data: bytes):
        buffer = ctypes.create_string_buffer(data)
        blob = self.DATA_BLOB(len(data), ctypes.cast(buffer, ctypes.POINTER(ctypes.c_ubyte)))
        return blob, buffer

    def protect(self, plaintext: bytes) -> bytes:
        if os.name != "nt":
            raise OSError("DPAPI is available only on Windows")
        in_blob, keep = self._blob(plaintext)
        out_blob = self.DATA_BLOB()
        if not ctypes.windll.crypt32.CryptProtectData(
            ctypes.byref(in_blob), "Herfy Tracking System", None, None, None, 0x1,
            ctypes.byref(out_blob)
        ):
            raise ctypes.WinError()
        try:
            return ctypes.string_at(out_blob.pbData, out_blob.cbData)
        finally:
            ctypes.windll.kernel32.LocalFree(out_blob.pbData)

    def unprotect(self, ciphertext: bytes) -> bytes:
        if os.name != "nt":
            raise OSError("DPAPI is available only on Windows")
        in_blob, keep = self._blob(ciphertext)
        out_blob = self.DATA_BLOB()
        if not ctypes.windll.crypt32.CryptUnprotectData(
            ctypes.byref(in_blob), None, None, None, None, 0x1, ctypes.byref(out_blob)
        ):
            raise ctypes.WinError()
        try:
            return ctypes.string_at(out_blob.pbData, out_blob.cbData)
        finally:
            ctypes.windll.kernel32.LocalFree(out_blob.pbData)

class SessionStore:
    def __init__(self, root: Path, protector: SecretProtector | None = None) -> None:
        self.root = Path(root)
        self.metadata_path = self.root / "session" / "metadata.json"
        self.secret_path = self.root / "session" / "tokens.bin"
        self.protector = protector or DPAPISecretProtector()

    def save(self, session: UserSession) -> None:
        if not session.remember_session:
            self.clear()
            return
        self.metadata_path.parent.mkdir(parents=True, exist_ok=True)
        metadata = {
            "session_id": session.session_id,
            "user_id": session.user_id,
            "username": session.username,
            "display_name": session.display_name,
            "roles": list(session.roles),
            "permissions": sorted(session.permissions),
            "created_at": session.created_at.isoformat(),
            "expires_at": session.expires_at.isoformat() if session.expires_at else None,
            "remember_session": True,
            "last_login_at": datetime.now().astimezone().isoformat(),
        }
        secret = json.dumps({
            "access_token": session.access_token,
            "refresh_token": session.refresh_token,
        }, separators=(",", ":")).encode("utf-8")
        encrypted = self.protector.protect(secret)
        self._atomic_write(self.metadata_path, json.dumps(metadata, ensure_ascii=False).encode("utf-8"))
        self._atomic_write(self.secret_path, base64.b64encode(encrypted))

    def load(self) -> UserSession | None:
        if not self.metadata_path.is_file() or not self.secret_path.is_file():
            return None
        metadata = json.loads(self.metadata_path.read_text(encoding="utf-8"))
        encrypted = base64.b64decode(self.secret_path.read_bytes(), validate=True)
        secret = json.loads(self.protector.unprotect(encrypted).decode("utf-8"))
        return UserSession(
            session_id=str(metadata["session_id"]),
            user_id=str(metadata["user_id"]),
            username=str(metadata["username"]),
            display_name=str(metadata.get("display_name") or ""),
            roles=tuple(str(v) for v in metadata.get("roles", [])),
            permissions=frozenset(str(v) for v in metadata.get("permissions", [])),
            access_token=str(secret["access_token"]),
            refresh_token=secret.get("refresh_token"),
            created_at=datetime.fromisoformat(metadata["created_at"]),
            expires_at=datetime.fromisoformat(metadata["expires_at"]) if metadata.get("expires_at") else None,
            remember_session=True,
        )

    def clear(self) -> None:
        for path in (self.secret_path, self.metadata_path):
            path.unlink(missing_ok=True)
        parent = self.metadata_path.parent
        try:
            parent.rmdir()
        except OSError:
            pass

    @staticmethod
    def _atomic_write(path: Path, data: bytes) -> None:
        path.parent.mkdir(parents=True, exist_ok=True)
        temp = path.with_suffix(path.suffix + ".tmp")
        with open(temp, "wb") as handle:
            handle.write(data)
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temp, path)
