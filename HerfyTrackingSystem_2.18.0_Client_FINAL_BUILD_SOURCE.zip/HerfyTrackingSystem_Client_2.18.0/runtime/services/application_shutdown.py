from __future__ import annotations
import logging
from collections.abc import Callable
from settings.logging_setup import flush_root_logging

logger = logging.getLogger(__name__)

class ApplicationShutdown:
    def __init__(self) -> None:
        self._steps: list[tuple[str, Callable[[], None]]] = []
        self._blocked = False

    @property
    def operations_blocked(self) -> bool:
        return self._blocked

    def add_step(self, name: str, callback: Callable[[], None]) -> None:
        self._steps.append((name, callback))

    def prepare_update(self, launch_agent: Callable[[], None]) -> None:
        self._blocked = True
        for name, callback in self._steps:
            try:
                callback()
            except (OSError, RuntimeError, ValueError):
                logger.exception("Shutdown step failed: %s", name)
                raise
        flush_root_logging()
        launch_agent()
        logger.info("Update agent started; application may exit")
