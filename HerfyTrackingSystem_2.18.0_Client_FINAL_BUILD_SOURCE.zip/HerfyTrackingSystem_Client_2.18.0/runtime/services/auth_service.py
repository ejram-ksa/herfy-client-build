from __future__ import annotations
import re

# ruff: noqa: E402

import logging
from dataclasses import dataclass
from collections.abc import Mapping
from typing import Any

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class LoginRemoteNotice:
    message: str
    severity: str


class LoginRemoteNoticeService:

    @staticmethod
    def evaluate(settings: Mapping[str, Any] | None) -> LoginRemoteNotice:
        data = dict(settings or {})
        maintenance_enabled = (
            str(data.get("remote_maintenance_enabled", "False")) == "True"
        )
        maintenance_message = str(
            data.get("remote_maintenance_message", "") or ""
        ).strip()
        login_message = str(data.get("remote_login_message", "") or "").strip()
        banner_message = str(data.get("remote_startup_banner", "") or "").strip()
        banner_severity = (
            str(data.get("remote_startup_banner_severity", "info") or "info").strip()
            or "info"
        )
        if maintenance_enabled and maintenance_message:
            return LoginRemoteNotice(message=maintenance_message, severity="warning")
        if login_message:
            return LoginRemoteNotice(message=login_message, severity="info")
        if banner_message:
            return LoginRemoteNotice(message=banner_message, severity=banner_severity)
        return LoginRemoteNotice(message="", severity="neutral")


import logging
from core.errors import SERVICE_OPERATION_EXCEPTIONS
from settings.messages import canonical_error_message
from domain.user import AuthSession
from domain.access_policy import PermissionContext
from services.device_identity import get_or_create_device_id

logger = logging.getLogger(__name__)


class AuthError(RuntimeError):
    """Authentication failure raised by AuthService."""


def _flatten_auth_payload(
    data: dict[str, Any], *, fallback_identifier: str = ""
) -> dict[str, Any]:
    payload = dict(data or {})
    nested_user = payload.get("user") if isinstance(payload.get("user"), dict) else {}
    merged = {**nested_user, **payload}
    for key in ("access_token", "token", "token_type", "refresh_token", "expires_in"):
        if key in payload:
            merged[key] = payload[key]
    session_payload = payload.get("session")
    if isinstance(session_payload, dict):
        merged["session_id"] = str(session_payload.get("session_id") or "")
        merged["device_id"] = str(session_payload.get("device_id") or "")
        merged["remember_me"] = bool(session_payload.get("remember_me", False))
    sync_payload = payload.get("sync")
    if isinstance(sync_payload, dict):
        merged["sync_cursor"] = int(sync_payload.get("cursor") or 0)
    if fallback_identifier and not merged.get("username"):
        merged["username"] = str(fallback_identifier).strip()
    return merged


def _unwrap_auth_response(data: dict[str, Any]) -> dict[str, Any]:
    payload = dict(data or {})
    for key in ("data", "result", "session", "auth"):
        nested = payload.get(key)
        if isinstance(nested, dict) and (
            nested.get("access_token")
            or nested.get("token")
            or nested.get("user")
            or nested.get("session")
        ):
            merged = dict(nested)
            for token_key in (
                "access_token",
                "token",
                "token_type",
                "refresh_token",
                "expires_in",
            ):
                if token_key in payload and token_key not in merged:
                    merged[token_key] = payload[token_key]
            return merged
    return payload


def _response_json(response: Any) -> dict[str, Any]:
    try:
        data = response.json()
    except SERVICE_OPERATION_EXCEPTIONS as exc:
        raise AuthError(canonical_error_message("malformed_response")) from exc
    return data if isinstance(data, dict) else {}


def _normalized_expires_in(value: Any) -> int:
    try:
        seconds = int(value)
    except (TypeError, ValueError):
        return 3600
    if seconds <= 0:
        return 3600
    return min(seconds, 7 * 24 * 60 * 60)


def _canonical_login_request(
    identifier: str,
    password: str,
    *,
    remember_me: bool,
    device_id: str,
) -> dict[str, Any]:
    """Build the single server-supported login payload.

    The authoritative API accepts JSON with ``username`` and ``password``.
    Sending several alternative payloads can trigger account lockout counters
    and can turn one valid sign-in attempt into a misleading 403 response.

    Branch user input is normalized client-side as a compatibility safety net
    for older servers: h1074 -> H1074. The server remains the authority.
    """
    user = str(identifier or "").strip()
    if re.fullmatch(r"[Hh][0-9]+", user):
        user = user.upper()
    secret = str(password or "")
    return {
        "json": {
            "username": user,
            "password": secret,
            "remember_me": bool(remember_me),
            "device_id": str(device_id or "").strip(),
        },
        "headers": {
            "Accept": "application/json",
            "Content-Type": "application/json",
            "Cache-Control": "no-store",
        },
        "max_retries": 0,
    }


def _parse_auth_session(data: dict, identifier: str = "") -> AuthSession:
    data = _unwrap_auth_response(dict(data or {}))
    token = str(data.get("access_token") or data.get("token") or "").strip()
    if not token:
        raise AuthError(canonical_error_message("invalid_response"))
    hydrated = _flatten_auth_payload(dict(data or {}), fallback_identifier=identifier)
    permission_context = PermissionContext.from_payload(
        hydrated, active_branch=str(hydrated.get("active_branch") or "").strip()
    )
    branches = list(permission_context.scope.branches or [])
    active_branch = str(
        permission_context.active_branch or (branches[0] if len(branches) == 1 else "")
    ).strip()
    role = permission_context.role
    # Do not write usernames, branch scope, or token-derived identity to logs.
    logger.info("Authentication authority accepted by server")
    return AuthSession(
        id_token=token,
        uid=str(
            hydrated.get("username")
            or hydrated.get("uid")
            or permission_context.user_id
            or permission_context.username
            or identifier
            or ""
        ).strip(),
        role=role,
        branches=branches,
        active_branch=active_branch,
        token_type=str(hydrated.get("token_type") or "bearer"),
        refresh_token=str(hydrated.get("refresh_token") or ""),
        expires_in=_normalized_expires_in(hydrated.get("expires_in")),
        session_id=str(hydrated.get("session_id") or "").strip(),
        device_id=str(hydrated.get("device_id") or "").strip(),
        remember_me=bool(hydrated.get("remember_me", False)),
        sync_cursor=int(hydrated.get("sync_cursor") or 0),
        permission_context=permission_context,
    )


import logging
from dataclasses import dataclass
from domain.user import UserProfile

logger = logging.getLogger(__name__)


@dataclass(frozen=True)
class SessionRestoreCandidate:
    refresh_token: str = ""
    username: str = ""
    device_id: str = ""


def build_restore_candidate(snapshot: Any | None) -> SessionRestoreCandidate | None:
    """Create a candidate only when the real server can re-authorize it.

    Stored access tokens, cached roles, branches, and permissions are never
    authentication authority. A remembered session requires a refresh token
    and must be accepted by the server before the application opens.
    """
    if snapshot is None or not bool(getattr(snapshot, "remember", False)):
        return None
    refresh_token = str(getattr(snapshot, "refresh_token", "") or "").strip()
    if not refresh_token:
        return None
    return SessionRestoreCandidate(
        refresh_token=refresh_token,
        username=str(getattr(snapshot, "username", "") or "").strip(),
        device_id=str(getattr(snapshot, "device_id", "") or "").strip()
        or get_or_create_device_id(),
    )


import logging

logger = logging.getLogger(__name__)


def load_user_profile_from_session(
    session: AuthSession, fallback_username: str = ""
) -> UserProfile:
    """Build a profile only from permission data returned by the server."""
    del fallback_username
    ctx = getattr(session, "permission_context", None)
    if not isinstance(ctx, PermissionContext):
        raise AuthError(canonical_error_message("profile_missing"))
    if not (str(ctx.username or "").strip() or str(ctx.user_id or "").strip()):
        raise AuthError(canonical_error_message("profile_missing"))
    if (
        str(getattr(ctx, "authority_source", "") or "").strip()
        != "postgresql.role_permissions"
    ):
        raise AuthError(canonical_error_message("profile_missing"))
    if not bool(getattr(ctx, "is_active", True)):
        raise AuthError(canonical_error_message("account_inactive"))
    return UserProfile.from_permission_context(ctx)


import logging
from settings.config import get_http_timeout_seconds, get_request_verify_ssl
from settings.messages import user_error_message
from core.errors import RemoteRequestError, SessionExpiredError
from application.ports import api_request
from remote.http import temporary_http_session

logger = logging.getLogger(__name__)
_LOGIN_ENDPOINT = "/auth/login"
_REFRESH_ENDPOINT = "/auth/refresh"
_PROFILE_ENDPOINT = "/auth/me"
_LOGOUT_ENDPOINT = "/auth/logout"
_LOGIN_INACTIVE_MARKERS = (
    "inactive",
    "disabled",
    "deactivated",
    "suspended",
    "blocked",
)
_LOGIN_INVALID_CREDENTIAL_MARKERS = (
    "invalid username or password",
    "incorrect username or password",
    "bad credentials",
    "invalid credentials",
)


def _login_rejection_message(error: BaseException) -> str:
    text = str(error or "").strip()
    lowered = text.lower()
    if any(marker in lowered for marker in _LOGIN_INVALID_CREDENTIAL_MARKERS):
        return canonical_error_message("invalid_credentials")
    if any(marker in lowered for marker in _LOGIN_INACTIVE_MARKERS):
        return canonical_error_message("account_inactive")
    return canonical_error_message("login_access_denied")


def _merge_authenticated_profile(
    auth_payload: dict[str, Any],
    profile_payload: dict[str, Any],
) -> dict[str, Any]:
    """Merge /auth/me authority into the token response without losing tokens."""
    auth_data = _unwrap_auth_response(dict(auth_payload or {}))
    profile_data = _unwrap_auth_response(dict(profile_payload or {}))
    nested_user = (
        profile_data.get("user") if isinstance(profile_data.get("user"), dict) else {}
    )
    merged = dict(auth_data)
    merged.update(nested_user)
    merged.update(profile_data)
    for key in (
        "access_token",
        "token",
        "token_type",
        "refresh_token",
        "expires_in",
    ):
        if auth_data.get(key) not in (None, ""):
            merged[key] = auth_data[key]
    return merged


def _contains_server_authority(payload: dict[str, Any]) -> bool:
    """Return True only for explicit identity and authorization from the API."""
    data = _unwrap_auth_response(dict(payload or {}))
    nested_user = data.get("user") if isinstance(data.get("user"), dict) else {}
    merged = {**nested_user, **data}
    identity = str(
        merged.get("user_id")
        or merged.get("uid")
        or merged.get("username")
        or merged.get("id")
        or ""
    ).strip()
    has_authorization = any(
        key in merged
        for key in (
            "role",
            "permissions",
            "scope",
            "branches",
            "branch_scope",
            "assigned_branch_ids",
        )
    )
    return bool(identity and has_authorization)


def _hydrate_authenticated_profile(
    auth_payload: dict[str, Any],
    *,
    session: Any,
) -> dict[str, Any]:
    """Use authorization returned by the real server, never local JWT decoding."""
    if _contains_server_authority(auth_payload):
        logger.info("Authenticated authority supplied by login/refresh response")
        return auth_payload
    token = str(
        auth_payload.get("access_token") or auth_payload.get("token") or ""
    ).strip()
    if not token:
        raise AuthError(canonical_error_message("invalid_response"))
    headers = {
        "Authorization": f"Bearer {token}",
        "Accept": "application/json",
        "Cache-Control": "no-store",
    }
    try:
        response = api_request(
            "GET",
            _PROFILE_ENDPOINT,
            session=session,
            timeout=get_http_timeout_seconds(),
            verify=get_request_verify_ssl(),
            headers=headers,
            max_retries=0,
        )
        try:
            profile_payload = _response_json(response)
        finally:
            response.close()
        if not _contains_server_authority(profile_payload):
            raise AuthError(canonical_error_message("profile_missing"))
        logger.info("Authenticated profile hydrated from canonical endpoint")
        return _merge_authenticated_profile(auth_payload, profile_payload)
    except SessionExpiredError as exc:
        raise AuthError(canonical_error_message("invalid_credentials")) from exc
    except RemoteRequestError as exc:
        raise AuthError(user_error_message(exc, context="login")) from exc
    except AuthError:
        raise
    except SERVICE_OPERATION_EXCEPTIONS as exc:
        raise AuthError(user_error_message(exc, context="login")) from exc


def _post_login(
    identifier: str,
    password: str,
    *,
    remember_me: bool,
    device_id: str,
) -> dict[str, Any]:
    request_kwargs = _canonical_login_request(
        identifier,
        password,
        remember_me=remember_me,
        device_id=device_id,
    )

    # A dedicated session prevents cookies or headers from a previous account
    # from contaminating the public authentication request.
    with temporary_http_session() as session:
        try:
            response = api_request(
                "POST",
                _LOGIN_ENDPOINT,
                session=session,
                timeout=get_http_timeout_seconds(),
                verify=get_request_verify_ssl(),
                **request_kwargs,
            )
            try:
                auth_payload = _unwrap_auth_response(_response_json(response))
            finally:
                response.close()
            logger.info("Login accepted through the canonical endpoint")
            return _hydrate_authenticated_profile(auth_payload, session=session)
        except SessionExpiredError as exc:
            raise AuthError(canonical_error_message("invalid_credentials")) from exc
        except RemoteRequestError as exc:
            status_code = getattr(exc, "status_code", None)
            if status_code == 401:
                logger.error("Login rejected by server status=401")
                raise AuthError(canonical_error_message("invalid_credentials")) from exc
            if status_code == 403:
                logger.error("Login access rejected by server status=403")
                raise AuthError(_login_rejection_message(exc)) from exc
            raise AuthError(user_error_message(exc, context="login")) from exc
        except SERVICE_OPERATION_EXCEPTIONS as exc:
            raise AuthError(user_error_message(exc, context="login")) from exc


def _post_refresh(refresh_token: str, *, device_id: str) -> dict[str, Any]:
    """Refresh the token and permissions against the production API."""
    secret = str(refresh_token or "").strip()
    if not secret:
        raise AuthError(canonical_error_message("invalid_response"))
    request_kwargs = {
        "json": {
            "refresh_token": secret,
            "device_id": str(device_id or "").strip(),
        },
        "headers": {
            "Accept": "application/json",
            "Content-Type": "application/json",
            "Cache-Control": "no-store",
        },
        "max_retries": 0,
    }
    with temporary_http_session() as session:
        try:
            response = api_request(
                "POST",
                _REFRESH_ENDPOINT,
                session=session,
                timeout=get_http_timeout_seconds(),
                verify=get_request_verify_ssl(),
                **request_kwargs,
            )
            try:
                auth_payload = _unwrap_auth_response(_response_json(response))
            finally:
                response.close()
            logger.info("Session refreshed through the canonical endpoint")
            return _hydrate_authenticated_profile(auth_payload, session=session)
        except SessionExpiredError as exc:
            raise AuthError(canonical_error_message("invalid_credentials")) from exc
        except RemoteRequestError as exc:
            if getattr(exc, "status_code", None) in {401, 403}:
                raise AuthError(canonical_error_message("invalid_credentials")) from exc
            raise AuthError(user_error_message(exc, context="auth")) from exc
        except SERVICE_OPERATION_EXCEPTIONS as exc:
            raise AuthError(user_error_message(exc, context="auth")) from exc


def sign_in_with_identifier_password(
    identifier: str,
    password: str,
    *,
    remember_me: bool = False,
    device_id: str = "",
) -> AuthSession:
    logger.info("Attempting server login")
    resolved_device_id = str(device_id or "").strip() or get_or_create_device_id()
    data = _post_login(
        identifier,
        password,
        remember_me=bool(remember_me),
        device_id=resolved_device_id,
    )
    session = _parse_auth_session(data, identifier=identifier)
    if not session.device_id:
        session.device_id = resolved_device_id
    return session


def refresh_session(
    refresh_token: str,
    identifier: str = "",
    *,
    device_id: str = "",
) -> AuthSession:
    if not str(refresh_token or "").strip():
        raise AuthError(canonical_error_message("invalid_response"))
    resolved_device_id = str(device_id or "").strip() or get_or_create_device_id()
    data = _post_refresh(
        str(refresh_token).strip(),
        device_id=resolved_device_id,
    )
    session = _parse_auth_session(data, identifier=identifier)
    if not session.device_id:
        session.device_id = resolved_device_id
    return session


def revoke_remote_session(session: AuthSession | None) -> bool:
    """Best-effort server revocation. Call from a worker, never the UI thread."""
    token = str(getattr(session, "id_token", "") or "").strip()
    if not token:
        return False
    headers = {
        "Authorization": f"Bearer {token}",
        "Accept": "application/json",
        "Content-Type": "application/json",
        "Cache-Control": "no-store",
    }
    try:
        response = api_request(
            "POST",
            _LOGOUT_ENDPOINT,
            timeout=get_http_timeout_seconds(),
            verify=get_request_verify_ssl(),
            headers=headers,
            json={
                "session_id": str(getattr(session, "session_id", "") or ""),
                "refresh_token": str(getattr(session, "refresh_token", "") or ""),
            },
            max_retries=0,
        )
        response.close()
        return True
    except (RemoteRequestError, SessionExpiredError, *SERVICE_OPERATION_EXCEPTIONS) as exc:
        logger.info("Server logout could not be confirmed: %s", type(exc).__name__)
    return False


def change_own_password(
    api_client: Any, old_password: str, new_password: str
) -> dict[str, Any]:
    if api_client is None:
        raise AuthError("Cloud service is not available.")
    try:
        result = api_client.change_own_password(old_password, new_password)
    except SessionExpiredError as exc:
        raise AuthError(user_error_message(exc, context="auth")) from exc
    except RemoteRequestError as exc:
        raise AuthError(user_error_message(exc, context="auth")) from exc
    except SERVICE_OPERATION_EXCEPTIONS as exc:
        raise AuthError(user_error_message(exc, context="auth")) from exc
    return dict(result or {})
