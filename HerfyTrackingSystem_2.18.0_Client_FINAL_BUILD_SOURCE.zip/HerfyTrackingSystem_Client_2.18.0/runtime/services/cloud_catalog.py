from __future__ import annotations

from typing import Any

from core.booleans import parse_bool
from core.objects import normalize_int


def profile_to_cloud_user_payload(profile: Any) -> dict[str, Any]:
    """Project an authenticated profile into the API client's authority shape."""
    if profile is None:
        return {}
    if hasattr(profile, "to_cloud_user_payload"):
        return profile.to_cloud_user_payload()
    context = getattr(profile, "permission_context", None)
    scope = getattr(context, "scope", None)
    return {
        "username": getattr(profile, "username", ""),
        "role": getattr(profile, "role", ""),
        "active_branch": getattr(profile, "active_branch", ""),
        "uid": getattr(profile, "uid", ""),
        "permissions": list(getattr(context, "permissions", []) or []),
        "scope": {
            "regions": list(getattr(scope, "regions", []) or []),
            "areas": list(getattr(scope, "areas", []) or []),
            "branches": list(getattr(scope, "branches", []) or []),
            "all_regions": bool(getattr(scope, "all_regions", False)),
            "all_areas": bool(getattr(scope, "all_areas", False)),
            "all_branches": bool(getattr(scope, "all_branches", False)),
        },
        "area_id": getattr(profile, "area_id", ""),
        "operations_consultant_id": getattr(profile, "operations_consultant_id", ""),
        "assigned_branch_ids": list(getattr(profile, "assigned_branch_ids", []) or []),
        "must_change_password": bool(getattr(profile, "must_change_password", False)),
        "is_active": bool(getattr(profile, "is_active", True)),
        "temporary_manager": bool(getattr(profile, "temporary_manager", False)),
        "permission_source": str(getattr(context, "authority_source", "") or ""),
        "authority_revision": int(getattr(context, "authority_revision", 0) or 0),
    }


def apply_remote_catalog_snapshot(
    db_manager: Any, snapshot: dict[str, Any] | None
) -> dict[str, str]:
    """Persist an already-received catalog snapshot without issuing network I/O."""
    payload = snapshot if isinstance(snapshot, dict) else {}
    if not payload:
        return {}
    rows: list[dict[str, Any]] = []
    normalized: dict[str, str] = {}
    for material_id, value in payload.items():
        material_text = str(material_id).strip()
        item = dict(value) if isinstance(value, dict) else {}
        material_text = str(
            item.get("material_number") or item.get("material") or material_text
        ).strip()
        raw_name = item.get("name") or item.get("material_name")
        if raw_name is None and not isinstance(value, dict):
            raw_name = value
        name_text = str(raw_name or "").strip()
        if not material_text:
            continue
        row = {
            "material_number": material_text,
            "name": name_text or material_text,
            "revision": normalize_int(item.get("revision"), 0),
            "is_active": parse_bool(
                item.get("is_active", item.get("active", True)), True
            ),
        }
        rows.append(row)
        if row["is_active"]:
            normalized[material_text] = row["name"]

    merge = getattr(db_manager, "merge_remote_stored_products", None)
    if callable(merge):
        merge(rows)
        return normalized

    # Compatibility for deliberately minimal repository doubles.  Production
    # repositories expose merge_remote_stored_products and remain the owner of
    # the local catalog schema.
    connection = db_manager.connection
    cursor = connection.cursor()
    for row in rows:
        cursor.execute(
            """
            INSERT INTO stored_products(material_number,name,revision,is_active)
            VALUES(?,?,?,?)
            ON CONFLICT(material_number) DO UPDATE SET
                name=excluded.name,
                revision=MAX(stored_products.revision, excluded.revision),
                is_active=excluded.is_active
            """,
            (
                row["material_number"],
                row["name"],
                row["revision"],
                int(row["is_active"]),
            ),
        )
    connection.commit()
    return normalized
