from __future__ import annotations
import re
from datetime import datetime
from pathlib import PurePath
from urllib.parse import urlsplit
from domain.versions import parse_semver
from .models import UpdateManifest

_SHA256 = re.compile(r"^[0-9a-fA-F]{64}$")
_ALLOWED = {"patch": ".zip", "installer": ".exe"}

def parse_manifest(payload: dict, *, current_version: str, production: bool = True) -> UpdateManifest:
    if not isinstance(payload, dict):
        raise ValueError("Manifest must be an object")
    if int(payload.get("schema_version", 0)) != 1:
        raise ValueError("Unsupported manifest schema")
    status = str(payload.get("publication_status") or "")
    if status != "published":
        raise ValueError("Update is not published")
    package_type = str(payload.get("package_type") or "")
    if package_type not in _ALLOWED:
        raise ValueError("Unsupported package type")
    filename = str(payload.get("filename") or "")
    if not filename or PurePath(filename).name != filename or ".." in PurePath(filename).parts:
        raise ValueError("Unsafe update filename")
    if not filename.lower().endswith(_ALLOWED[package_type]):
        raise ValueError("Package extension does not match type")
    sha256 = str(payload.get("sha256") or "")
    if not _SHA256.fullmatch(sha256):
        raise ValueError("Invalid SHA-256")
    size_bytes = int(payload.get("size_bytes", 0))
    if size_bytes <= 0:
        raise ValueError("Invalid package size")
    version = str(payload.get("version") or "")
    if parse_semver(version) <= parse_semver(current_version):
        raise ValueError("Update version must be newer")
    download_url = str(payload.get("download_url") or "")
    parts = urlsplit(download_url)
    if production and parts.scheme.lower() != "https":
        raise ValueError("Production updates require HTTPS")
    if parts.scheme.lower() not in {"http", "https"} or not parts.netloc:
        raise ValueError("Invalid update URL")
    released_at = datetime.fromisoformat(str(payload.get("released_at") or "").replace("Z", "+00:00"))
    return UpdateManifest(
        schema_version=1,
        version=version,
        package_type=package_type,  # type: ignore[arg-type]
        filename=filename,
        download_url=download_url,
        sha256=sha256.lower(),
        size_bytes=size_bytes,
        mandatory=bool(payload.get("mandatory", False)),
        publication_status=status,
        minimum_supported_version=str(payload.get("minimum_supported_version") or ""),
        released_at=released_at,
    )
