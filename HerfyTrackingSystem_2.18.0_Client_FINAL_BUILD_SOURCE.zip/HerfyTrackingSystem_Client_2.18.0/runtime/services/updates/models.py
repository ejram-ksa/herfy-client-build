from __future__ import annotations
from dataclasses import dataclass, replace
from datetime import datetime
from pathlib import Path
from typing import Literal

PackageType = Literal["patch", "installer"]
TransactionStage = Literal[
    "detected","downloading","downloaded","verified","shutdown_requested",
    "waiting_for_exit","backing_up","installing","verifying","restart_requested",
    "health_check_pending","completed","rollback_started","rolled_back","failed"
]

@dataclass(frozen=True, slots=True)
class UpdateManifest:
    schema_version: int
    version: str
    package_type: PackageType
    filename: str
    download_url: str
    sha256: str
    size_bytes: int
    mandatory: bool
    publication_status: str
    minimum_supported_version: str
    released_at: datetime

@dataclass(frozen=True, slots=True)
class UpdateTransaction:
    transaction_id: str
    from_version: str
    to_version: str
    package_type: PackageType
    package_sha256: str
    install_root: str
    stage: TransactionStage
    started_at: str
    updated_at: str
    attempt: int
    rollback_attempted: bool
    user_id: str

    def advance(self, stage: TransactionStage) -> "UpdateTransaction":
        return replace(self, stage=stage, updated_at=datetime.now().astimezone().isoformat())
