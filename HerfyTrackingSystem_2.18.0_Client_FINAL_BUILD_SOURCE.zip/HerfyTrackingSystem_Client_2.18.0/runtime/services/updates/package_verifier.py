from __future__ import annotations
import hashlib
from pathlib import Path
from .models import UpdateManifest

def verify_downloaded_package(path: Path, manifest: UpdateManifest) -> None:
    path = Path(path)
    if not path.is_file():
        raise FileNotFoundError(path)
    if path.name != manifest.filename:
        raise ValueError("Downloaded filename mismatch")
    if path.stat().st_size != manifest.size_bytes:
        raise ValueError("Downloaded size mismatch")
    digest = hashlib.sha256()
    with open(path, "rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(block)
    if digest.hexdigest().lower() != manifest.sha256:
        raise ValueError("Downloaded SHA-256 mismatch")
