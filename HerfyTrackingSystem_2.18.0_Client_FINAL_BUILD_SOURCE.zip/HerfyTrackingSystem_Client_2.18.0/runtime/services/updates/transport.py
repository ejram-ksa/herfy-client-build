from __future__ import annotations
from pathlib import Path
from urllib.request import Request, urlopen

class UpdateTransport:
    def download(self, url: str, destination: Path, *, timeout: float = 60.0) -> None:
        destination.parent.mkdir(parents=True, exist_ok=True)
        request = Request(url, headers={"User-Agent": "HerfyTrackingSystem-Updater"})
        temp = destination.with_suffix(destination.suffix + ".part")
        with urlopen(request, timeout=timeout) as response, open(temp, "wb") as target:
            while True:
                block = response.read(1024 * 1024)
                if not block:
                    break
                target.write(block)
            target.flush()
        temp.replace(destination)
