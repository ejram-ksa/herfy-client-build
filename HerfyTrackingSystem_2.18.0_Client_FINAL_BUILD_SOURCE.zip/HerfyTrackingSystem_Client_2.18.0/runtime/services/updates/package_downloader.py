from __future__ import annotations
from pathlib import Path
from .models import UpdateManifest
from .transport import UpdateTransport

class PackageDownloader:
    def __init__(self, transport: UpdateTransport | None = None) -> None:
        self.transport = transport or UpdateTransport()

    def download(self, manifest: UpdateManifest, directory: Path) -> Path:
        destination = Path(directory) / manifest.filename
        self.transport.download(manifest.download_url, destination)
        return destination
