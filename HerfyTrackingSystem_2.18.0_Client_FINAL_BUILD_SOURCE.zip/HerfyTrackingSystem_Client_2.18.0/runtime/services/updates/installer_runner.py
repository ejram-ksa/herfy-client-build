from __future__ import annotations
import os
import subprocess
import sys
from pathlib import Path
from .models import UpdateManifest

_FORBIDDEN_PARENTS = {"temp", "tmp", "downloads"}

def current_install_root() -> Path:
    root = Path(sys.executable).resolve().parent if getattr(sys, "frozen", False) else Path(__file__).resolve().parents[3]
    return root

def validate_install_root(root: Path) -> Path:
    root = Path(root).resolve()
    if root.parent == root:
        raise ValueError("Drive root is not a valid installation directory")
    if any(part.casefold() in _FORBIDDEN_PARENTS for part in root.parts):
        raise ValueError("Unsafe installation directory")
    if not (root / "HerfyTrackingSystem.exe").is_file() and getattr(sys, "frozen", False):
        raise ValueError("Current executable missing from installation directory")
    if not (root / "version.json").is_file():
        raise ValueError("version.json missing from installation directory")
    return root

class InstallerRunner:
    def build_command(
        self, package: Path, manifest: UpdateManifest, *,
        install_root: Path, target_pid: int, transaction_id: str
    ) -> list[str]:
        if manifest.package_type != "installer" or package.suffix.lower() != ".exe":
            raise ValueError("InstallerRunner accepts EXE installer packages only")
        root = validate_install_root(install_root)
        return [
            str(package), "/VERYSILENT", "/SUPPRESSMSGBOXES", "/NORESTART",
            "/CLOSEAPPLICATIONS", f"/DIR={root}", f"/CURRENTINSTALLROOT={root}",
            "/AUTORESTARTAPP=0", f"/TARGETPID={int(target_pid)}",
            f"/UPDATETRANSACTION={transaction_id}",
        ]

    def start(self, command: list[str]) -> subprocess.Popen[bytes]:
        return subprocess.Popen(command, close_fds=True)
