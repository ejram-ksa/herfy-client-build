from __future__ import annotations
import uuid
from datetime import datetime
from domain.notification_models import AppNotification
from services.persistent_notification_service import PersistentNotificationService
from .models import UpdateManifest

class UpdateNotificationService:
    def __init__(self, notifications: PersistentNotificationService, user_id: str) -> None:
        self.notifications = notifications
        self.user_id = user_id

    def publish(self, manifest: UpdateManifest) -> bool:
        key = f"update:{manifest.version}:{manifest.sha256}"
        item = AppNotification(
            id=str(uuid.uuid4()), user_id=self.user_id, kind="app_update",
            title="Application update available",
            message=f"Herfy Tracking System {manifest.version} is available.",
            severity="critical" if manifest.mandatory else "info",
            created_at=datetime.now().astimezone(), read_at=None,
            deduplication_key=key, action_type="open_update_dialog",
            action_payload={"target_version": manifest.version, "package_sha256": manifest.sha256},
            expires_at=None,
        )
        return self.notifications.add(item)
