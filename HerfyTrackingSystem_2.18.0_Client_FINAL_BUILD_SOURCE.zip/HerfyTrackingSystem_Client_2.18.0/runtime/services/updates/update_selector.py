from __future__ import annotations
from .models import UpdateManifest

def select_update_service(manifest: UpdateManifest) -> str:
    if manifest.package_type == "patch":
        return "patch"
    if manifest.package_type == "installer":
        return "installer"
    raise ValueError("Unsupported update package type")
