from __future__ import annotations
from pathlib import Path
from .models import UpdateManifest

class PatchUpdateService:
    def validate(self, package: Path, manifest: UpdateManifest) -> None:
        if manifest.package_type != "patch" or Path(package).suffix.lower() != ".zip":
            raise ValueError("Patch service accepts ZIP patches only")
