from __future__ import annotations
import json
import os
from dataclasses import asdict
from pathlib import Path
from .models import UpdateTransaction

class UpdateTransactionStore:
    def __init__(self, app_data_root: Path) -> None:
        self.path = Path(app_data_root) / "updates" / "transaction.json"

    def save(self, value: UpdateTransaction) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)
        temp = self.path.with_suffix(".json.tmp")
        with open(temp, "w", encoding="utf-8", newline="\n") as handle:
            json.dump(asdict(value), handle, ensure_ascii=False, separators=(",", ":"))
            handle.flush()
            os.fsync(handle.fileno())
        os.replace(temp, self.path)

    def load(self) -> UpdateTransaction | None:
        if not self.path.is_file():
            return None
        return UpdateTransaction(**json.loads(self.path.read_text(encoding="utf-8")))
