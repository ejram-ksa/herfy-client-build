from __future__ import annotations
import os
import uuid
from datetime import datetime
from pathlib import Path
from .models import UpdateManifest, UpdateTransaction
from .result_store import UpdateTransactionStore
from .installer_runner import InstallerRunner, current_install_root
from .patch_service import PatchUpdateService

class UpdateCoordinator:
    def __init__(self, store: UpdateTransactionStore) -> None:
        self.store = store

    def create_transaction(self, manifest: UpdateManifest, *, current_version: str, user_id: str) -> UpdateTransaction:
        now = datetime.now().astimezone().isoformat()
        transaction = UpdateTransaction(
            transaction_id=str(uuid.uuid4()), from_version=current_version,
            to_version=manifest.version, package_type=manifest.package_type,
            package_sha256=manifest.sha256, install_root=str(current_install_root()),
            stage="detected", started_at=now, updated_at=now, attempt=1,
            rollback_attempted=False, user_id=user_id,
        )
        self.store.save(transaction)
        return transaction
