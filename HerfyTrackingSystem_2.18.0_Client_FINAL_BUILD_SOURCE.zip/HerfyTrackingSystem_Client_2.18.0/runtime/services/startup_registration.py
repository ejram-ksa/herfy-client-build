from __future__ import annotations

import logging
import sys
from collections.abc import Mapping
from pathlib import Path

from core.booleans import parse_bool
from core.errors import SERVICE_OPERATION_EXCEPTIONS
from settings.config import source_root_dir

logger = logging.getLogger(__name__)
_RUN_KEY_PATH = "Software\\Microsoft\\Windows\\CurrentVersion\\Run"
_RUN_VALUE_NAME = "HerfyTrackingSystem"


def _is_windows() -> bool:
    return sys.platform.startswith("win")


def _quote_arg(value: Path | str) -> str:
    return '"' + str(value) + '"'


def _project_main_script() -> Path:
    return source_root_dir() / "main.py"


def _resolve_dev_python_executable() -> Path:
    executable = Path(sys.executable).resolve()
    if _is_windows():
        pythonw = executable.with_name("pythonw.exe")
        if pythonw.exists():
            return pythonw
    return executable


def _build_launch_command() -> str:
    if getattr(sys, "frozen", False):
        return _quote_arg(Path(sys.executable).resolve())
    return " ".join(
        (
            _quote_arg(_resolve_dev_python_executable()),
            _quote_arg(_project_main_script()),
        )
    )


def _load_winreg():
    if not _is_windows():
        return None
    try:
        import winreg

        return winreg
    except (ImportError, OSError, AttributeError):
        logger.exception("Failed to import Windows registry support")
        return None


def set_start_with_windows(enabled: bool) -> bool:
    """Apply the Windows autostart preference in one operating-system adapter."""
    winreg = _load_winreg()
    if winreg is None:
        return False
    try:
        with winreg.CreateKey(winreg.HKEY_CURRENT_USER, _RUN_KEY_PATH) as key:
            if enabled:
                winreg.SetValueEx(
                    key,
                    _RUN_VALUE_NAME,
                    0,
                    winreg.REG_SZ,
                    _build_launch_command(),
                )
            else:
                try:
                    winreg.DeleteValue(key, _RUN_VALUE_NAME)
                except FileNotFoundError:
                    logger.debug("Startup registry value was already absent")
        return True
    except SERVICE_OPERATION_EXCEPTIONS:
        logger.exception("Failed to update Windows startup registration")
        return False


def sync_startup_from_preferences(preferences: Mapping[str, bool]) -> bool:
    if not _is_windows():
        return False
    return set_start_with_windows(
        parse_bool(preferences.get("start_with_windows"), False)
    )
