from __future__ import annotations
import logging
import threading
from enum import Enum
from typing import Callable

logger = logging.getLogger(__name__)

class ApplicationState(str, Enum):
    STARTING = "starting"
    SIGNED_OUT = "signed_out"
    RESTORING_SESSION = "restoring_session"
    SIGNED_IN = "signed_in"
    RUNNING_BACKGROUND = "running_background"
    SHUTTING_DOWN = "shutting_down"
    LOGGING_OUT = "logging_out"
    PREPARING_UPDATE = "preparing_update"

class ApplicationLifecycle:
    def __init__(self) -> None:
        self._state = ApplicationState.STARTING
        self._lock = threading.RLock()
        self._start_hooks: list[Callable[[], None]] = []
        self._stop_hooks: list[Callable[[], None]] = []

    @property
    def state(self) -> ApplicationState:
        return self._state

    def register_user_task(self, start: Callable[[], None], stop: Callable[[], None]) -> None:
        self._start_hooks.append(start)
        self._stop_hooks.append(stop)

    def transition(self, state: ApplicationState) -> None:
        with self._lock:
            current = self._state
            if current == state:
                return
            self._state = state
        logger.info("Application lifecycle %s -> %s", current.value, state.value)

    def start_user_tasks(self) -> None:
        for hook in self._start_hooks:
            hook()

    def stop_user_tasks(self) -> None:
        for hook in reversed(self._stop_hooks):
            try:
                hook()
            except (OSError, RuntimeError, ValueError):
                logger.exception("Failed to stop user task")
