from __future__ import annotations

import logging
import threading
import time
from pathlib import Path
from typing import Any

from application.ports import fetch_client_bootstrap, get_server_base_url
from core.booleans import parse_bool
from core.errors import SERVICE_OPERATION_EXCEPTIONS
from core.files import read_json_dict, write_json_dict
from core.objects import normalize_int
from settings.config import DEFAULT_SERVER_BASE_URL, runtime_cache_path

logger = logging.getLogger(__name__)
_BOOTSTRAP_CACHE: dict[tuple[str, str], tuple[float, dict[str, Any]]] = {}
_BOOTSTRAP_CACHE_LOCK = threading.RLock()
_BOOTSTRAP_CACHE_TTL_SECONDS = 12.0


def _fetch_cached_bootstrap(base_url: str, client_version: str) -> dict[str, Any]:
    key = (str(base_url or "").rstrip("/"), str(client_version or "").strip())
    now = time.monotonic()
    with _BOOTSTRAP_CACHE_LOCK:
        cached = _BOOTSTRAP_CACHE.get(key)
        if cached is not None:
            timestamp, payload = cached
            if now - float(timestamp) <= _BOOTSTRAP_CACHE_TTL_SECONDS and isinstance(
                payload, dict
            ):
                return dict(payload)
    payload = fetch_client_bootstrap(key[1], base_url=key[0])
    if isinstance(payload, dict) and payload:
        with _BOOTSTRAP_CACHE_LOCK:
            _BOOTSTRAP_CACHE[key] = (time.monotonic(), dict(payload))
    return dict(payload or {})


def current_api_base_url() -> str:
    try:
        return str(
            get_server_base_url(DEFAULT_SERVER_BASE_URL) or DEFAULT_SERVER_BASE_URL
        ).strip()
    except SERVICE_OPERATION_EXCEPTIONS:
        logger.debug("Falling back to default API base URL", exc_info=True)
        return DEFAULT_SERVER_BASE_URL


class StartupRuntimeSnapshot:
    def __init__(
        self,
        startup_config: dict | None = None,
        update_policy: dict | None = None,
        server_time: str = "",
    ) -> None:
        self.startup_config = dict(startup_config or {})
        self.update_policy = dict(update_policy or {})
        self.server_time = str(server_time or "")


class ServerRuntimeService:
    """Cache and apply the sole server bootstrap document for client startup."""

    def __init__(self, base_url: str | None = None):
        try:
            resolved_base_url = base_url or get_server_base_url(DEFAULT_SERVER_BASE_URL)
        except SERVICE_OPERATION_EXCEPTIONS:
            logger.debug(
                "Using default API base URL for server runtime service", exc_info=True
            )
            resolved_base_url = DEFAULT_SERVER_BASE_URL
        self.base_url = str(resolved_base_url or DEFAULT_SERVER_BASE_URL).rstrip("/")
        self.cache_file = Path(runtime_cache_path("remote_state/startup_runtime.json"))
        self.cache_file.parent.mkdir(parents=True, exist_ok=True)

    @staticmethod
    def _snapshot_from_payload(
        payload: dict[str, Any] | None,
    ) -> StartupRuntimeSnapshot | None:
        data = dict(payload or {})
        if not data:
            return None
        return StartupRuntimeSnapshot(
            startup_config=dict(data.get("startup_config") or {}),
            update_policy=dict(data.get("update_policy") or {}),
            server_time=str(data.get("server_time") or ""),
        )

    def _save_cache(self, payload: dict[str, Any]) -> None:
        write_json_dict(self.cache_file, dict(payload or {}), ensure_ascii=False)

    def load_cached(self) -> StartupRuntimeSnapshot | None:
        try:
            if not self.cache_file.exists():
                return None
            return self._snapshot_from_payload(read_json_dict(self.cache_file))
        except SERVICE_OPERATION_EXCEPTIONS:
            logger.exception("Failed to load cached startup runtime snapshot")
            return None

    def fetch_client_bootstrap(self, client_version: str) -> StartupRuntimeSnapshot:
        payload = _fetch_cached_bootstrap(self.base_url, client_version)
        if not payload:
            return self.load_cached() or StartupRuntimeSnapshot()
        self._save_cache(payload)
        return self._snapshot_from_payload(payload) or StartupRuntimeSnapshot()

    def apply_startup_config(
        self, db_manager: Any, snapshot: StartupRuntimeSnapshot | None
    ) -> dict[str, Any]:
        snap = snapshot or self.load_cached()
        if snap is None:
            return {}
        config = dict(snap.startup_config or {})
        thresholds = dict(config.get("alert_thresholds") or {})
        client_runtime = dict(config.get("client_runtime") or {})
        banner = dict(config.get("startup_banner") or {})
        maintenance = dict(config.get("maintenance_mode") or {})
        pairs = {
            "remote_backend_version": str(config.get("backend_version") or ""),
            "remote_api_version": str(config.get("api_version") or ""),
            "remote_latest_client_version": str(
                config.get("latest_client_version") or ""
            ),
            "remote_min_supported_client_version": str(
                config.get("min_supported_client_version") or ""
            ),
            "remote_update_channel": str(config.get("update_channel") or ""),
            "remote_update_platform": str(config.get("update_platform") or ""),
            "remote_update_manifest_url": str(config.get("update_manifest_url") or ""),
            "remote_login_message": str(client_runtime.get("login_message") or ""),
            "remote_startup_banner": str(banner.get("message") or ""),
            "remote_startup_banner_severity": str(banner.get("severity") or "info"),
            "remote_maintenance_enabled": (
                "True" if parse_bool(maintenance.get("enabled"), False) else "False"
            ),
            "remote_maintenance_message": str(maintenance.get("message") or ""),
            "remote_force_logout_below_version": str(
                client_runtime.get("force_logout_below_version") or ""
            ),
        }
        if thresholds.get("warn_days") is not None:
            pairs["expiring_soon_threshold"] = str(
                normalize_int(thresholds.get("warn_days"), 7)
            )
        if thresholds.get("critical_days") is not None:
            pairs["critical_threshold"] = str(
                normalize_int(thresholds.get("critical_days"), 2)
            )
        for key, value in pairs.items():
            try:
                db_manager.set_setting(key, value)
            except SERVICE_OPERATION_EXCEPTIONS:
                logger.exception("Failed to persist startup runtime setting: %s", key)
        return {
            "startup_config": config,
            "update_policy": dict(snap.update_policy or {}),
            "server_time": snap.server_time,
        }

    def fetch_and_apply(self, db_manager: Any, client_version: str) -> dict[str, Any]:
        return self.apply_startup_config(
            db_manager, self.fetch_client_bootstrap(client_version)
        )
