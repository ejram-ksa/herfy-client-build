from __future__ import annotations

import time

from core.booleans import parse_bool


def prepare_update_check(
    settings_store, *, force: bool, now_ts: int | None = None
) -> tuple[object | None, str, bool]:
    """Apply the single update-check cadence before requesting the manifest."""
    current_ts = int(time.time()) if now_ts is None else int(now_ts)
    enabled = parse_bool(settings_store.value("check_updates_on_startup", "True"), True)
    if not force and not enabled:
        return (settings_store, "", False)
    last_value = settings_store.value("updates/last_check", 0)
    last_check = int(last_value or 0)
    if not force and last_check and current_ts - last_check < 12 * 3600:
        skipped = str(settings_store.value("updates/skipped_version", "") or "")
        return (settings_store, skipped, False)
    settings_store.setValue("updates/last_check", current_ts)
    settings_store.sync()
    skipped_version = str(settings_store.value("updates/skipped_version", "") or "")
    return (settings_store, skipped_version, True)
