from __future__ import annotations

import hashlib
import json
import logging
import threading
import time
from contextlib import nullcontext
from dataclasses import dataclass
from typing import Any, Callable

from core.booleans import parse_bool
from data.tracking_baseline import (
    delete_tracking_baseline_row,
    write_tracking_baseline_row,
)

logger = logging.getLogger(__name__)


@dataclass(frozen=True, slots=True)
class SyncIdentity:
    user_id: str
    device_id: str
    session_id: str
    generation: int


class LocalFirstSyncEngine:
    """One background delta-sync worker bound to one authenticated identity."""

    def __init__(
        self,
        repository: Any,
        *,
        on_changes: Callable[[dict[str, Any]], None] | None = None,
        on_state: Callable[[dict[str, Any]], None] | None = None,
        generation_is_current: Callable[[int], bool] | None = None,
    ) -> None:
        self.repository = repository
        self.on_changes = on_changes
        self.on_state = on_state
        self.generation_is_current = generation_is_current
        self._lock = threading.RLock()
        self._wake = threading.Event()
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None
        self._debounce_timer: threading.Timer | None = None
        self._identity: SyncIdentity | None = None
        self._api_client: Any | None = None
        self._allowed_branches: tuple[str, ...] = ()
        self._all_branches = False
        self._backoff_seconds = 1.0
        self._authority_token = f"local-first-{id(self):x}"
        self._scope_fingerprint_value = ""

    @property
    def running(self) -> bool:
        thread = self._thread
        return bool(thread and thread.is_alive() and not self._stop.is_set())

    def start(
        self,
        *,
        user_id: str,
        device_id: str,
        session_id: str,
        generation: int,
        api_client: Any,
        allowed_branches: list[str] | tuple[str, ...],
        all_branches: bool,
    ) -> None:
        identity = SyncIdentity(
            user_id=str(user_id or "").strip(),
            device_id=str(device_id or "").strip(),
            session_id=str(session_id or "").strip(),
            generation=int(generation),
        )
        if not identity.user_id or not identity.device_id or api_client is None:
            raise ValueError("Authenticated user, device, and API client are required")
        self.stop()
        with self._lock:
            self._identity = identity
            self._api_client = api_client
            self._allowed_branches = tuple(
                dict.fromkeys(
                    str(branch or "").strip()
                    for branch in allowed_branches or ()
                    if str(branch or "").strip()
                )
            )
            self._all_branches = bool(all_branches)
            self._refresh_scope_configuration(api_client)
            self._backoff_seconds = 1.0
            self._stop.clear()
            self._wake.set()
            scope_fingerprint = self._scope_fingerprint(api_client)
            ensure_scope = getattr(self.repository, "ensure_sync_scope", None)
            if callable(ensure_scope):
                ensure_scope(
                    identity.user_id,
                    identity.device_id,
                    scope_fingerprint,
                )
            self._scope_fingerprint_value = scope_fingerprint
            migrate_legacy = getattr(
                self.repository, "migrate_legacy_usage_operations", None
            )
            if callable(migrate_legacy):
                migrate_legacy(
                    identity.user_id, identity.device_id, identity.session_id
                )
            recover = getattr(self.repository, "recover_inflight_operations", None)
            if callable(recover):
                recover(identity.user_id, identity.device_id)
            self._set_api_authority(api_client, True)
            self._thread = threading.Thread(
                target=self._run,
                name=f"herfy-sync-{identity.user_id}",
                daemon=True,
            )
            self._thread.start()
        self._emit_state("queued", identity)

    def stop(self, timeout: float = 4.0) -> None:
        with self._lock:
            thread = self._thread
            identity = self._identity
            api_client = self._api_client
            self._stop.set()
            timer = self._debounce_timer
            self._debounce_timer = None
            if timer is not None:
                timer.cancel()
            self._wake.set()
        if thread and thread.is_alive() and thread is not threading.current_thread():
            thread.join(timeout=max(0.0, float(timeout)))
        with self._lock:
            self._thread = None
            self._api_client = None
            self._identity = None
            self._allowed_branches = ()
            self._all_branches = False
            self._scope_fingerprint_value = ""
            self._wake.clear()
        self._set_api_authority(api_client, False)
        if identity is not None:
            self._emit_state("stopped", identity)

    def wake(self, *, immediate: bool = False) -> None:
        """Wake sync only for a real event.

        Local edits are debounced for two seconds so multiple changes are sent
        as one batch. Remote notifications and startup recovery wake immediately.
        """
        if not self.running:
            return
        if immediate:
            with self._lock:
                timer = self._debounce_timer
                self._debounce_timer = None
            if timer is not None:
                timer.cancel()
            self._wake.set()
            return

        def _fire() -> None:
            with self._lock:
                self._debounce_timer = None
            if self.running:
                self._wake.set()

        with self._lock:
            timer = self._debounce_timer
            if timer is not None:
                timer.cancel()
            timer = threading.Timer(2.0, _fire)
            timer.daemon = True
            self._debounce_timer = timer
            timer.start()

    def _set_api_authority(self, api_client: Any, active: bool) -> None:
        setter = getattr(api_client, "set_local_sync_authority", None)
        if not callable(setter):
            return
        try:
            setter(bool(active), owner_token=self._authority_token)
        except TypeError:
            # Lightweight test doubles may expose a single positional argument.
            setter(bool(active))

    def _scope_fingerprint(self, api_client: Any) -> str:
        raw_user = getattr(api_client, "user", {})
        user = raw_user if isinstance(raw_user, dict) else {}
        raw_scope = user.get("scope") if isinstance(user.get("scope"), dict) else {}
        permissions = sorted(
            {
                str(value).strip()
                for value in user.get("permissions") or []
                if str(value).strip()
            }
        )
        payload = {
            "server": str(getattr(api_client, "base_url", "") or "").rstrip("/"),
            "all_branches": bool(self._all_branches),
            "branches": sorted(
                {
                    str(value).strip()
                    for value in self._allowed_branches
                    if str(value).strip()
                }
            ),
            "permissions": permissions,
            "authority_revision": str(
                user.get("authority_revision")
                or raw_scope.get("authority_revision")
                or ""
            ),
            "server_scope": raw_scope,
        }
        raw = json.dumps(payload, ensure_ascii=False, sort_keys=True, default=str)
        return hashlib.sha256(raw.encode("utf-8")).hexdigest()

    def _refresh_scope_configuration(self, api_client: Any) -> None:
        """Adopt the latest authorized branch scope from a refreshed token.

        Token refresh can alter a user's branches or all-branches flag while
        the process remains open.  Cursor invalidation alone is insufficient:
        the following bootstrap/pull must also send the *new* branch request
        rather than the scope captured at the original login.
        """

        raw_user = getattr(api_client, "user", {})
        user = raw_user if isinstance(raw_user, dict) else {}
        scope = user.get("scope") if isinstance(user.get("scope"), dict) else {}
        if not scope:
            return
        self._all_branches = parse_bool(
            scope.get("all_branches", self._all_branches), self._all_branches
        )
        raw_branches = scope.get("branches")
        if not isinstance(raw_branches, (list, tuple, set)):
            raw_branches = user.get("assigned_branch_ids")
        if not isinstance(raw_branches, (list, tuple, set)):
            raw_branches = ()
        self._allowed_branches = tuple(
            dict.fromkeys(
                str(branch or "").strip()
                for branch in raw_branches
                if str(branch or "").strip()
            )
        )

    def _refresh_scope_if_changed(
        self, identity: SyncIdentity, api_client: Any
    ) -> bool:
        self._refresh_scope_configuration(api_client)
        fingerprint = self._scope_fingerprint(api_client)
        if fingerprint == self._scope_fingerprint_value:
            return False
        ensure_scope = getattr(self.repository, "ensure_sync_scope", None)
        if callable(ensure_scope):
            ensure_scope(identity.user_id, identity.device_id, fingerprint)
        self._scope_fingerprint_value = fingerprint
        return True

    def _operation_summary(self, identity: SyncIdentity) -> dict[str, int]:
        summary = getattr(self.repository, "operation_summary", None)
        if not callable(summary):
            return {
                "pending": 0,
                "retry": 0,
                "in_flight": 0,
                "conflict": 0,
                "rejected": 0,
                "queued": 0,
                "review": 0,
            }
        try:
            value = summary(identity.user_id, identity.device_id)
            return dict(value) if isinstance(value, dict) else {}
        except Exception:
            logger.debug("Unable to read local sync operation summary", exc_info=True)
            return {}

    def _emit_state(
        self,
        phase: str,
        identity: SyncIdentity | None,
        result: dict[str, Any] | None = None,
        *,
        error_kind: str = "",
    ) -> None:
        if identity is None or not callable(self.on_state):
            return
        payload: dict[str, Any] = {
            "phase": str(phase or "").strip().lower(),
            "generation": identity.generation,
            "counts": self._operation_summary(identity),
        }
        if isinstance(result, dict):
            for key in (
                "pushed",
                "pulled",
                "cursor",
                "conflicts",
                "rejected",
                "has_more",
                "has_changes",
            ):
                if key in result:
                    payload[key] = result[key]
        if error_kind:
            payload["error_kind"] = str(error_kind)
        try:
            self.on_state(payload)
        except Exception:
            logger.debug("Local sync state callback failed", exc_info=True)

    def _identity_is_current(self, identity: SyncIdentity) -> bool:
        current = self._identity
        if current != identity or self._stop.is_set():
            return False
        checker = self.generation_is_current
        return bool(checker(identity.generation)) if callable(checker) else True

    def _run(self) -> None:
        while not self._stop.is_set():
            self._wake.wait()
            self._wake.clear()
            identity = self._identity
            if identity is None or not self._identity_is_current(identity):
                continue
            try:
                self._emit_state("syncing", identity)
                changed = self.sync_once(identity)
                self._backoff_seconds = 1.0
                if bool(changed.get("has_more", False)):
                    self._wake.set()
                counts = dict(changed.get("counts") or {})
                if int(counts.get("review") or 0) > 0:
                    phase = "blocked"
                elif int(counts.get("queued") or 0) > 0:
                    phase = "queued"
                else:
                    phase = "synced"
                self._emit_state(phase, identity, changed)
                if bool(changed.get("has_changes", False)) and callable(
                    self.on_changes
                ):
                    self.on_changes(changed)
            except Exception as exc:  # background boundary
                logger.warning("Background sync failed: %s", type(exc).__name__)
                self._emit_state("retrying", identity, error_kind=type(exc).__name__)
                wait_for = min(self._backoff_seconds, 60.0)
                self._backoff_seconds = min(wait_for * 2.0, 60.0)
                self._stop.wait(wait_for)

    @staticmethod
    def _result_error(result: dict[str, Any]) -> str:
        value = result.get("error") or result.get("detail") or result.get("message")
        if isinstance(value, dict):
            value = value.get("reason") or value.get("message") or value
        return str(value or "Server did not acknowledge operation")

    @staticmethod
    def _is_accepted_result(result: dict[str, Any]) -> bool:
        return str(result.get("status") or "").strip().lower() in {
            "ok",
            "accepted",
            "duplicate",
            "idempotent",
        }

    @staticmethod
    def _is_permanent_rejection(result: dict[str, Any]) -> bool:
        status_code = int(result.get("status_code") or 0)
        status = str(result.get("status") or "").strip().lower()
        return status in {"conflict", "rejected"} or 400 <= status_code < 500

    @staticmethod
    def _transport_status_code(exc: BaseException) -> int:
        value = getattr(exc, "status_code", None)
        if value is None:
            response = getattr(exc, "response", None)
            value = getattr(response, "status_code", None)
        try:
            return int(value or 0)
        except (TypeError, ValueError):
            return 0

    @classmethod
    def _is_permanent_transport_error(cls, exc: BaseException) -> bool:
        status_code = cls._transport_status_code(exc)
        return 400 <= status_code < 500 and status_code != 429

    def _push_changes(
        self, api_client: Any, payloads: list[dict[str, Any]]
    ) -> dict[str, Any]:
        if callable(getattr(api_client, "set_local_sync_authority", None)):
            return api_client.push_sync_changes(
                payloads, sync_owner=self._authority_token
            )
        return api_client.push_sync_changes(payloads)

    def _pull_changes(
        self, api_client: Any, *, cursor: int, branch_ids: list[str]
    ) -> dict[str, Any]:
        if callable(getattr(api_client, "set_local_sync_authority", None)):
            return api_client.pull_sync_changes(
                cursor=cursor,
                branch_ids=branch_ids,
                sync_owner=self._authority_token,
            )
        return api_client.pull_sync_changes(cursor=cursor, branch_ids=branch_ids)

    def _fetch_bootstrap(
        self, api_client: Any, *, branch_ids: list[str]
    ) -> dict[str, Any]:
        fetch = getattr(api_client, "fetch_sync_bootstrap", None)
        if not callable(fetch):
            return {"sync_bootstrap_unavailable": True}
        if callable(getattr(api_client, "set_local_sync_authority", None)):
            try:
                return fetch(branch_ids=branch_ids, sync_owner=self._authority_token)
            except TypeError:
                # Keep deliberately small API fakes usable in tests.
                return fetch(branch_ids=branch_ids)
        return fetch(branch_ids=branch_ids)

    def _install_bootstrap_if_needed(
        self, identity: SyncIdentity, api_client: Any, branch_ids: list[str]
    ) -> dict[str, Any]:
        needs_bootstrap = getattr(self.repository, "needs_sync_bootstrap", None)
        if not callable(needs_bootstrap) or not needs_bootstrap(
            identity.user_id, identity.device_id
        ):
            return {"applied": False, "domains": []}

        current_cursor = self.repository.sync_cursor_for(
            identity.user_id, identity.device_id
        )
        payload = self._fetch_bootstrap(api_client, branch_ids=branch_ids)
        if bool(payload.get("delegated_to_local_sync")):
            raise RuntimeError("The local sync coordinator lost API ownership")
        if bool(payload.get("sync_bootstrap_unavailable")) or bool(
            payload.get("permission_denied")
        ):
            # A rolling deployment can temporarily pair this client with an
            # older server.  Its normal event stream remains a valid fallback;
            # mark the one-time bootstrap attempt complete to avoid a retry
            # loop while preserving the current cursor.
            mark_ready = getattr(self.repository, "mark_sync_bootstrap_ready", None)
            if callable(mark_ready):
                mark_ready(
                    identity.user_id,
                    identity.device_id,
                    cursor=current_cursor,
                )
            return {"applied": False, "fallback": True, "domains": []}
        if not isinstance(payload, dict) or not payload:
            raise RuntimeError("Sync bootstrap returned an invalid response")
        apply_bootstrap = getattr(self.repository, "apply_sync_bootstrap", None)
        if not callable(apply_bootstrap):
            return {"applied": False, "domains": []}
        result = apply_bootstrap(
            user_id=identity.user_id,
            device_id=identity.device_id,
            baseline=payload,
        )
        if not isinstance(result, dict):
            result = {}
        set_cursor = getattr(api_client, "set_sync_cursor", None)
        if callable(set_cursor):
            set_cursor(result.get("cursor", current_cursor))
        result["applied"] = True
        return result

    def _claim_operations(self, identity: SyncIdentity) -> list[dict[str, Any]]:
        claim = getattr(self.repository, "claim_pending_operations", None)
        if callable(claim):
            return list(claim(identity.user_id, identity.device_id, limit=50) or [])
        # Compatibility for intentionally small repository fakes in tests.
        return list(
            self.repository.pending_operations(
                identity.user_id, identity.device_id, limit=50
            )
            or []
        )

    def sync_once(self, identity: SyncIdentity | None = None) -> dict[str, Any]:
        identity = identity or self._identity
        api_client = self._api_client
        if identity is None or api_client is None:
            return {"pushed": 0, "pulled": 0, "has_changes": False}
        if not self._identity_is_current(identity):
            return {"pushed": 0, "pulled": 0, "stale": True, "has_changes": False}

        self._refresh_scope_if_changed(identity, api_client)

        guard = getattr(api_client, "sync_guard", None)
        lock_context = guard() if callable(guard) else nullcontext()
        with lock_context:
            branch_ids = [] if self._all_branches else list(self._allowed_branches)
            bootstrap = self._install_bootstrap_if_needed(
                identity, api_client, branch_ids
            )
            pending = self._claim_operations(identity)
            pushed = 0
            conflicts = 0
            rejected = 0
            if pending:
                payloads = [self._pending_payload(row, identity) for row in pending]
                permanent_transport_failure = False
                try:
                    result = self._push_changes(api_client, payloads)
                except Exception as exc:
                    permanent = self._is_permanent_transport_error(exc)
                    for row in pending:
                        op_id = str(row["operation_id"])
                        if permanent:
                            self.repository.mark_operation_blocked(
                                op_id,
                                identity.user_id,
                                identity.device_id,
                                status="rejected",
                                error=str(exc),
                            )
                            block_dependents = getattr(
                                self.repository, "block_dependent_operations", None
                            )
                            if callable(block_dependents):
                                block_dependents(
                                    user_id=identity.user_id,
                                    device_id=identity.device_id,
                                    entity_type=str(row.get("entity_type") or ""),
                                    entity_id=str(row.get("entity_id") or ""),
                                    status="rejected",
                                    error=str(exc),
                                    except_operation_id=op_id,
                                )
                            rejected += 1
                        else:
                            self.repository.mark_operation_retry(
                                op_id,
                                identity.user_id,
                                identity.device_id,
                                str(exc),
                            )
                    if not permanent:
                        raise
                    permanent_transport_failure = True
                    result = {"results": [], "ok": False}
                result_rows = result.get("results") or result.get("changes") or []
                by_operation = {
                    str(item.get("operation_id") or "").strip(): item
                    for item in result_rows
                    if isinstance(item, dict)
                    and str(item.get("operation_id") or "").strip()
                }
                fallback_accept_all = not by_operation and bool(result.get("ok", False))
                for row in (() if permanent_transport_failure else pending):
                    op_id = str(row["operation_id"])
                    item = by_operation.get(op_id, {})
                    if fallback_accept_all or self._is_accepted_result(item):
                        self.repository.mark_operation_completed(
                            op_id, identity.user_id, identity.device_id
                        )
                        rebase = getattr(
                            self.repository, "rebase_following_operations", None
                        )
                        if callable(rebase):
                            record = (
                                item.get("record")
                                if isinstance(item.get("record"), dict)
                                else {}
                            )
                            server_revision = int(
                                item.get("server_revision")
                                or record.get("revision")
                                or 0
                            )
                            rebase(
                                user_id=identity.user_id,
                                device_id=identity.device_id,
                                entity_type=str(row.get("entity_type") or ""),
                                entity_id=str(row.get("entity_id") or ""),
                                server_revision=server_revision,
                                except_operation_id=op_id,
                            )
                        pushed += 1
                    elif self._is_permanent_rejection(item):
                        status = (
                            "conflict"
                            if str(item.get("status") or "").lower() == "conflict"
                            or int(item.get("status_code") or 0) == 409
                            else "rejected"
                        )
                        self.repository.mark_operation_blocked(
                            op_id,
                            identity.user_id,
                            identity.device_id,
                            status=status,
                            error=self._result_error(item),
                        )
                        block_dependents = getattr(
                            self.repository, "block_dependent_operations", None
                        )
                        if callable(block_dependents):
                            block_dependents(
                                user_id=identity.user_id,
                                device_id=identity.device_id,
                                entity_type=str(row.get("entity_type") or ""),
                                entity_id=str(row.get("entity_id") or ""),
                                status=status,
                                error=self._result_error(item),
                                except_operation_id=op_id,
                            )
                        if status == "conflict":
                            conflicts += 1
                        else:
                            rejected += 1
                    else:
                        self.repository.mark_operation_retry(
                            op_id,
                            identity.user_id,
                            identity.device_id,
                            self._result_error(item),
                        )

            if not self._identity_is_current(identity):
                return {
                    "pushed": pushed,
                    "pulled": 0,
                    "stale": True,
                    "generation": identity.generation,
                    "has_changes": False,
                }

            cursor = self.repository.sync_cursor_for(
                identity.user_id, identity.device_id
            )
            all_events: list[dict[str, Any]] = []
            has_more = False
            for _page in range(4):
                pulled_payload = self._pull_changes(
                    api_client, cursor=cursor, branch_ids=branch_ids
                )
                if bool(pulled_payload.get("delegated_to_local_sync")):
                    raise RuntimeError("The local sync coordinator lost API ownership")
                events = pulled_payload.get("events")
                if not isinstance(events, list):
                    events = pulled_payload.get("changes")
                events = [item for item in events or [] if isinstance(item, dict)]
                if not events:
                    has_more = False
                    break
                next_cursor = self.repository.apply_sync_events(
                    user_id=identity.user_id,
                    device_id=identity.device_id,
                    events=events,
                    apply_event=lambda conn, event: self._apply_event(
                        conn, event, identity
                    ),
                )
                server_cursor = int(
                    pulled_payload.get("next_cursor")
                    or pulled_payload.get("cursor")
                    or next_cursor
                    or 0
                )
                updated_cursor = max(cursor, next_cursor, server_cursor)
                self.repository.set_sync_cursor_for(
                    identity.user_id, identity.device_id, updated_cursor
                )
                all_events.extend(events)
                has_more = bool(
                    pulled_payload.get("has_more") or pulled_payload.get("truncated")
                )
                if updated_cursor <= cursor:
                    logger.warning(
                        "Sync pull returned events without advancing its cursor"
                    )
                    break
                cursor = updated_cursor
                if not has_more or not self._identity_is_current(identity):
                    break

            set_cursor = getattr(api_client, "set_sync_cursor", None)
            if callable(set_cursor):
                set_cursor(cursor)
        counts = self._operation_summary(identity)
        conflicts = int(counts.get("conflict") or conflicts)
        rejected = int(counts.get("rejected") or rejected)
        has_more = bool(has_more or int(counts.get("queued") or 0) > 0)
        return {
            "pushed": pushed,
            "pulled": len(all_events),
            "cursor": cursor,
            "events": all_events,
            "bootstrap": bootstrap,
            "domains": list(bootstrap.get("domains") or []),
            "conflicts": conflicts,
            "rejected": rejected,
            "has_more": has_more,
            "generation": identity.generation,
            "counts": counts,
            "has_changes": bool(
                pushed
                or all_events
                or bootstrap.get("applied")
                or conflicts
                or rejected
            ),
        }

    @staticmethod
    def _pending_payload(row: dict[str, Any], identity: SyncIdentity) -> dict[str, Any]:
        payload = row.get("payload") if isinstance(row.get("payload"), dict) else {}
        return {
            "operation_id": str(row.get("operation_id") or ""),
            "user_id": identity.user_id,
            "device_id": identity.device_id,
            "session_id": identity.session_id,
            "entity_type": str(row.get("entity_type") or ""),
            "entity_id": str(row.get("entity_id") or ""),
            "entity_key": str(row.get("entity_id") or ""),
            "action": str(row.get("action") or "upsert"),
            "operation": str(row.get("action") or "upsert"),
            "branch_id": str(row.get("branch_id") or ""),
            "base_revision": row.get("base_revision"),
            "payload": dict(payload),
        }

    @staticmethod
    def _canonical_entity_type(entity_type: str) -> str:
        entity = str(entity_type or "").strip().lower()
        if entity in {"tracking", "tracking_item", "tracked_product"}:
            return "tracking_item"
        if entity in {"stored_product", "catalog_product", "product"}:
            return "stored_product"
        if entity in {"usage", "usage_product", "usage_products", "catalog_usage"}:
            return "usage_product"
        return ""

    @staticmethod
    def _event_revision(event: dict[str, Any], payload: dict[str, Any]) -> int:
        try:
            return max(0, int(event.get("revision") or payload.get("revision") or 0))
        except (TypeError, ValueError):
            return 0

    def _has_local_overlay(
        self,
        conn,
        identity: SyncIdentity,
        entity_type: str,
        entity_id: str,
    ) -> bool:
        checker = getattr(self.repository, "has_pending_operation_for_entity", None)
        if callable(checker):
            return bool(
                checker(
                    user_id=identity.user_id,
                    device_id=identity.device_id,
                    entity_type=entity_type,
                    entity_id=entity_id,
                    conn=conn,
                )
            )
        return False

    def _apply_event(self, conn, event: dict[str, Any], identity: SyncIdentity) -> None:
        payload = event.get("payload") if isinstance(event.get("payload"), dict) else {}
        entity_type = self._canonical_entity_type(event.get("entity_type") or "")
        if not entity_type:
            return
        entity_id = str(
            event.get("entity_id")
            or event.get("entity_key")
            or payload.get("id")
            or payload.get("doc_id")
            or payload.get("material_number")
            or payload.get("material")
            or ""
        ).strip()
        if not entity_id:
            return
        if self._has_local_overlay(conn, identity, entity_type, entity_id):
            # The event is durable and its cursor is still recorded.  Keeping
            # the newer local overlay visible prevents an acknowledged older
            # edit from overwriting a subsequent offline edit.
            return
        action = (
            str(event.get("action") or event.get("operation") or "upsert")
            .strip()
            .lower()
        )
        revision = self._event_revision(event, payload)
        if entity_type == "stored_product":
            self._apply_stored_product_event(conn, entity_id, payload, action, revision)
            return
        if entity_type == "usage_product":
            self._apply_usage_product_event(conn, entity_id, payload, action, revision)
            return
        self._apply_tracking_event(conn, entity_id, payload, action, revision, event)

    @staticmethod
    def _apply_stored_product_event(
        conn,
        material: str,
        payload: dict[str, Any],
        action: str,
        revision: int,
    ) -> None:
        if action == "delete":
            conn.execute(
                """
                INSERT INTO stored_products(material_number, name, revision, is_active)
                VALUES(?, ?, ?, 0)
                ON CONFLICT(material_number) DO UPDATE SET
                    revision = MAX(stored_products.revision, excluded.revision),
                    is_active = 0
                """,
                (
                    material,
                    str(
                        payload.get("name") or payload.get("material_name") or material
                    ),
                    revision,
                ),
            )
            return
        name = str(
            payload.get("name") or payload.get("material_name") or material
        ).strip()
        is_active = parse_bool(
            payload.get("is_active", payload.get("active", True)), True
        )
        conn.execute(
            """
            INSERT INTO stored_products(material_number, name, revision, is_active)
            VALUES(?, ?, ?, ?)
            ON CONFLICT(material_number) DO UPDATE SET
                name = excluded.name,
                revision = MAX(stored_products.revision, excluded.revision),
                is_active = excluded.is_active
            """,
            (material, name or material, revision, int(is_active)),
        )

    @staticmethod
    def _apply_usage_product_event(
        conn,
        material: str,
        payload: dict[str, Any],
        action: str,
        revision: int,
    ) -> None:
        if action == "delete":
            conn.execute(
                """
                INSERT INTO usage_products(material, name, uom, revision, active)
                VALUES(?, ?, ?, ?, 0)
                ON CONFLICT(material) DO UPDATE SET
                    revision = MAX(usage_products.revision, excluded.revision),
                    active = 0
                """,
                (
                    material,
                    str(
                        payload.get("name") or payload.get("material_name") or material
                    ),
                    str(payload.get("uom") or payload.get("unit") or ""),
                    revision,
                ),
            )
            return
        name = str(
            payload.get("name") or payload.get("material_name") or material
        ).strip()
        uom = str(payload.get("uom") or payload.get("unit") or "").strip()
        active = parse_bool(payload.get("active", payload.get("is_active", True)), True)
        conn.execute(
            """
            INSERT INTO usage_products(material, name, uom, revision, active)
            VALUES(?, ?, ?, ?, ?)
            ON CONFLICT(material) DO UPDATE SET
                name = excluded.name,
                uom = CASE
                    WHEN excluded.uom <> '' THEN excluded.uom
                    ELSE usage_products.uom
                END,
                revision = MAX(usage_products.revision, excluded.revision),
                active = excluded.active
            """,
            (material, name or material, uom, revision, int(active)),
        )

    @staticmethod
    def _apply_tracking_event(
        conn,
        entity_id: str,
        payload: dict[str, Any],
        action: str,
        revision: int,
        event: dict[str, Any],
    ) -> None:
        branch = str(
            event.get("branch_id")
            or payload.get("branch_id")
            or payload.get("branch")
            or ""
        ).strip()
        if action == "delete":
            delete_tracking_baseline_row(
                conn,
                document_id=entity_id,
                branch=branch,
            )
            return
        normalized = dict(payload)
        normalized["revision"] = revision
        write_tracking_baseline_row(
            conn,
            normalized,
            fallback_document_id=entity_id,
            fallback_branch=branch,
            updated_at=time.strftime("%Y-%m-%dT%H:%M:%S"),
        )
