from __future__ import annotations

# ruff: noqa: E402

import logging
import threading
from collections.abc import Iterator
from contextlib import contextmanager
from typing import Any
import requests
from core.booleans import parse_bool
from core.errors import SERVICE_OPERATION_EXCEPTIONS
from remote.cache_api import _user_to_dict
from remote.http import (
    current_http_timeout,
    current_requests_verify,
    get_server_base_url,
    HttpSessionOwner,
    request_with_retry,
    resolve_api_url,
    redact_url_for_log,
)
from remote.realtime import CallbackBridge

logger = logging.getLogger(__name__)


class CloudTrackingService:

    def __init__(
        self, id_token: str | None = None, user: Any = None, base_url: str | None = None
    ):
        super().__init__()
        self.base_url = (
            get_server_base_url()
            if not str(base_url or "").strip()
            else str(base_url).rstrip("/")
        )
        self.id_token = id_token
        self.user = _user_to_dict(user)
        self._sync_lock = threading.RLock()
        self._realtime_session_lock = threading.RLock()
        self._http_sessions = HttpSessionOwner()
        self._realtime_sessions: set[requests.Session] = set()
        self._realtime_lock = threading.RLock()
        self._cursor: int = 0
        self._rt_stop = threading.Event()
        self._rt_thread: threading.Thread | None = None
        self._events_unavailable: bool = False
        self._local_sync_authority = False
        self._local_sync_owner = ""
        self._callback_bridge = CallbackBridge()

    def _headers(self) -> dict[str, str]:
        h = {"Content-Type": "application/json"}
        if self.id_token:
            h["Authorization"] = f"Bearer {self.id_token}"
        return h

    @contextmanager
    def sync_guard(self) -> Iterator[None]:
        """Serialize cursor-based sync work for this authenticated API client."""

        with self._sync_lock:
            yield

    def set_local_sync_authority(self, active: bool, *, owner_token: str = "") -> None:
        """Reserve cursor-based sync I/O for the local-first coordinator."""

        with self._sync_lock:
            if active:
                self._local_sync_authority = True
                self._local_sync_owner = str(owner_token or "").strip()
            elif (
                not self._local_sync_owner
                or self._local_sync_owner == str(owner_token or "").strip()
            ):
                self._local_sync_authority = False
                self._local_sync_owner = ""

    def _is_local_sync_owner(self, owner_token: str = "") -> bool:
        return bool(
            not self._local_sync_authority
            or (
                bool(self._local_sync_owner)
                and self._local_sync_owner == str(owner_token or "").strip()
            )
        )

    @contextmanager
    def _realtime_session(self) -> Iterator[requests.Session]:
        """Track the stream session so shutdown can interrupt a blocking read."""

        session = self._http_sessions.new_session()
        with self._realtime_session_lock:
            self._realtime_sessions.add(session)
        try:
            yield session
        finally:
            with self._realtime_session_lock:
                self._realtime_sessions.discard(session)
            self._http_sessions.release_session(session)

    def _close_realtime_sessions(self) -> None:
        with self._realtime_session_lock:
            sessions = list(self._realtime_sessions)
        for session in sessions:
            try:
                session.close()
            except SERVICE_OPERATION_EXCEPTIONS:
                logger.debug("Realtime session shutdown close failed", exc_info=True)

    def _request_with_session(
        self, method: str, url: str, **kwargs
    ) -> requests.Response:
        return request_with_retry(
            method,
            url,
            session_owner=self._http_sessions,
            timeout=current_http_timeout(),
            verify=current_requests_verify(),
            **kwargs,
        )

    def _realtime_get(self, session: requests.Session, url: str, **kwargs):
        return session.get(
            url,
            timeout=current_http_timeout(),
            verify=current_requests_verify(),
            allow_redirects=False,
            **kwargs,
        )

    def _resolve_request_url(self, path: str) -> str:
        return resolve_api_url(path, base_url=self.base_url)

    def _req(self, method: str, path: str, **kwargs) -> requests.Response:
        url = self._resolve_request_url(path)
        kwargs.setdefault("headers", self._headers())
        logger.info("Tracking API: %s %s -> %s", method, path, redact_url_for_log(url))
        try:
            response = self._request_with_session(method, url, **kwargs)
            logger.info("Tracking API response: %s", response.status_code)
            return response
        except SERVICE_OPERATION_EXCEPTIONS as e:
            status_code = int(getattr(e, "status_code", 0) or 0)
            if str(path).strip() == "/sync/pull" and status_code in {404, 405, 501}:
                logger.info(
                    "Optional sync endpoint unavailable: %s (%s)", path, status_code
                )
            else:
                logger.error("Tracking API error: %s %s - %s", method, path, e)
            raise

    def _reset_realtime_worker(self) -> None:
        # Every worker owns the Event captured when it starts. Replacing the
        # Event prevents a timed-out previous worker from being revived when a
        # new worker clears its own stop state.
        self.stop_realtime()
        with self._realtime_lock:
            self._rt_stop = threading.Event()
            self._rt_thread = None

    def _start_realtime_worker(self, target) -> None:
        with self._realtime_lock:
            self._rt_thread = threading.Thread(
                target=target,
                name="herfy-realtime",
                daemon=True,
            )
            self._rt_thread.start()

    def close(self) -> None:
        stop_realtime = getattr(self, "stop_realtime", None)
        if callable(stop_realtime):
            stop_realtime()
        self._http_sessions.close()


import logging
import time
from settings.config import get_cache_ttl
from core.objects import safe_get
from core.strings import normalize_text

logger = logging.getLogger(__name__)
from application.dto import (
    normalize_area_payload,
    normalize_branch_payload,
    normalize_region_payload,
)
from core.objects import clean_string_list, normalize_int


class RemoteTrackingMetadataMixin:

    def _server_authority_valid(self) -> bool:
        source = normalize_text(safe_get(self.user, "permission_source"))
        scope = safe_get(self.user, "scope")
        permissions = safe_get(self.user, "permissions")
        return (
            source == "postgresql.role_permissions"
            and isinstance(scope, dict)
            and isinstance(permissions, (list, tuple, set))
        )

    def _server_permissions(self) -> set[str]:
        if not self._server_authority_valid():
            return set()
        return {
            normalize_text(value).lower()
            for value in safe_get(self.user, "permissions") or []
            if normalize_text(value)
        }

    def _server_has_permission(self, permission: str) -> bool:
        code = normalize_text(permission).lower()
        permissions = self._server_permissions()
        return bool(code and ("*" in permissions or code in permissions))

    def _server_has_any_permission(self, *permissions: str) -> bool:
        return any(self._server_has_permission(code) for code in permissions)

    def _require_server_permission(self, permission: str) -> None:
        if not self._server_has_permission(permission):
            raise PermissionError(f"Server permission required: {permission}")

    def _server_can_access_branch(self, branch: str | None) -> bool:
        value = normalize_text(branch)
        if not value or not self._server_authority_valid():
            return False
        if self._server_scope_all_branches():
            return True
        return value.casefold() in {
            item.casefold() for item in self._known_scope_branches()
        }

    def _metadata_cache_ttl(self) -> float:
        return float(get_cache_ttl().metadata)

    @staticmethod
    def _normalize_rows(
        items: list[Any], normalizer, id_key: str
    ) -> list[dict[str, Any]]:
        rows: list[dict[str, Any]] = []
        for item in items:
            row = normalizer(item)
            if row.get(id_key):
                rows.append(row)
        return rows

    def _request_json_optional(
        self, path: str, *, params: dict[str, Any] | None = None
    ) -> dict[str, Any]:
        try:
            return self._safe_json(self._req("GET", path, params=params))
        except SERVICE_OPERATION_EXCEPTIONS as exc:
            if int(getattr(exc, "status_code", 0) or 0) == 404:
                return {}
            raise

    def _server_scope_all_branches(self) -> bool:
        """Read all-branch scope only from authenticated server authority."""
        if not self._server_authority_valid():
            return False
        scope = safe_get(self.user, "scope") or {}
        try:
            return parse_bool(safe_get(scope, "all_branches"), False)
        except SERVICE_OPERATION_EXCEPTIONS:
            logger.warning(
                "Unable to read all-branch scope; restricted scope is enforced",
                exc_info=True,
            )
            return False

    def _server_scope_branch_ids(self) -> list[str]:
        """Return restricted branches; empty scope never grants global access."""
        if self._server_scope_all_branches():
            return []
        return self._known_scope_branches()

    def _known_scope_branches(self) -> list[str]:
        if not self._server_authority_valid():
            return []
        scope = safe_get(self.user, "scope") or {}
        return clean_string_list(safe_get(scope, "branches") or [])

    def meta_branches(self) -> list[str]:
        return [
            row.get("branch_id", "")
            for row in self.meta_branches_full()
            if normalize_text(row.get("branch_id"))
        ]

    def meta_branches_full(self) -> list[dict[str, Any]]:
        return self._cached_meta_rows(
            cache_key="meta_branches_full",
            endpoint="/meta/branches",
            payload_key="branches",
            normalizer=normalize_branch_payload,
            id_key="branch_id",
        )

    def _cached_meta_rows(
        self,
        *,
        cache_key: str,
        endpoint: str,
        payload_key: str,
        normalizer,
        id_key: str,
    ) -> list[dict[str, Any]]:

        def _load():
            data = self._request_json_optional(endpoint)
            items = data.get("items") or data.get(payload_key) or []
            return self._normalize_rows(items, normalizer, id_key)

        return list(self._cached(cache_key, self._metadata_cache_ttl(), _load))

    def meta_regions(self) -> list[dict[str, Any]]:
        return self._cached_meta_rows(
            cache_key="meta_regions",
            endpoint="/meta/regions",
            payload_key="regions",
            normalizer=normalize_region_payload,
            id_key="region_id",
        )

    def meta_areas(self) -> list[dict[str, Any]]:
        return self._cached_meta_rows(
            cache_key="meta_areas",
            endpoint="/meta/areas",
            payload_key="areas",
            normalizer=normalize_area_payload,
            id_key="area_id",
        )


import logging

logger = logging.getLogger(__name__)


class RemoteTrackingSyncMixin:

    def _sync_owner_allows(self, owner_token: str = "") -> bool:
        """Allow standalone mixin probes while honoring a real API reservation."""

        checker = getattr(self, "_is_local_sync_owner", None)
        return bool(checker(owner_token)) if callable(checker) else True

    def _sync_cursor_from_payload(self, data: dict[str, Any]) -> int:
        for key in (
            "cursor",
            "next_cursor",
            "last_cursor",
            "last_id",
            "event_id",
            "version",
        ):
            value = normalize_int(data.get(key))
            if value > 0:
                return value
        return 0

    def sync_pull_temporarily_disabled(self) -> bool:
        disabled_until = float(getattr(self, "_sync_pull_disabled_until", 0.0) or 0.0)
        return bool(disabled_until and time.monotonic() < disabled_until)

    def fetch_sync_bootstrap(
        self,
        *,
        branch_ids: list[str] | None = None,
        sync_owner: str = "",
    ) -> dict[str, Any]:
        """Fetch the atomic baseline reserved for the local sync owner."""

        if not self._sync_owner_allows(sync_owner):
            return {"delegated_to_local_sync": True}
        if not self._server_has_permission("sync.pull"):
            return {"permission_denied": True}
        branches = clean_string_list(branch_ids or [])
        params = {"branch_ids": ",".join(branches)} if branches else None
        try:
            data = self._safe_json(
                self._req(
                    "GET",
                    "/sync/bootstrap",
                    params=params,
                    optional_statuses={404, 405, 501},
                )
            )
        except SERVICE_OPERATION_EXCEPTIONS as exc:
            status_code = int(getattr(exc, "status_code", 0) or 0)
            if status_code in {404, 405, 501}:
                return {"sync_bootstrap_unavailable": True}
            raise
        return data if isinstance(data, dict) else {}

    def pull_sync_changes(
        self,
        branch_id: str | None = None,
        *,
        cursor: int | None = None,
        branch_ids: list[str] | None = None,
        sync_owner: str = "",
    ) -> dict[str, Any]:
        if not self._sync_owner_allows(sync_owner):
            return {
                "changes": [],
                "cursor": int(getattr(self, "_cursor", 0) or 0),
                "delegated_to_local_sync": True,
            }
        if not self._server_has_permission("sync.pull"):
            return {
                "changes": [],
                "cursor": int(getattr(self, "_cursor", 0) or 0),
                "permission_denied": True,
            }
        disabled_until = float(getattr(self, "_sync_pull_disabled_until", 0.0) or 0.0)
        if disabled_until and time.monotonic() < disabled_until:
            return {
                "changes": [],
                "cursor": int(getattr(self, "_cursor", 0) or 0),
                "sync_unavailable": True,
            }
        params: dict[str, Any] = {}
        branches = clean_string_list(branch_ids or [])
        branch_param = normalize_text(branch_id)
        if branch_param.lower() in {"all", "*"}:
            branch_param = ""
        if branch_param:
            params["branch_id"] = branch_param
        elif branches:
            params["branch_ids"] = ",".join(branches)
        if cursor is not None:
            params["since"] = normalize_int(cursor)
        try:
            data = self._safe_json(
                self._req(
                    "GET",
                    "/sync/pull",
                    params=params or None,
                    optional_statuses={404, 405, 501},
                )
            )
        except SERVICE_OPERATION_EXCEPTIONS as exc:
            status_code = int(getattr(exc, "status_code", 0) or 0)
            if status_code in {404, 405, 501}:
                self._sync_pull_disabled_until = time.monotonic() + 300.0
                if not bool(getattr(self, "_sync_pull_unavailable_logged", False)):
                    logger.info(
                        "/sync/pull is unavailable on this server; delta sync is disabled for 5 minutes."
                    )
                    self._sync_pull_unavailable_logged = True
                return {
                    "changes": [],
                    "cursor": int(getattr(self, "_cursor", 0) or 0),
                    "sync_unavailable": True,
                }
            raise
        if not isinstance(data, dict):
            return {}
        self._sync_pull_unavailable_logged = False
        self._sync_pull_disabled_until = 0.0
        return data

    def push_sync_changes(
        self, changes: list[dict[str, Any]], *, sync_owner: str = ""
    ) -> dict[str, Any]:
        if not self._sync_owner_allows(sync_owner):
            raise RuntimeError("The local sync coordinator owns server mutations.")
        self._require_server_permission("sync.push")
        pending = [item for item in list(changes or []) if isinstance(item, dict)]
        if not pending:
            return {"ok": True, "status": "ok", "results": [], "changes": []}

        combined_results: list[dict[str, Any]] = []
        server_time = ""
        overall_status = "ok"
        for offset in range(0, len(pending), 50):
            batch = pending[offset : offset + 50]
            data = self._safe_json(
                self._req("POST", "/sync/push", json={"changes": batch})
            )
            if not isinstance(data, dict):
                raise RuntimeError("Sync push returned an invalid server response.")
            batch_results = data.get("results") or data.get("changes") or []
            if isinstance(batch_results, list):
                combined_results.extend(
                    item for item in batch_results if isinstance(item, dict)
                )
            if str(data.get("status") or "ok").lower() != "ok":
                overall_status = str(data.get("status") or "error")
            server_time = str(data.get("server_time") or server_time)
            next_cursor = self._sync_cursor_from_payload(data)
            if next_cursor > 0:
                self._cursor = max(self._cursor, next_cursor)

        if combined_results:
            self.invalidate_tracking_cache()
        return {
            "ok": overall_status == "ok",
            "status": overall_status,
            "results": combined_results,
            "changes": combined_results,
            "server_time": server_time,
        }

    def set_sync_cursor(self, cursor: int | str | None) -> None:
        self._cursor = max(0, normalize_int(cursor))

    def sync_cursor(self) -> int:
        return max(0, int(getattr(self, "_cursor", 0) or 0))

class RemoteApiTrackingMixin(
    RemoteTrackingMetadataMixin,
    RemoteTrackingSyncMixin,
):
    """Composition surface for tracking-related remote API responsibilities."""
