from __future__ import annotations
import logging
from settings.config import _
from PyQt5.QtWidgets import QAction
from ui.common_widgets import set_menu_action_icon
from core.booleans import parse_bool
from ui.dialogs.notifications_dialog import NotificationsDialog
from ui.common_widgets import set_widget_enabled
from PyQt5.QtWidgets import QMenu, QSystemTrayIcon
from settings.config import APP_DISPLAY_NAME
from core.signals import safe_disconnect
from ui.common_widgets import tray_icon_or_fallback

logger = logging.getLogger(__name__)


class MainWindowNotificationsMixin:

    @staticmethod
    def _notification_to_dict(item):
        return {
            "id": item.id,
            "kind": item.kind,
            "title": item.title,
            "message": item.message,
            "severity": item.severity,
            "created_at": item.created_at.isoformat(),
            "read": item.read_at is not None,
            "action_type": item.action_type,
            "action_payload": dict(item.action_payload or {}),
        }

    def _current_notification_items(self):
        service = getattr(self, "persistent_notifications", None)
        if service is None:
            return []
        try:
            return [self._notification_to_dict(item) for item in service.list_current()]
        except PermissionError:
            return []

    def _hide_notifications_panel(self):
        panel = getattr(self, "_notifications_dialog", None)
        if panel is not None:
            try:
                panel.hide_panel()
            except (AttributeError, RuntimeError, TypeError, ValueError):
                panel.hide()

    def _refresh_notifications_ui(self, items=None) -> None:
        data = self._current_notification_items() if items is None else list(items or [])
        service = getattr(self, "persistent_notifications", None)
        count = service.unread_count() if service is not None else 0
        self.unread_notifications = int(count)
        try:
            if getattr(self, "notifications_service", None) is not None:
                self.notifications_service.update_badge()
        except (AttributeError, RuntimeError, TypeError, ValueError):
            logger.exception("Failed to refresh notification badge")
        dialog = getattr(self, "_notifications_dialog", None)
        if dialog is not None:
            dialog.set_notifications(data)

    def _sync_notifications_panel_direction(self) -> None:
        panel = getattr(self, "_notifications_dialog", None)
        if panel is not None and hasattr(panel, "apply_language_layout"):
            panel.apply_language_layout()

    def _set_notifications_enabled(self, enabled: bool) -> None:
        set_widget_enabled(getattr(self, "btn_notifications", None), enabled)

    def on_show_notifications(self):
        if (
            not getattr(self, "btn_notifications", None)
            or not self.btn_notifications.isEnabled()
        ):
            return
        panel = getattr(self, "_notifications_dialog", None)
        if panel is None:
            panel = NotificationsDialog(self)
            panel.mark_all_requested.connect(self.mark_all_notifications_read)
            panel.clear_all_requested.connect(self.clear_notifications)
            panel.mark_one_requested.connect(self.mark_notification_read)
            self._notifications_dialog = panel
        self._sync_notifications_panel_direction()
        if panel.isVisible():
            panel.hide_panel()
            return
        panel.set_notifications(self._current_notification_items())
        panel.show_near(getattr(self, "notif_wrap", self.btn_notifications))

    def mark_notification_read(self, index: int):
        items = self._current_notification_items()
        idx = int(index)
        if idx < 0 or idx >= len(items):
            return
        service = getattr(self, "persistent_notifications", None)
        if service is not None:
            service.mark_read(str(items[idx]["id"]))
        self._refresh_notifications_ui()

    def mark_all_notifications_read(self):
        service = getattr(self, "persistent_notifications", None)
        if service is not None:
            service.mark_all_read()
        self._refresh_notifications_ui()

    def clear_notifications(self):
        service = getattr(self, "persistent_notifications", None)
        if service is None:
            self._refresh_notifications_ui([])
            return
        for item in service.list_current():
            service.delete(item.id)
        self._refresh_notifications_ui([])


class MainWindowTrayMixin:

    def _should_keep_running_in_tray_on_close(self) -> bool:
        try:
            return parse_bool(
                self.db_manager.get_setting("enable_tray_background", "False"), False
            )
        except (AttributeError, RuntimeError, TypeError, ValueError):
            return False

    def _is_tray_enabled(self) -> bool:
        try:
            tray_background = parse_bool(
                self.db_manager.get_setting("enable_tray_background", "False"), False
            )
            desktop_alerts = parse_bool(
                self.db_manager.get_setting("enable_desktop_notifications", "True"),
                True,
            )
            return bool(tray_background or desktop_alerts)
        except (AttributeError, RuntimeError, TypeError, ValueError):
            return False

    def _destroy_tray_icon(self):
        tray = getattr(self, "tray_icon", None)
        if tray is None:
            return
        safe_disconnect(
            tray.activated,
            self.on_tray_icon_activated,
            logger_=logger,
            context="MainWindowUiMixin._destroy_tray_icon disconnect",
        )
        try:
            tray.hide()
            tray.setVisible(False)
        except (AttributeError, RuntimeError, TypeError, ValueError):
            logger.debug(
                "MainWindowUiMixin._destroy_tray_icon hide failed", exc_info=True
            )
        try:
            tray.setContextMenu(None)
        except (AttributeError, RuntimeError, TypeError, ValueError):
            logger.debug(
                "MainWindowUiMixin._destroy_tray_icon clear menu failed", exc_info=True
            )
        try:
            tray.deleteLater()
        except (AttributeError, RuntimeError, TypeError, ValueError):
            logger.debug(
                "MainWindowUiMixin._destroy_tray_icon deleteLater failed", exc_info=True
            )
        try:
            tray_menu = getattr(self, "_tray_menu", None)
            if tray_menu is not None:
                tray_menu.clear()
                tray_menu.deleteLater()
        except (AttributeError, RuntimeError, TypeError, ValueError):
            logger.debug(
                "MainWindowUiMixin._destroy_tray_icon menu cleanup failed",
                exc_info=True,
            )
        self._tray_menu = None
        self.tray_icon = None

    def _ensure_tray_icon(self):
        if getattr(self, "tray_icon", None) is None:
            self.init_tray_icon()
        return getattr(self, "tray_icon", None)

    def _show_tray_icon(self) -> bool:
        try:
            tray = self._ensure_tray_icon()
            if tray is None:
                return False
            tray.show()
            tray.setVisible(True)
            return True
        except (AttributeError, RuntimeError, TypeError, ValueError):
            logger.debug("MainWindowUiMixin._show_tray_icon failed", exc_info=True)
            return False

    def _minimize_to_tray(self, *, show_message: bool = True) -> bool:
        tray = self._ensure_tray_icon()
        if tray is None:
            return False
        try:
            tray.show()
            tray.setVisible(True)
            self.hide()
            self._apply_monitor_schedule(restart=bool(self.app_state.session))
            if show_message and parse_bool(
                self.db_manager.get_setting("tray_show_message_on_minimize", "False"),
                False,
            ):
                tray.showMessage(
                    APP_DISPLAY_NAME,
                    _("App is running in background."),
                    QSystemTrayIcon.Information,
                    2500,
                )
            return True
        except (AttributeError, RuntimeError, TypeError, ValueError):
            logger.debug("MainWindowUiMixin._minimize_to_tray failed", exc_info=True)
            return False

    def init_tray_icon(self):
        self._destroy_tray_icon()
        if not self._is_tray_enabled():
            return
        try:
            if not QSystemTrayIcon.isSystemTrayAvailable():
                logger.warning("System tray is not available on this environment")
                return
        except (AttributeError, RuntimeError, TypeError, ValueError):
            return
        self.tray_icon = QSystemTrayIcon(self)
        self.tray_icon.setIcon(tray_icon_or_fallback(self))
        self.tray_icon.setToolTip(APP_DISPLAY_NAME)
        self._tray_menu = QMenu(self)
        show_act = QAction(_("Home"), self)
        set_menu_action_icon(show_act, "home.png")
        show_act.triggered.connect(self._restore_from_tray)
        self._tray_menu.addAction(show_act)
        exit_act = QAction(_("Exit"), self)
        set_menu_action_icon(exit_act, "exit.png")
        exit_act.triggered.connect(getattr(self, "close_app_completely", self.close))
        self._tray_menu.addAction(exit_act)
        self.tray_icon.setContextMenu(self._tray_menu)
        self.tray_icon.activated.connect(self.on_tray_icon_activated)
        try:
            self.tray_icon.hide()
        except (AttributeError, RuntimeError, TypeError, ValueError):
            logger.debug(
                "MainWindowUiMixin.init_tray_icon fallback failed", exc_info=True
            )

    def refresh_tray_icon(self):
        try:
            self.init_tray_icon()
        except (AttributeError, RuntimeError, TypeError, ValueError):
            logger.exception("refresh_tray_icon failed")

    def _bring_to_front(self, *, show_if_hidden: bool = False) -> None:
        try:
            if self.isMinimized():
                self.showNormal()
            elif show_if_hidden and (not self.isVisible()):
                self.show()
            if show_if_hidden and (not self.isVisible()):
                self.setVisible(True)
            self.raise_()
            self.activateWindow()
        except (AttributeError, RuntimeError, TypeError, ValueError):
            logger.debug(
                "MainWindowUiMixin._bring_to_front fallback failed", exc_info=True
            )

    def _restore_from_tray(self):
        self._bring_to_front(show_if_hidden=True)
        try:
            if getattr(self, "tray_icon", None) is not None:
                self.tray_icon.hide()
        except (AttributeError, RuntimeError, TypeError, ValueError):
            logger.debug(
                "MainWindowUiMixin._restore_from_tray fallback failed", exc_info=True
            )
        try:
            self._apply_monitor_schedule(restart=bool(self.app_state.session))
        except (AttributeError, RuntimeError, TypeError, ValueError):
            logger.debug(
                "MainWindowUiMixin._restore_from_tray fallback failed", exc_info=True
            )

    def on_tray_icon_activated(self, reason):
        if reason in (QSystemTrayIcon.Trigger, QSystemTrayIcon.DoubleClick):
            self._restore_from_tray()
