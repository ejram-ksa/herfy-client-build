from __future__ import annotations
import logging
from core.errors import UI_OPERATION_EXCEPTIONS
from datetime import date, datetime, timedelta
from core.booleans import parse_bool
from services.monitoring_engine import MonitoringAlertService, MonitoringEngine
from services.tracking_store import tracking_store
from services.expiry_status import ExpiryThresholds

logger = logging.getLogger(__name__)


class MainWindowMonitoringMixin:
    _expiry_token = 0

    def _compute_monitor_interval_minutes(self) -> int:
        try:
            active_mins = min(
                1440,
                max(
                    5,
                    int(
                        self.db_manager.get_setting(
                            "monitoring_active_check_interval_minutes", "15"
                        )
                    ),
                ),
            )
        except UI_OPERATION_EXCEPTIONS:
            active_mins = 30
        try:
            background_mins = min(
                1440,
                max(
                    active_mins,
                    int(
                        self.db_manager.get_setting(
                            "monitoring_background_check_interval_minutes",
                            str(max(active_mins, 30)),
                        )
                    ),
                ),
            )
        except UI_OPERATION_EXCEPTIONS:
            background_mins = max(active_mins, 30)
        hidden = self.isHidden() or not self.isVisible()
        return background_mins if hidden else active_mins

    def _apply_monitor_schedule(self, *, restart: bool = True):
        try:
            mins = self._compute_monitor_interval_minutes()
            self.check_interval_timer.setInterval(max(5, mins) * 60 * 1000)
            if restart:
                self.check_interval_timer.start()
        except UI_OPERATION_EXCEPTIONS:
            logger.exception("Failed to apply monitor schedule")

    def set_daily_timer(self):
        """Set daily timer."""
        now_ = datetime.now()
        tomorrow_ = date.today() + timedelta(days=1)
        mid_ = datetime.combine(tomorrow_, datetime.min.time())
        ms_ = int((mid_ - now_).total_seconds() * 1000)
        self.daily_timer.setSingleShot(True)
        self.daily_timer.start(ms_)

    def update_daily(self):
        """Update daily."""
        self.check_expiry()
        self._sync_notifications_panel_direction()
        self.set_daily_timer()

    def load_tracked_products(
        self, preloaded: list | None = None, show_busy: bool = True
    ):
        """Compatibility shim; monitoring must not reload Tracking UI."""
        del preloaded, show_busy
        self.check_expiry()

    def check_expiry(
        self, preloaded: list | None = None, *, allow_network: bool = False
    ):
        del allow_network  # Compatibility flag; monitoring uses the local synchronized store.
        try:
            if not parse_bool(
                self.db_manager.get_setting("enable_alerts", "True"), True
            ):
                return
            if getattr(self, "_expiry_running", False):
                return
            self._expiry_running = True
            self._expiry_token += 1
            token = self._expiry_token
            thresholds = ExpiryThresholds.from_settings(self.db_manager)

            def _fetch_all(progress_callback=None):
                del progress_callback
                return tracking_store.snapshot()

            self._start_logged_worker(
                _fetch_all,
                on_result=lambda res: self._on_expiry_result(token, res, thresholds),
                on_finished=lambda: self._on_expiry_finished(token),
                error_handler=lambda msg: logging.error("check_expiry worker: %s", msg),
                operation_key="expiry_check",
            )
        except UI_OPERATION_EXCEPTIONS as e:
            logging.error("check_expiry start error: %s", e)
            self._expiry_running = False

    def _on_expiry_result(self, token: int, snapshot, thresholds: ExpiryThresholds):
        if token != getattr(self, "_expiry_token", 0):
            return
        records = tuple(getattr(snapshot, "records", ()) or ())
        engine = getattr(self, "_monitoring_engine", None)
        if engine is None:
            engine = MonitoringEngine()
            self._monitoring_engine = engine
        transitions = engine.evaluate(
            records=records,
            now=datetime.now(),
            policy=thresholds,
        )
        notification_engine = getattr(self.notifications_service, "engine", None)
        alert_service = getattr(self, "_monitoring_alert_service", None)
        if (
            alert_service is None
            or getattr(alert_service, "_notification_engine", None)
            is not notification_engine
        ):
            alert_service = MonitoringAlertService(notification_engine)
            self._monitoring_alert_service = alert_service
        self.notifications_service.publish_alerts(
            alert_service.events_from_transitions(transitions)
        )

    def _on_expiry_finished(self, token: int):
        if token != getattr(self, "_expiry_token", 0):
            return
        self._expiry_running = False
