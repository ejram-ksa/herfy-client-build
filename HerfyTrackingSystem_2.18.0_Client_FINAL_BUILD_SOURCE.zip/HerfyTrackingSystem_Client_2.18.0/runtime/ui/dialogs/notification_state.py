from __future__ import annotations
import logging
import threading
import time
from typing import Any
from core.errors import SERVICE_OPERATION_EXCEPTIONS
from services.notification_service import NotificationEngine

logger = logging.getLogger(__name__)


class NotificationDuplicateGuard:

    def __init__(self, *, stale_after_seconds: float = 900.0) -> None:
        self._recent_messages: dict[str, float] = {}
        self._lock = threading.RLock()
        self._stale_after_seconds = max(1.0, float(stale_after_seconds))

    def prune(self) -> None:
        cutoff = time.monotonic() - self._stale_after_seconds
        with self._lock:
            stale = [key for key, ts in self._recent_messages.items() if ts < cutoff]
            for key in stale:
                self._recent_messages.pop(key, None)

    def mark_recent(self, key: str, *, ttl_seconds: float = 60.0) -> bool:
        key = str(key or "").strip().lower()
        if not key:
            return True
        now = time.monotonic()
        self.prune()
        with self._lock:
            last = self._recent_messages.get(key, 0.0)
            if now - last < max(1.0, float(ttl_seconds)):
                return False
            self._recent_messages[key] = now
        return True

    def clear(self) -> None:
        with self._lock:
            self._recent_messages.clear()


class NotificationHistoryStore:

    def __init__(
        self, main_window: Any, engine: NotificationEngine, *, max_items: int = 500
    ) -> None:
        self.main_window = main_window
        self.engine = engine
        self.max_items = int(max_items)

    def history_key(self, entry: dict | None) -> str:
        return self.engine.history_key(entry)

    def record_entries(self, entries: list[dict]) -> bool:
        if not entries:
            return False
        from datetime import datetime
        import uuid
        from domain.notification_models import AppNotification

        service = getattr(self.main_window, "persistent_notifications", None)
        if service is None:
            raise RuntimeError("PersistentNotificationService is not initialized")
        inserted_any = False
        for entry in entries:
            key = self.history_key(entry)
            if not key:
                continue
            created_raw = str(entry.get("created_at") or "")
            try:
                created_at = datetime.fromisoformat(created_raw) if created_raw else datetime.now().astimezone()
            except ValueError:
                created_at = datetime.now().astimezone()
            user_id = str(
                getattr(getattr(self.main_window.app_state, "current_user", None), "uid", "") or ""
            ).strip()
            if not user_id:
                continue
            item = AppNotification(
                id=str(entry.get("id") or uuid.uuid4()),
                user_id=user_id,
                kind=str(entry.get("kind") or "expiry"),
                title=str(entry.get("title") or ""),
                message=str(entry.get("message") or entry.get("full_message") or ""),
                severity=str(entry.get("severity") or entry.get("status") or "info"),
                created_at=created_at,
                read_at=None,
                deduplication_key=key,
                action_type=str(entry.get("action_type") or "") or None,
                action_payload=dict(entry.get("action_payload") or {}),
                expires_at=None,
            )
            inserted_any = service.add(item) or inserted_any
        return inserted_any

    def clear_runtime_items(self) -> None:
        service = getattr(self.main_window, "persistent_notifications", None)
        if service is not None:
            service.clear_current_view()

