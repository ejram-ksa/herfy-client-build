from __future__ import annotations

from core.numbers import parse_plain_number
from core.objects import normalize_int
from .sound import SoundNotifier
from .notification_state import NotificationDuplicateGuard, NotificationHistoryStore
from .notification_queue import DesktopNotificationQueue
from .notification_badge import NotificationBadgeUpdater
from .desktop_notifier import DesktopNotifier
import logging
import time
from datetime import datetime
from settings.config import _
from core.booleans import setting_bool
from core.errors import SERVICE_OPERATION_EXCEPTIONS
from services.notification_service import NotificationEngine
from services.preferences import SettingsService
from services.reminders import (
    ToastRateLimiter,
    branch_is_allowed,
    build_reminder_thresholds,
    is_quiet_hours,
    threshold_reached,
)

logger = logging.getLogger(__name__)


class NotificationService:

    def __init__(self, main_window):
        self.main_window = main_window
        self.desktop_notifier = DesktopNotifier(main_window)
        self.sound_notifier = SoundNotifier(self._get_setting)
        self.engine = NotificationEngine()
        self.duplicate_guard = NotificationDuplicateGuard()
        self._toast_rate_limiter = ToastRateLimiter()
        self.badge_updater = NotificationBadgeUpdater(main_window)
        self.history_store = NotificationHistoryStore(
            main_window, self.engine, max_items=500
        )
        self.desktop_queue = DesktopNotificationQueue(
            main_window,
            get_bool=self._get_bool,
            show_tray_message=self.desktop_notifier.show_tray_message,
            show_card_notification=self.desktop_notifier.show_card_notification,
            show_native_notification=self.desktop_notifier.show_native_notification,
            play_sound=self.sound_notifier.play,
        )

    def _identity_scope(self) -> tuple[str, str, list[str], bool]:
        state = getattr(self.main_window, "app_state", None)
        profile = getattr(state, "current_user", None)
        session = getattr(state, "session", None)
        user_id = str(
            getattr(profile, "uid", "")
            or getattr(profile, "username", "")
            or ""
        ).strip()
        device_id = str(getattr(session, "device_id", "") or "").strip()
        context = getattr(profile, "permission_context", None)
        scope = getattr(context, "scope", None)
        branches = list(
            getattr(scope, "branches", None)
            or getattr(profile, "branches", None)
            or []
        )
        all_branches = bool(getattr(scope, "all_branches", False))
        return user_id, device_id, branches, all_branches

    def _get_setting(self, key: str, default=None):
        try:
            db = self.main_window.db_manager
            if key in SettingsService.USER_DEVICE_SETTING_KEYS:
                user_id, device_id, _branches, _all = self._identity_scope()
                reader = getattr(db, "user_device_setting", None)
                if user_id and device_id and callable(reader):
                    return reader(user_id, device_id, key, default)
            return db.get_setting(key, default)
        except SERVICE_OPERATION_EXCEPTIONS:
            return default

    def _get_bool(self, key: str, default: bool = False) -> bool:
        try:
            return setting_bool(self._get_setting, key, default)
        except SERVICE_OPERATION_EXCEPTIONS:
            return bool(default)

    def _get_int(self, key: str, default: int) -> int:
        try:
            return int(self._get_setting(key, str(default)))
        except SERVICE_OPERATION_EXCEPTIONS:
            return default

    def _quiet_now(self) -> bool:
        return is_quiet_hours(
            enabled=self._get_bool("quiet_hours_enabled", False),
            start=str(self._get_setting("quiet_hours_start", "22:00") or "22:00"),
            end=str(self._get_setting("quiet_hours_end", "07:00") or "07:00"),
        )

    def _reminder_key_for_event(self, event: dict) -> dict | None:
        user_id, device_id, branches, all_branches = self._identity_scope()
        branch_id = str(
            event.get("branch_id") or event.get("branch") or event.get("store") or ""
        ).strip()
        if not user_id or not device_id:
            return None
        if not branch_is_allowed(
            branch_id, scope_branches=branches, all_branches=all_branches
        ):
            return None
        days_left = normalize_int(event.get("days_remaining"), 0)
        thresholds = build_reminder_thresholds(
            self._get_setting("first_reminder_days", "30")
        )
        threshold = threshold_reached(days_left, thresholds)
        if threshold is None:
            return None
        expiry_date = str(event.get("expiry_date") or "").strip()[:10]
        item_id = str(
            event.get("item_id")
            or event.get("id")
            or "|".join(
                [
                    str(event.get("material_number") or "").strip(),
                    str(event.get("production_date") or "").strip(),
                    expiry_date,
                ]
            )
        ).strip()
        if not item_id or not expiry_date:
            return None
        return {
            "user_id": user_id,
            "device_id": device_id,
            "item_id": item_id,
            "branch_id": branch_id,
            "threshold_days": int(threshold),
            "expiry_date": expiry_date,
        }

    def _mark_reminder_keys(self, keys: list[dict]) -> bool:
        db = self.main_window.db_manager
        marker = getattr(db, "mark_reminder_shown", None)
        checker = getattr(db, "reminder_was_shown", None)
        if not callable(marker):
            return True
        inserted_any = False
        for key in keys:
            try:
                if callable(checker) and checker(**key):
                    continue
                inserted_any = bool(marker(**key)) or inserted_any
            except SERVICE_OPERATION_EXCEPTIONS:
                logger.exception("Unable to persist reminder deduplication key")
        return inserted_any

    def _enqueue_desktop_notification(
        self,
        *,
        title: str,
        message: str,
        duration_s: int,
        status: str = "",
        entry: dict | None = None,
    ) -> None:
        self.desktop_queue.enqueue(
            title=title,
            message=message,
            duration_s=duration_s,
            status=status,
            entry=entry,
        )

    def _dispatch_popup(
        self,
        title: str,
        short_msg: str,
        full_msg: str,
        status: str,
        dedupe_key: str,
        entry: dict | None = None,
        reminder_keys: list[dict] | None = None,
    ):
        if not self._get_bool("notifications_enabled", True) or self._quiet_now():
            return
        if not self._toast_rate_limiter.allow(
            self._get_int("max_toasts_per_minute", 3),
            monotonic_now=time.monotonic(),
        ):
            logger.info("Notification suppressed by per-minute rate limit")
            return
        keys = list(reminder_keys or [])
        if keys and not self._mark_reminder_keys(keys):
            return
        dur_s = min(30, max(3, self._get_int("notification_duration_seconds", 8)))
        if not self.duplicate_guard.mark_recent(
            f"popup|{dedupe_key}", ttl_seconds=10.0
        ):
            return
        message = str(full_msg or short_msg or "").strip()
        self._enqueue_desktop_notification(
            title=title, message=message, duration_s=dur_s, status=status, entry=entry
        )

    def _record_history_entries(self, entries: list[dict]) -> None:
        if not entries:
            return
        changed = self.history_store.record_entries(list(entries or []))
        if changed:
            self.badge_updater.update()

    def _evaluate_event(self, event: dict) -> tuple[bool, dict]:
        db = self.main_window.db_manager
        key = self.engine.alert_key(event)
        now_ts = time.time()
        today = datetime.now().strftime("%Y-%m-%d")
        repeat_minutes = min(
            1440,
            max(15, self._get_int("notification_repeat_interval_minutes", 240)),
        )
        cooldown = repeat_minutes * 60
        once_per_day = self._get_bool("notification_once_per_day", True)
        state = db.get_alert_state(key) or {}
        ledger = (
            db.get_notification_ledger(key)
            if hasattr(db, "get_notification_ledger")
            else {}
        )
        fp = self.engine.fingerprint(event)
        rank = normalize_int(event.get("severity_rank"), 0)
        last_fp = str(state.get("fingerprint") or "")
        last_rank = normalize_int(state.get("severity_rank"), 0)
        last_date = str(state.get("last_date") or "")
        ledger_fp = str(ledger.get("last_payload_hash") or "")
        ledger_rank = normalize_int(ledger.get("severity"), 0)
        ledger_date = str(ledger.get("last_shown_at") or "")[:10]
        last_notified_at = parse_plain_number(state.get("last_notified_at"))
        notify_count = normalize_int(state.get("notify_count"), 0)
        changed = fp != (ledger_fp or last_fp)
        escalated = rank > max(last_rank, ledger_rank)
        cooldown_elapsed = now_ts - last_notified_at >= cooldown
        should_notify = not state or changed or escalated or cooldown_elapsed
        already_today = last_date == today or ledger_date == today
        if once_per_day and already_today and (not changed) and (not escalated):
            should_notify = False
        db.set_alert_state(
            key,
            last_date=today if should_notify else last_date,
            last_notified_at=now_ts if should_notify else last_notified_at,
            last_seen_at=now_ts,
            fingerprint=fp,
            severity_rank=rank,
            status_text=str(event.get("status") or ""),
            notify_count=notify_count + 1 if should_notify else notify_count,
        )
        if should_notify and hasattr(db, "record_notification_ledger"):
            db.record_notification_ledger(
                key,
                state=self.engine.normalized_kind(event),
                severity=rank,
                payload_hash=fp,
            )
        return (should_notify, {"key": key, "changed": changed, "escalated": escalated})

    def publish_alerts(self, alerts: list[dict]) -> None:
        if (
            not alerts
            or not self._get_bool("notifications_enabled", True)
            or self._quiet_now()
        ):
            return
        notify_candidates: list[dict] = []
        history_entries: list[dict] = []
        for event in alerts:
            if not isinstance(event, dict):
                continue
            if not self.engine.is_notifiable_source(event):
                continue
            if not self.engine.is_notifiable_status(event):
                continue
            key = self.engine.alert_key(event)
            if not key:
                continue
            reminder_key = self._reminder_key_for_event(event)
            if reminder_key is None:
                continue
            checker = getattr(
                self.main_window.db_manager, "reminder_was_shown", None
            )
            if callable(checker):
                try:
                    if checker(**reminder_key):
                        continue
                except SERVICE_OPERATION_EXCEPTIONS:
                    logger.exception("Reminder deduplication lookup failed")
            should_notify, _reason = self._evaluate_event(event)
            if should_notify:
                prepared = dict(event)
                prepared["_reminder_key"] = reminder_key
                notify_candidates.append(prepared)
                history_entries.append(self.engine.history_entry(event))
        self._record_history_entries(history_entries)
        if not notify_candidates:
            return
        notify_candidates.sort(key=self.engine.sort_key, reverse=True)
        smart_enabled = self._get_bool("enable_smart_notifications", True)
        summary_threshold = min(
            50, max(2, self._get_int("notification_summary_threshold", 3))
        )
        max_per_cycle = min(20, max(1, self._get_int("notification_max_per_cycle", 5)))
        branches = {
            str(event.get("branch") or "").strip().lower()
            for event in notify_candidates
            if str(event.get("branch") or "").strip()
        }
        if smart_enabled and (
            len(notify_candidates) >= summary_threshold or len(branches) > 1
        ):
            self._dispatch_summary(notify_candidates)
            return
        urgent_events = [
            event
            for event in notify_candidates
            if not self.engine.is_summary_preferred(event)
        ]
        soon_events = [
            event
            for event in notify_candidates
            if self.engine.is_summary_preferred(event)
        ]
        dispatched = 0
        for event in urgent_events[:max_per_cycle]:
            self._dispatch_detail(event)
            dispatched += 1
        remaining_urgent = urgent_events[max_per_cycle:]
        if remaining_urgent:
            self._dispatch_summary(
                remaining_urgent,
                prefix_count=len(remaining_urgent),
                title_override=_("More urgent alerts"),
            )
            return
        remaining_slots = max(0, max_per_cycle - dispatched)
        if not soon_events or remaining_slots <= 0:
            return
        if smart_enabled and len(soon_events) >= summary_threshold:
            self._dispatch_summary(soon_events)
            return
        for event in soon_events[:remaining_slots]:
            self._dispatch_detail(event)
            dispatched += 1
        remaining_soon = soon_events[remaining_slots:]
        if remaining_soon:
            self._dispatch_summary(
                remaining_soon,
                prefix_count=len(remaining_soon),
                title_override=_("More alerts"),
            )

    def _dispatch_detail(self, event: dict) -> None:
        title = _("Products expiration tracking")
        short_msg = f"{event.get('product_name') or event.get('display_product') or ''} - {event.get('status') or ''}".strip(
            " -"
        )
        self._dispatch_popup(
            title,
            short_msg,
            str(event.get("message") or short_msg),
            str(event.get("status") or ""),
            self.engine.alert_key(event),
            entry=self.engine.history_entry(event),
            reminder_keys=[event["_reminder_key"]]
            if isinstance(event.get("_reminder_key"), dict)
            else [],
        )

    def _dispatch_summary(
        self,
        events: list[dict],
        *,
        prefix_count: int | None = None,
        title_override: str | None = None,
    ) -> None:
        if not events:
            return
        critical = sum(
            (1 for ev in events if normalize_int(ev.get("severity_rank"), 0) >= 4)
        )
        warning = sum(
            (1 for ev in events if normalize_int(ev.get("severity_rank"), 0) == 3)
        )
        expired = sum(
            (1 for ev in events if "expired" in str(ev.get("status") or "").lower())
        )
        total = int(prefix_count or len(events))
        title = str(title_override or _("Products expiration tracking"))
        parts = [
            (
                f"{total} {_('food items need attention')}"
                if total != 1
                else f"1 {_('food item needs attention')}"
            )
        ]
        if expired:
            parts.append(f"{_('Expired')}: {expired}")
        if critical:
            parts.append(f"{_('Critical')}: {critical}")
        if warning:
            parts.append(f"{_('Expiring Soon')}: {warning}")
        lead_names = [
            str(ev.get("display_product") or ev.get("product_name") or "").strip()
            for ev in events[:3]
            if str(ev.get("display_product") or ev.get("product_name") or "").strip()
        ]
        summary = " | ".join(parts)
        branches = [
            str(ev.get("branch") or "").strip()
            for ev in events
            if str(ev.get("branch") or "").strip()
        ]
        if branches:
            unique_branches = list(dict.fromkeys(branches))[:6]
            stores = [
                (
                    branch
                    if branch.upper().startswith("H")
                    else f"H{branch}" if branch.isdigit() else branch
                )
                for branch in unique_branches
            ]
            summary += "\n" + f"{_('Stores')}: " + ", ".join(stores)
        if lead_names:
            summary += "\n" + ", ".join(lead_names)
        self._dispatch_popup(
            title,
            summary.split("\n", 1)[0],
            summary,
            "warning",
            f"summary|{','.join(lead_names)}|{total}",
            entry={
                "status_label": _("Summary"),
                "days_text": str(total),
                "message": summary,
                "branch": str(events[0].get("branch") or "") if events else "",
            },
            reminder_keys=[
                dict(event["_reminder_key"])
                for event in events
                if isinstance(event.get("_reminder_key"), dict)
            ],
        )

    def reset_runtime_state(self, *, clear_history: bool = True) -> None:
        self._toast_rate_limiter.clear()
        try:
            self.duplicate_guard.clear()
        except SERVICE_OPERATION_EXCEPTIONS:
            logger.debug("Failed to clear notification duplicate guard", exc_info=True)
        try:
            self.desktop_queue.clear()
        except SERVICE_OPERATION_EXCEPTIONS:
            logger.debug("Failed to clear notification desktop queue", exc_info=True)
        if clear_history:
            try:
                self.history_store.clear_runtime_items()
            except SERVICE_OPERATION_EXCEPTIONS:
                logger.debug("Failed to clear notification history", exc_info=True)
        self.update_badge()

    def close(self) -> None:
        """Stop all notification delivery resources owned by this service."""
        try:
            self.desktop_queue.close()
        except SERVICE_OPERATION_EXCEPTIONS:
            logger.debug("Desktop notification queue close failed", exc_info=True)
        try:
            self.desktop_notifier.close()
        except SERVICE_OPERATION_EXCEPTIONS:
            logger.debug("Desktop notifier close failed", exc_info=True)
        try:
            self.sound_notifier.stop()
        except SERVICE_OPERATION_EXCEPTIONS:
            logger.debug("Notification sound stop failed", exc_info=True)

    def update_badge(self):
        """Update badge."""
        self.badge_updater.update()
