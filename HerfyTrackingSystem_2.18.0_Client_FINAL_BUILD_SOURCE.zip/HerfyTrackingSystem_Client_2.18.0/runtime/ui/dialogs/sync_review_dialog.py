from __future__ import annotations

from collections.abc import Callable
from typing import Any

from PyQt5.QtCore import Qt
from PyQt5.QtWidgets import (
    QDialog,
    QDialogButtonBox,
    QHBoxLayout,
    QLabel,
    QMessageBox,
    QPushButton,
    QTreeWidget,
    QTreeWidgetItem,
    QVBoxLayout,
)

from settings.config import _


class SyncReviewDialog(QDialog):
    """Small, deliberate resolution surface for blocked local-first operations."""

    def __init__(
        self,
        parent=None,
        *,
        operations: list[dict[str, Any]],
        on_discard: Callable[[str], bool],
        reload_operations: Callable[[], list[dict[str, Any]]],
    ) -> None:
        super().__init__(parent)
        self._operations = list(operations or [])
        self._on_discard = on_discard
        self._reload_operations = reload_operations
        self.setObjectName("SyncReviewDialog")
        self.setWindowTitle(_("Sync issues"))
        self.setMinimumWidth(680)

        layout = QVBoxLayout(self)
        hint = QLabel(
            _("Discard selected local change and fetch the server version?"), self
        )
        hint.setWordWrap(True)
        layout.addWidget(hint)

        self.list = QTreeWidget(self)
        self.list.setObjectName("SyncReviewList")
        self.list.setHeaderLabels([_("Sync operation"), _("Entity"), _("Issue")])
        self.list.setRootIsDecorated(False)
        self.list.setAlternatingRowColors(True)
        self.list.itemSelectionChanged.connect(self._update_actions)
        layout.addWidget(self.list, 1)

        actions = QHBoxLayout()
        self.refresh_button = QPushButton(_("Refresh from server"), self)
        self.refresh_button.clicked.connect(self._reload)
        actions.addWidget(self.refresh_button)
        actions.addStretch(1)
        self.discard_button = QPushButton(_("Discard local change"), self)
        self.discard_button.clicked.connect(self._discard_selected)
        actions.addWidget(self.discard_button)
        layout.addLayout(actions)

        buttons = QDialogButtonBox(QDialogButtonBox.Close, parent=self)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)
        self._populate(self._operations)

    def _populate(self, operations: list[dict[str, Any]]) -> None:
        self._operations = list(operations or [])
        self.list.clear()
        for operation in self._operations:
            entity_type = str(operation.get("entity_type") or "").strip()
            entity_id = str(operation.get("entity_id") or "").strip()
            action = str(operation.get("action") or "upsert").strip()
            status = str(operation.get("status") or "").strip()
            error = str(operation.get("last_error") or "").strip()
            item = QTreeWidgetItem(
                [f"{action} · {status}", f"{entity_type}: {entity_id}", error]
            )
            item.setData(0, Qt.UserRole, str(operation.get("operation_id") or ""))
            self.list.addTopLevelItem(item)
        if self.list.topLevelItemCount():
            self.list.setCurrentItem(self.list.topLevelItem(0))
            self.list.resizeColumnToContents(0)
            self.list.resizeColumnToContents(1)
        else:
            empty = QTreeWidgetItem([_("No blocked operations."), "", ""])
            empty.setFlags(Qt.NoItemFlags)
            self.list.addTopLevelItem(empty)
        self._update_actions()

    def _selected_operation_id(self) -> str:
        item = self.list.currentItem()
        return str(item.data(0, Qt.UserRole) or "") if item is not None else ""

    def _update_actions(self) -> None:
        self.discard_button.setEnabled(bool(self._selected_operation_id()))

    def _reload(self) -> None:
        self._populate(list(self._reload_operations() or []))

    def _discard_selected(self) -> None:
        operation_id = self._selected_operation_id()
        if not operation_id:
            return
        answer = QMessageBox.question(
            self,
            _("Sync issues"),
            _("Discard selected local change and fetch the server version?"),
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No,
        )
        if answer != QMessageBox.Yes:
            return
        if self._on_discard(operation_id):
            self._reload()


__all__ = ["SyncReviewDialog"]
