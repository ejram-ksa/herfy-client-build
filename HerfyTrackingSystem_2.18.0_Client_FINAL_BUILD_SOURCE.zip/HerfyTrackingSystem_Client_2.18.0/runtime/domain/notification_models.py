from __future__ import annotations
from dataclasses import dataclass
from datetime import datetime
from typing import Any

@dataclass(frozen=True, slots=True)
class AppNotification:
    id: str
    user_id: str
    kind: str
    title: str
    message: str
    severity: str
    created_at: datetime
    read_at: datetime | None
    deduplication_key: str
    action_type: str | None
    action_payload: dict[str, Any]
    expires_at: datetime | None
