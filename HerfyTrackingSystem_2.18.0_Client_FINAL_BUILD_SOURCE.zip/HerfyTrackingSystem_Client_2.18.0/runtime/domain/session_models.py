from __future__ import annotations
from dataclasses import dataclass
from datetime import datetime
from enum import Enum

class LogoutReason(str, Enum):
    MANUAL = "manual"
    SWITCH_USER = "switch_user"
    SESSION_EXPIRED = "session_expired"
    SERVER_REVOKED = "server_revoked"

@dataclass(frozen=True, slots=True)
class UserSession:
    session_id: str
    user_id: str
    username: str
    display_name: str
    roles: tuple[str, ...]
    permissions: frozenset[str]
    access_token: str
    refresh_token: str | None
    created_at: datetime
    expires_at: datetime | None
    remember_session: bool

    def __post_init__(self) -> None:
        required = {
            "session_id": self.session_id,
            "user_id": self.user_id,
            "username": self.username,
            "access_token": self.access_token,
        }
        missing = [name for name, value in required.items() if not str(value or "").strip()]
        if missing:
            raise ValueError("Missing authenticated session fields: " + ", ".join(missing))
