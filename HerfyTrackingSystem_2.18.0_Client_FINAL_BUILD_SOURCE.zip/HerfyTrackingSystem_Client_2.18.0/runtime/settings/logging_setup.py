from __future__ import annotations
import faulthandler
import logging
import os
import re
import sys
import threading
import traceback
from pathlib import Path
from typing import Callable, Any
from settings.config import app_root_dir

LOG_NAME = "herfy.log"
_MAX_BYTES = 5 * 1024 * 1024
_KEEP_BYTES = 2 * 1024 * 1024
_SECRET_PATTERN = re.compile(
    r"(?i)\b(password|authorization|bearer|access_token|refresh_token|cookie|session_secret|api_key)\b"
    r"(\s*[:=]\s*|\s+)([^\s,;]+)"
)

class SecretRedactionFilter(logging.Filter):
    def filter(self, record: logging.LogRecord) -> bool:
        text = record.getMessage()
        record.msg = _SECRET_PATTERN.sub(lambda m: f"{m.group(1)}{m.group(2)}<redacted>", text)
        record.args = ()
        return True

class SingleFileHandler(logging.Handler):
    """One physical log file with in-place atomic compaction."""
    def __init__(self, path: Path) -> None:
        super().__init__()
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self._lock = threading.RLock()

    def emit(self, record: logging.LogRecord) -> None:
        try:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            payload = (self.format(record) + "\n").encode("utf-8", errors="replace")
            with self._lock:
                self._compact_if_needed(len(payload))
                with open(self.path, "ab", buffering=0) as handle:
                    handle.write(payload)
        except (OSError, ValueError):
            self.handleError(record)

    def _compact_if_needed(self, incoming: int) -> None:
        if not self.path.exists() or self.path.stat().st_size + incoming <= _MAX_BYTES:
            return
        with open(self.path, "rb") as source:
            size = self.path.stat().st_size
            source.seek(max(0, size - _KEEP_BYTES))
            tail = source.read()
        first_newline = tail.find(b"\n")
        if first_newline >= 0:
            tail = tail[first_newline + 1 :]
        temp = self.path.with_suffix(".tmp")
        with open(temp, "wb") as target:
            target.write(tail)
            target.flush()
            os.fsync(target.fileno())
        os.replace(temp, self.path)

_handler: SingleFileHandler | None = None
_crash_stream: Any | None = None

def log_path() -> Path:
    return Path(app_root_dir()) / "logs" / LOG_NAME

def configure_root_logging(*_args: Any, level: int = logging.INFO, **_kwargs: Any) -> None:
    global _handler
    root = logging.getLogger()
    root.setLevel(level)
    for handler in list(root.handlers):
        root.removeHandler(handler)
        try:
            handler.close()
        except (OSError, ValueError):
            pass
    _handler = SingleFileHandler(log_path())
    _handler.setLevel(level)
    _handler.addFilter(SecretRedactionFilter())
    _handler.setFormatter(logging.Formatter("%(asctime)s %(levelname)s %(name)s %(message)s"))
    root.addHandler(_handler)

def setup_crash_logging() -> None:
    global _crash_stream
    configure_root_logging()
    if _crash_stream is None or getattr(_crash_stream, "closed", True):
        _crash_stream = open(log_path(), "a", encoding="utf-8", errors="replace")
    try:
        faulthandler.enable(file=_crash_stream, all_threads=True)
    except RuntimeError:
        logging.getLogger(__name__).exception("Failed to enable faulthandler")

def flush_root_logging() -> None:
    for handler in list(logging.getLogger().handlers):
        try:
            handler.flush()
        except (OSError, ValueError):
            continue
    if _crash_stream is not None:
        try:
            _crash_stream.flush()
        except (OSError, ValueError):
            pass

def write_emergency_crash_report(message: str) -> list[str]:
    logger = logging.getLogger("crash")
    logger.critical("%s", message)
    flush_root_logging()
    return [str(log_path())]

def install_exception_hooks(error_presenter: Callable[[str, str], None] | None = None) -> None:
    def excepthook(exc_type: type[BaseException], exc: BaseException, tb: Any) -> None:
        message = "".join(traceback.format_exception(exc_type, exc, tb))
        logging.getLogger("crash").critical("Unhandled exception\n%s", message)
        flush_root_logging()
        if error_presenter:
            error_presenter(
                "Unexpected error - Herfy Tracking System",
                f"The application encountered an unexpected error.\n\nLog: {log_path()}",
            )
    sys.excepthook = excepthook

    def thread_excepthook(args: threading.ExceptHookArgs) -> None:
        message = "".join(traceback.format_exception(args.exc_type, args.exc_value, args.exc_traceback))
        logging.getLogger("crash").critical("Unhandled thread exception\n%s", message)
        flush_root_logging()
    threading.excepthook = thread_excepthook
