from __future__ import annotations

import hashlib
import json
import os
import shutil
import sys
from datetime import datetime, timezone
from pathlib import Path

CANONICAL_APP_FOLDER = "HerfyTrackingSystem"
MIGRATION_MARKER = ".runtime_migration_v2"
_SKIP_TOP_LEVEL = {"__pycache__", "cache", "logs", "updates"}


def _sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def _copy_and_verify_tree(source: Path, target: Path) -> list[str]:
    copied: list[str] = []
    for child in source.iterdir():
        if child.name in _SKIP_TOP_LEVEL or child.is_symlink():
            continue
        destination = target / child.name
        if child.is_dir():
            destination.mkdir(parents=True, exist_ok=True)
            copied.extend(_copy_and_verify_tree(child, destination))
            continue
        destination.parent.mkdir(parents=True, exist_ok=True)
        if not destination.exists():
            shutil.copy2(child, destination)
            if _sha256(child) != _sha256(destination):
                raise OSError(f"Migration verification failed: {child}")
            copied.append(str(child))
    return copied


def _legacy_roots(target_root: Path) -> list[Path]:
    roots: list[Path] = []
    roaming = str(os.environ.get("APPDATA") or "").strip()
    local = str(os.environ.get("LOCALAPPDATA") or "").strip()
    if roaming:
        roots.append(Path(roaming) / "Herfy Tracking System")
    if local:
        roots.append(Path(local) / "HerfyTrackingSystem")
        roots.append(Path(local) / "Herfy Tracking System")
    result: list[Path] = []
    target_resolved = target_root.resolve()
    for root in roots:
        try:
            if root.resolve() != target_resolved and root not in result:
                result.append(root)
        except OSError:
            continue
    return result


def migrate_previous_localappdata(target_root: Path) -> dict[str, object]:
    """Migrate known legacy runtime roots to the canonical Roaming directory.

    Files are copied and verified before a legacy directory is removed. Cache,
    logs and downloaded updates are intentionally discarded.
    """
    result: dict[str, object] = {
        "attempted": False,
        "migrated": False,
        "removed": [],
        "sources": [],
        "target": str(target_root),
        "error": "",
    }
    if not sys.platform.startswith("win"):
        return result

    try:
        target_root.mkdir(parents=True, exist_ok=True)
        for source in _legacy_roots(target_root):
            if not source.exists() or source.is_symlink():
                continue
            result["attempted"] = True
            result["sources"].append(str(source))
            _copy_and_verify_tree(source, target_root)
            shutil.rmtree(source)
            result["removed"].append(str(source))

        marker = target_root / MIGRATION_MARKER
        marker.write_text(
            json.dumps(
                {
                    "migrated_at_utc": datetime.now(timezone.utc).isoformat(),
                    "sources": result["sources"],
                    "removed": result["removed"],
                    "target": str(target_root),
                },
                indent=2,
                ensure_ascii=False,
            ) + "\n",
            encoding="utf-8",
        )
        result["migrated"] = bool(result["sources"])
    except (OSError, RuntimeError, ValueError) as exc:
        result["error"] = f"{type(exc).__name__}: {exc}"
    return result
