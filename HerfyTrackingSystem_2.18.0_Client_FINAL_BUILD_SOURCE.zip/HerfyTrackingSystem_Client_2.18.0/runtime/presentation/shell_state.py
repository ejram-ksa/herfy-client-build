from __future__ import annotations

from collections.abc import Iterable
from dataclasses import dataclass

from domain.access_policy import PermissionContext, PermissionService
from services.translations import is_rtl, normalize_language_code
from settings.config import _


def normalize_shell_scope(
    permission_context: PermissionContext | None, allowed_branches: Iterable[str] | None
) -> tuple[PermissionContext, list[str]]:
    context = (
        permission_context
        if isinstance(permission_context, PermissionContext)
        else PermissionContext()
    )
    branches = [
        str(branch).strip() for branch in allowed_branches or [] if str(branch).strip()
    ]
    return context, branches


@dataclass(frozen=True)
class ShellAccessState:
    has_session: bool
    has_branch_scope: bool
    can_open_home: bool
    can_open_tracking: bool
    can_open_usage: bool
    can_open_about: bool
    can_open_settings: bool
    can_open_admin: bool
    can_manage_stored_products: bool
    can_manage_usage_products: bool
    can_change_own_password: bool
    can_open_notifications: bool
    can_logout: bool
    can_exit: bool
    can_open_admin_dashboard: bool


class ShellAccessService:
    @staticmethod
    def build(
        *,
        permission_context: PermissionContext | None = None,
        has_session: bool = False,
        allowed_branches: Iterable[str] | None = None,
        api_client_available: bool = False,
    ) -> ShellAccessState:
        context, allowed = normalize_shell_scope(permission_context, allowed_branches)
        has_branch_scope = bool(
            PermissionService.can_view_all(permission_context=context) or allowed
        )
        can_manage_org = bool(
            PermissionService.can_manage_org(permission_context=context)
        )
        return ShellAccessState(
            has_session=bool(has_session),
            has_branch_scope=has_branch_scope,
            can_open_home=True,
            can_open_tracking=bool(has_session and has_branch_scope),
            can_open_usage=bool(has_session and has_branch_scope),
            can_open_about=True,
            can_open_settings=bool(has_session),
            can_open_admin=bool(has_session and can_manage_org),
            can_manage_stored_products=bool(
                has_session
                and PermissionService.can_manage_catalog(permission_context=context)
            ),
            can_manage_usage_products=bool(
                has_session
                and PermissionService.can_manage_usage(permission_context=context)
            ),
            can_change_own_password=bool(
                has_session
                and PermissionService.can_change_own_password(permission_context=context)
            ),
            can_open_notifications=bool(has_session),
            can_logout=bool(has_session),
            can_exit=True,
            can_open_admin_dashboard=bool(
                has_session and can_manage_org and api_client_available
            ),
        )


@dataclass(frozen=True)
class ShellUserScopeState:
    resolved_view_branch: str
    branch_text: str
    top_info: str
    greeting: str


class ShellUserScopePresenter:
    @staticmethod
    def build(
        *,
        permission_context: PermissionContext | None = None,
        username: str = "",
        allowed_branches: Iterable[str] | None = None,
        language: str = "ar",
        view_branch: str | None = None,
    ) -> ShellUserScopeState:
        context, allowed = normalize_shell_scope(permission_context, allowed_branches)
        language_code = normalize_language_code(language)
        user_name = str(username or context.username or "").strip()
        resolved_view_branch = str(
            view_branch if view_branch is not None else context.active_branch or ""
        ).strip()
        if not resolved_view_branch or resolved_view_branch.lower() == "all":
            resolved_view_branch = "all"
        if resolved_view_branch == "all":
            if PermissionService.can_view_all(permission_context=context):
                branch_text = _("All restaurant branches")
            elif len(allowed) > 1:
                branch_text = _("All my restaurant branches")
            else:
                branch_text = allowed[0] if allowed else _("All restaurant branches")
        else:
            branch_text = resolved_view_branch
        role_text = PermissionService.role_label(
            permission_context=context,
            language="ar" if is_rtl(language_code) else "en",
        )
        if PermissionService.is_single_branch_scope(permission_context=context) and branch_text:
            greeting = _("Welcome, branch {branch}").format(branch=branch_text)
        elif user_name and branch_text:
            greeting = _("Welcome {username} — branch: {branch}").format(
                username=user_name, branch=branch_text
            )
        else:
            greeting = ""
        identity = " ".join(part for part in (role_text, user_name) if part).strip()
        compact_identity = role_text or user_name
        top_info = (
            f"{compact_identity} · {branch_text}".strip(" ·")
            if branch_text
            else identity
        )
        return ShellUserScopeState(
            resolved_view_branch=resolved_view_branch,
            branch_text=branch_text,
            top_info=top_info,
            greeting=greeting,
        )
