from __future__ import annotations

from dataclasses import dataclass

from core.booleans import parse_bool
from core.objects import normalize_int
from settings.config import _


@dataclass(frozen=True)
class RuntimeVisibleStateMessage:
    text: str
    timeout_ms: int = 0


class RuntimeVisibleStateService:
    @staticmethod
    def usage_sync_started(
        *, force_refresh: bool, include_pending: bool
    ) -> RuntimeVisibleStateMessage:
        if force_refresh and include_pending:
            return RuntimeVisibleStateMessage(
                _("Synchronizing usage changes and refreshing food items..."), 0
            )
        if include_pending:
            return RuntimeVisibleStateMessage(
                _("Synchronizing pending usage changes..."), 0
            )
        if force_refresh:
            return RuntimeVisibleStateMessage(_("Refreshing usage catalog..."), 0)
        return RuntimeVisibleStateMessage("")

    @staticmethod
    def usage_sync_finished(result: dict | None) -> RuntimeVisibleStateMessage:
        payload = result if isinstance(result, dict) else {}
        refreshed = parse_bool(payload.get("refreshed"), False)
        synced = normalize_int(payload.get("synced"), 0)
        if refreshed and synced > 0:
            return RuntimeVisibleStateMessage(
                _("Usage changes synced and food items refreshed."), 2800
            )
        if synced > 0:
            return RuntimeVisibleStateMessage(_("Usage changes synced."), 2400)
        if refreshed:
            return RuntimeVisibleStateMessage(
                _("Consumption item catalog refreshed."), 2400
            )
        return RuntimeVisibleStateMessage("")

    @staticmethod
    def update_check_started(*, interactive: bool) -> RuntimeVisibleStateMessage:
        return RuntimeVisibleStateMessage(_("Checking for updates..."), 0) if interactive else RuntimeVisibleStateMessage("")

    @staticmethod
    def update_checks_disabled() -> RuntimeVisibleStateMessage:
        return RuntimeVisibleStateMessage(
            _("Automatic update checks are disabled in Settings."), 4000
        )


@dataclass(frozen=True)
class CloudConnectionViewState:
    online: bool
    status_text: str
    indicator_property: str
    tray_tooltip: str
    status_title: str
    status_message: str
    status_level: str
    should_refresh_on_connect: bool


class CloudConnectionPresenter:
    @staticmethod
    def build(
        *, online: bool, previous: bool, app_name: str = "Herfy PTS"
    ) -> CloudConnectionViewState:
        is_online = bool(online)
        status_text = "● " + (_("Online") if is_online else _("Offline"))
        if is_online:
            status_message, status_level = _("Connection restored."), "ok"
        else:
            status_message = _(
                "Offline Mode — changes will sync when connection returns."
            )
            status_level = "warning"
        return CloudConnectionViewState(
            online=is_online,
            status_text=status_text,
            indicator_property="online" if is_online else "offline",
            tray_tooltip=f"{app_name} - {status_text}",
            status_title=_("Connection"),
            status_message=status_message,
            status_level=status_level,
            should_refresh_on_connect=is_online and not bool(previous),
        )
