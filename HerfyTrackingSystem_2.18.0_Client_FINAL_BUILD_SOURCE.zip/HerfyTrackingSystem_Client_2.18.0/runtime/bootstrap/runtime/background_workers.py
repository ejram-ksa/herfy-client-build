from __future__ import annotations
import logging
from collections.abc import Callable
from PyQt5.QtCore import QObject, QTimer
from PyQt5.QtWidgets import QApplication
from core.signals import safe_disconnect
from services.local_sync import LocalFirstSyncEngine

logger = logging.getLogger(__name__)


class SyncManager(QObject):

    def __init__(self, parent=None):
        super().__init__(parent)
        self._timers: dict[str, QTimer] = {}
        self._local_engine: LocalFirstSyncEngine | None = None

    def _timer_parent(self) -> QObject:
        app = QApplication.instance()
        parent_obj = self.parent()
        if (
            app is not None
            and isinstance(parent_obj, QObject)
            and (parent_obj.thread() == app.thread())
        ):
            return parent_obj
        return self

    def schedule(
        self, key: str, callback: Callable[[], None] | None, delay_ms: int = 350
    ) -> None:
        if not callable(callback):
            return
        timer = self._timers.get(key)
        if timer is None:
            timer = QTimer(self._timer_parent())
            timer.setSingleShot(True)
            self._timers[key] = timer
        else:
            safe_disconnect(
                timer.timeout,
                logger_=logger,
                context="Timer disconnect during reschedule",
            )
        timer.timeout.connect(callback)
        timer.start(max(50, int(delay_ms)))

    def cancel(self, key: str) -> None:
        timer = self._timers.get(key)
        if timer is not None:
            timer.stop()

    def cancel_all(self) -> None:
        for timer in list(self._timers.values()):
            try:
                timer.stop()
            except (AttributeError, RuntimeError, TypeError, ValueError):
                logger.debug("SyncManager timer stop failed", exc_info=True)

    def bind_local_first(
        self,
        *,
        repository,
        api_client,
        user_id: str,
        device_id: str,
        session_id: str,
        generation: int,
        allowed_branches,
        all_branches: bool,
        on_changes=None,
        on_state=None,
        generation_is_current=None,
    ) -> None:
        self.stop()
        self._local_engine = LocalFirstSyncEngine(
            repository,
            on_changes=on_changes,
            on_state=on_state,
            generation_is_current=generation_is_current,
        )
        setattr(repository, "local_sync_engine", self._local_engine)
        self._local_engine.start(
            user_id=user_id,
            device_id=device_id,
            session_id=session_id,
            generation=generation,
            api_client=api_client,
            allowed_branches=list(allowed_branches or []),
            all_branches=bool(all_branches),
        )

    def wake_local_first(self) -> None:
        engine = self._local_engine
        if engine is not None:
            engine.wake(immediate=True)

    def local_first_running(self) -> bool:
        engine = self._local_engine
        return bool(engine is not None and engine.running)

    def stop(self) -> None:
        self.cancel_all()
        engine = self._local_engine
        self._local_engine = None
        if engine is not None:
            repository = getattr(engine, "repository", None)
            if (
                repository is not None
                and getattr(repository, "local_sync_engine", None) is engine
            ):
                setattr(repository, "local_sync_engine", None)
            engine.stop()

    def shutdown(self) -> None:
        self.stop()
        for key, timer in list(self._timers.items()):
            try:
                timer.stop()
                safe_disconnect(
                    timer.timeout,
                    logger_=logger,
                    context=f"SyncManager shutdown disconnect: {key}",
                )
                timer.deleteLater()
            except (AttributeError, RuntimeError, TypeError, ValueError):
                logger.debug("SyncManager shutdown failed for %s", key, exc_info=True)
        self._timers.clear()
