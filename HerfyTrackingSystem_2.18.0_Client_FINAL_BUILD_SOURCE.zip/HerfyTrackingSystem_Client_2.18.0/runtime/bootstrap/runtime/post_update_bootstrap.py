from __future__ import annotations
import json
import logging
from pathlib import Path
from settings.config import app_root_dir, bundled_or_source_path
from settings.version import __version__
from services.updates.result_store import UpdateTransactionStore

logger = logging.getLogger(__name__)

def run_post_update_health_check(transaction_id: str) -> bool:
    store = UpdateTransactionStore(Path(app_root_dir()))
    transaction = store.load()
    if transaction is None or transaction.transaction_id != transaction_id:
        logger.error("Post-update transaction not found")
        return False
    checks = [
        str(__version__) == str(transaction.to_version),
        Path(bundled_or_source_path("version.json")).is_file(),
        Path(bundled_or_source_path("resources", "theme.qss")).is_file(),
        Path(app_root_dir()).is_dir(),
    ]
    if all(checks):
        store.save(transaction.advance("completed"))
        logger.info("Post-update health check completed transaction_id=%s", transaction_id)
        return True
    store.save(transaction.advance("failed"))
    logger.error("Post-update health check failed transaction_id=%s", transaction_id)
    return False
