from __future__ import annotations

import logging
import sqlite3

from core.errors import SERVICE_OPERATION_EXCEPTIONS
from domain.remote_ids import split_cloud_id, valid_remote_doc_id
from settings.config import _

logger = logging.getLogger(__name__)

_SESSION_CLEAR_SQL = {
    "cloud_tracked_products": "DELETE FROM cloud_tracked_products",
    "notify_log": "DELETE FROM notify_log",
    "stored_products": "DELETE FROM stored_products",
    "usage_products": "DELETE FROM usage_products",
}


class CloudSessionRepositoryMixin:
    """Session-scoped local data and remote request-cache ownership."""

    def _split_cloud_id(self, product_id: str) -> tuple[str, str]:
        return split_cloud_id(product_id)

    def _valid_cloud_doc_id(self, document_id: str | None) -> bool:
        return valid_remote_doc_id(document_id)

    def _missing_cloud_doc_id_error(self, *, silent: bool = False) -> bool:
        return self._show_error(
            _("Server record id is missing. Refresh shelf-life data and try again."),
            silent=silent,
        )

    def _require_cloud_doc_id(
        self, document_id: str | None, *, silent: bool = False
    ) -> bool:
        if self._valid_cloud_doc_id(document_id):
            return True
        self._missing_cloud_doc_id_error(silent=silent)
        return False

    def clear_session_scoped_local_data(self, *, clear_catalog: bool = True) -> None:
        """Clear data belonging to the signed-out user, not app preferences."""

        tables = ["cloud_tracked_products", "notify_log"]
        if clear_catalog:
            tables.extend(("stored_products", "usage_products"))
        try:
            with self._db_lock:
                conn = self._fresh_connection()
                try:
                    conn.execute("BEGIN IMMEDIATE")
                    for table in tables:
                        conn.execute(_SESSION_CLEAR_SQL[table])
                    conn.commit()
                except (sqlite3.Error, *SERVICE_OPERATION_EXCEPTIONS):
                    conn.rollback()
                    raise
                finally:
                    conn.close()
        except (sqlite3.Error, *SERVICE_OPERATION_EXCEPTIONS):
            logger.debug("Clearing session-scoped data failed", exc_info=True)

    def invalidate_remote_tracking_cache(self, branch: str | None = None) -> None:
        """Invalidate only the API client's request cache.

        The local SQLite baseline is authoritative and intentionally is not
        cleared here; LocalFirstSyncEngine advances it atomically.
        """

        try:
            service = self._cloud_service()
            if service is not None and hasattr(service, "invalidate_tracking_cache"):
                service.invalidate_tracking_cache(branch)
        except SERVICE_OPERATION_EXCEPTIONS:
            logger.debug("Remote tracking cache invalidation failed", exc_info=True)
