from __future__ import annotations

# ruff: noqa: E402

import logging
from core.booleans import parse_bool
from core.errors import SERVICE_OPERATION_EXCEPTIONS
from core.objects import safe_get
from application.dto import catalog_product_display_name
from application.dto import change_entity, change_operation, change_payload
from core.strings import normalize_text

logger = logging.getLogger(__name__)


class TrackingCatalogRepositoryMixin:

    def add_stored_product(self, mat_num: str, name_: str):
        material = normalize_text(mat_num)
        name = normalize_text(name_ or material)
        if not material:
            raise ValueError("Material number is required")
        operation_id = ""
        # The local view and its outbox entry must be created under the same
        # lock.  Otherwise a background bootstrap can land between those two
        # actions and hide a just-entered offline product.
        with self._db_lock:
            c = self.connection.cursor()
            existing = c.execute(
                "SELECT revision FROM stored_products WHERE material_number=?",
                (material,),
            ).fetchone()
            try:
                revision = max(0, int(safe_get(existing, "revision", 0) or 0))
            except (TypeError, ValueError):
                revision = 0
            c.execute(
                """
                INSERT INTO stored_products(material_number, name, revision, is_active)
                VALUES(?, ?, ?, 1)
                ON CONFLICT(material_number) DO UPDATE SET
                    name=excluded.name,
                    revision=MAX(stored_products.revision, excluded.revision),
                    is_active=1
                """,
                (material, name, revision),
            )
            self.connection.commit()
            if self._cloud_service() is not None:
                try:
                    operation_id = self._queue_sync_operation(
                        entity_type="stored_product",
                        entity_id=material,
                        action="upsert",
                        branch="",
                        payload={
                            "material_number": material,
                            "name": name,
                            "revision": revision,
                        },
                        base_revision=revision if revision > 0 else None,
                    )
                except SERVICE_OPERATION_EXCEPTIONS:
                    logger.debug("Stored product queueing skipped", exc_info=True)
        return {
            "status": "queued" if operation_id else "local",
            "operation_id": operation_id,
        }

    def fetch_stored_products(self):
        with self._db_lock:
            c = self.connection.cursor()
            c.execute(
                """
                SELECT material_number, name, revision, is_active
                  FROM stored_products
                 WHERE COALESCE(is_active, 1) = 1
                 ORDER BY material_number
                """
            )
            rows = [dict(r) for r in c.fetchall()]
        return rows

    def merge_remote_stored_products(self, rows: list[dict] | None) -> list[dict]:
        applied: list[dict] = []
        with self._db_lock:
            cursor = self.connection.cursor()
            for row in rows or []:
                if not isinstance(row, dict):
                    continue
                material = normalize_text(
                    row.get("material_number")
                    or row.get("material_code")
                    or row.get("material")
                    or row.get("code")
                )
                if not material or self._has_local_outbox_overlay(
                    "stored_product", material
                ):
                    continue
                name = normalize_text(
                    row.get("name")
                    or row.get("material_name")
                    or row.get("description")
                    or material
                )
                try:
                    revision = max(0, int(row.get("revision") or 0))
                except (TypeError, ValueError):
                    revision = 0
                existing = cursor.execute(
                    "SELECT revision FROM stored_products WHERE material_number=?",
                    (material,),
                ).fetchone()
                try:
                    current_revision = max(
                        0, int(safe_get(existing, "revision", 0) or 0)
                    )
                except (TypeError, ValueError):
                    current_revision = 0
                if existing is not None and revision < current_revision:
                    continue
                is_active = parse_bool(
                    row.get("is_active", row.get("active", True)), True
                )
                cursor.execute(
                    """
                    INSERT INTO stored_products(material_number, name, revision, is_active)
                    VALUES(?, ?, ?, ?)
                    ON CONFLICT(material_number) DO UPDATE SET
                        name=excluded.name,
                        revision=excluded.revision,
                        is_active=excluded.is_active
                    """,
                    (material, name, revision, int(is_active)),
                )
                applied.append(
                    {
                        "material_number": material,
                        "name": name,
                        "revision": revision,
                        "is_active": is_active,
                    }
                )
            if applied:
                self.connection.commit()
        return applied

    def apply_remote_stored_product_changes(self, changes: list[dict]) -> dict:
        upserts = 0
        deletes = 0
        with self._db_lock:
            cursor = self.connection.cursor()
            for change in changes or []:
                if not isinstance(change, dict):
                    continue
                entity = change_entity(change)
                if entity and entity not in {
                    "stored_product",
                    "catalog_product",
                    "product",
                }:
                    continue
                payload = change_payload(change)
                material = normalize_text(
                    payload.get("material_number")
                    or payload.get("material_code")
                    or payload.get("material")
                    or payload.get("code")
                )
                if not material or self._has_local_outbox_overlay(
                    "stored_product", material
                ):
                    continue
                try:
                    revision = max(
                        0, int(change.get("revision") or payload.get("revision") or 0)
                    )
                except (TypeError, ValueError):
                    revision = 0
                existing = cursor.execute(
                    "SELECT revision FROM stored_products WHERE material_number=?",
                    (material,),
                ).fetchone()
                try:
                    current_revision = max(
                        0, int(safe_get(existing, "revision", 0) or 0)
                    )
                except (TypeError, ValueError):
                    current_revision = 0
                if existing is not None and revision < current_revision:
                    continue
                if change_operation(change) == "delete":
                    cursor.execute(
                        """
                        INSERT INTO stored_products(material_number, name, revision, is_active)
                        VALUES(?, ?, ?, 0)
                        ON CONFLICT(material_number) DO UPDATE SET
                            name=excluded.name,
                            revision=excluded.revision,
                            is_active=0
                        """,
                        (
                            material,
                            catalog_product_display_name(payload, material),
                            revision,
                        ),
                    )
                    deletes += 1
                    continue
                name = catalog_product_display_name(payload, material)
                is_active = parse_bool(
                    payload.get("is_active", payload.get("active", True)), True
                )
                cursor.execute(
                    """
                    INSERT INTO stored_products(material_number, name, revision, is_active)
                    VALUES(?, ?, ?, ?)
                    ON CONFLICT(material_number) DO UPDATE SET
                        name=excluded.name,
                        revision=excluded.revision,
                        is_active=excluded.is_active
                    """,
                    (material, name, revision, int(is_active)),
                )
                upserts += 1
            if upserts or deletes:
                self.connection.commit()
        return {
            "upserts": upserts,
            "deletes": deletes,
            "applied": bool(upserts or deletes),
        }

    def stored_product_exists(self, mat_num: str) -> bool:
        material = str(mat_num or "").strip()
        if not material:
            return False
        with self._db_lock:
            c = self.connection.cursor()
            c.execute(
                """
                SELECT 1 FROM stored_products
                 WHERE material_number=? AND COALESCE(is_active, 1)=1
                """,
                (material,),
            )
            return bool(c.fetchone())

    def delete_stored_product(self, mat_num: str):
        material = normalize_text(mat_num)
        if not material:
            return {"status": "skipped", "operation_id": ""}
        operation_id = ""
        with self._db_lock:
            c = self.connection.cursor()
            existing = c.execute(
                "SELECT revision FROM stored_products WHERE material_number=?",
                (material,),
            ).fetchone()
            try:
                revision = max(0, int(safe_get(existing, "revision", 0) or 0))
            except (TypeError, ValueError):
                revision = 0
            c.execute(
                "UPDATE stored_products SET is_active=0 WHERE material_number=?",
                (material,),
            )
            self.connection.commit()
            if self._cloud_service() is not None:
                try:
                    user_id, device_id, _session_id = self._current_sync_identity()
                    if revision <= 0 and self.discard_unsent_operations_for_entity(
                        user_id=user_id,
                        device_id=device_id,
                        entity_type="stored_product",
                        entity_id=material,
                    ):
                        operation_id = ""
                    else:
                        operation_id = self._queue_sync_operation(
                            entity_type="stored_product",
                            entity_id=material,
                            action="delete",
                            branch="",
                            payload={"material_number": material, "revision": revision},
                            base_revision=revision if revision > 0 else None,
                        )
                except SERVICE_OPERATION_EXCEPTIONS:
                    logger.debug(
                        "Stored product delete queueing skipped", exc_info=True
                    )
        return {
            "status": "queued" if operation_id else "local",
            "operation_id": operation_id,
        }

    def _has_local_outbox_overlay(self, entity_type: str, entity_id: str) -> bool:
        try:
            user_id, device_id, _session_id = self._current_sync_identity()
            checker = getattr(self, "has_pending_operation_for_entity", None)
            return bool(
                callable(checker)
                and checker(
                    user_id=user_id,
                    device_id=device_id,
                    entity_type=entity_type,
                    entity_id=entity_id,
                )
            )
        except SERVICE_OPERATION_EXCEPTIONS:
            return False


import logging
from datetime import datetime
import uuid
from settings.config import _

logger = logging.getLogger(__name__)


class TrackingCommandRepositoryMixin:

    def _current_sync_identity(self) -> tuple[str, str, str]:
        state = getattr(self, "app_state", None)
        session = getattr(state, "session", None)
        profile = getattr(state, "current_user", None)
        user_id = str(
            getattr(profile, "uid", "")
            or getattr(profile, "username", "")
            or getattr(session, "uid", "")
            or ""
        ).strip()
        device_id = str(getattr(session, "device_id", "") or "").strip()
        session_id = str(getattr(session, "session_id", "") or "").strip()
        if not user_id or not device_id:
            raise RuntimeError("Authenticated sync identity is unavailable.")
        return user_id, device_id, session_id

    def _queue_sync_operation(
        self,
        *,
        entity_type: str,
        entity_id: str,
        action: str,
        branch: str,
        payload: dict,
        base_revision: int | None,
    ) -> str:
        user_id, device_id, session_id = self._current_sync_identity()
        operation_id = self.enqueue_pending_operation(
            user_id=user_id,
            device_id=device_id,
            session_id=session_id,
            entity_type=str(entity_type or "").strip().lower(),
            entity_id=str(entity_id or "").strip(),
            action=str(action or "").strip().lower(),
            branch_id=str(branch or "").strip(),
            base_revision=base_revision,
            payload=dict(payload or {}),
        )
        engine = getattr(self, "local_sync_engine", None)
        if engine is not None:
            engine.wake()
        return operation_id

    def _queue_tracking_operation(
        self,
        *,
        entity_id: str,
        action: str,
        branch: str,
        payload: dict,
        base_revision: int | None,
    ) -> str:
        return self._queue_sync_operation(
            entity_type="tracking_item",
            entity_id=entity_id,
            action=action,
            branch=branch,
            payload=payload,
            base_revision=base_revision,
        )

    def _delete_cloud_tracked_product(
        self, branch: str, doc_id: str, *, silent: bool = False
    ) -> bool:
        if not self._valid_cloud_doc_id(doc_id):
            return self._missing_cloud_doc_id_error(silent=silent)
        try:
            record = self._persisted_tracking_record(doc_id, branch)
            base_revision = int(record.get("revision") or 0)
            self._queue_tracking_operation(
                entity_id=str(doc_id).strip(),
                action="delete",
                branch=branch,
                payload={
                    "id": str(doc_id).strip(),
                    "branch_id": branch,
                    "revision": base_revision,
                },
                base_revision=base_revision,
            )
            self._delete_persisted_tracking_record(doc_id, branch)
            self.invalidate_remote_tracking_cache(branch)
            return self._show_success(
                _("Food item deleted locally and queued for synchronization."),
                silent=silent,
            )
        except SERVICE_OPERATION_EXCEPTIONS as e:
            return self._show_cloud_operation_error(e, silent=silent)

    def _delete_local_tracked_product(self, pid, *, silent: bool = False) -> bool:
        c = self.connection.cursor()
        c.execute("DELETE FROM tracked_products WHERE id=?", (pid,))
        self.connection.commit()
        return self._show_success(_("Food item deleted."), silent=silent)

    def _restore_cloud_tracked_product(
        self, branch: str, doc_id: str, *, silent: bool = False
    ) -> bool:
        if not self._valid_cloud_doc_id(doc_id):
            return self._missing_cloud_doc_id_error(silent=silent)
        try:
            record = self._persisted_tracking_record(doc_id, branch)
            if not record:
                return self._show_error(
                    _("Deleted food item is not available locally. Refresh data and try again."),
                    silent=silent,
                )
            base_revision = int(record.get("revision") or 0)
            payload = dict(record)
            payload.update(
                {
                    "id": str(doc_id).strip(),
                    "branch_id": branch,
                    "revision": base_revision,
                    "deleted_at": None,
                }
            )
            operation_id = self._queue_tracking_operation(
                entity_id=str(doc_id).strip(),
                action="restore",
                branch=branch,
                payload=payload,
                base_revision=base_revision,
            )
            record.update(
                {
                    "pending": True,
                    "pending_operation_id": operation_id,
                    "deleted_at": None,
                }
            )
            self._persist_tracking_records([record])
            self.invalidate_remote_tracking_cache(branch)
            return self._show_success(
                _("Food item restored locally and queued for synchronization."),
                silent=silent,
            )
        except SERVICE_OPERATION_EXCEPTIONS as e:
            return self._show_cloud_operation_error(e, silent=silent)

    def _update_cloud_tracked_product(
        self,
        branch: str,
        doc_id: str,
        *,
        qty: int,
        prod_date: str,
        exp_date: str,
        silent: bool = False,
    ) -> bool:
        if not self._valid_cloud_doc_id(doc_id):
            return self._missing_cloud_doc_id_error(silent=silent)
        rec = self._persisted_tracking_record(doc_id, branch)
        material = str(rec.get("material_number", "")).strip()
        if not material:
            return self._show_error(
                _("Food item was not found. Refresh shelf-life data and try again."),
                silent=silent,
            )
        try:
            base_revision = int(rec.get("revision") or 0)
            payload = {
                "id": str(doc_id).strip(),
                "branch_id": branch,
                "material_number": material,
                "material_name": str(rec.get("name") or material),
                "quantity": int(qty),
                "production_date": str(prod_date),
                "expiry_date": str(exp_date),
                "revision": base_revision,
            }
            operation_id = self._queue_tracking_operation(
                entity_id=str(doc_id).strip(),
                action="update",
                branch=branch,
                payload=payload,
                base_revision=base_revision,
            )
            rec.update(
                {
                    "doc_id": doc_id,
                    "material_number": material,
                    "quantity": int(qty),
                    "production_date": str(prod_date),
                    "expiry_date": str(exp_date),
                    "branch": branch,
                    "pending": True,
                    "pending_operation_id": operation_id,
                }
            )
            self._persist_tracking_records([rec])
            self.invalidate_remote_tracking_cache(branch)
            return self._show_success(
                _("Food item updated locally and queued for synchronization."),
                silent=silent,
            )
        except SERVICE_OPERATION_EXCEPTIONS as e:
            return self._show_cloud_operation_error(e, silent=silent)

    def _update_local_tracked_product(
        self, pid, *, qty: int, prod_date: str, exp_date: str, silent: bool = False
    ) -> bool:
        c = self.connection.cursor()
        c.execute(
            "UPDATE tracked_products SET quantity=?, production_date=?, expiry_date=? WHERE id=?",
            (qty, prod_date, exp_date, pid),
        )
        self.connection.commit()
        return self._show_success(_("Food item updated."), silent=silent)

    def add_tracked_product(
        self, mat_num: str, qty: int, prod_date: str, exp_date: str, name_: str = ""
    ):
        self.last_message = ""
        self.last_error = ""
        if self._cloud_service():
            branch = self._pick_branch_for_write()
            doc_id = uuid.uuid4().hex
            payload = {
                "id": doc_id,
                "branch_id": branch,
                "material_number": str(mat_num),
                "material_name": str(name_ or mat_num),
                "name": str(name_ or mat_num),
                "quantity": int(qty),
                "production_date": str(prod_date),
                "expiry_date": str(exp_date),
                "revision": 0,
            }
            operation_id = self._queue_tracking_operation(
                entity_id=doc_id,
                action="create",
                branch=branch,
                payload=payload,
                base_revision=None,
            )
            rec = self._normalize_tracking_record(
                {
                    "doc_id": doc_id,
                    "material_number": str(mat_num),
                    "name": str(name_ or mat_num),
                    "quantity": int(qty),
                    "production_date": str(prod_date),
                    "expiry_date": str(exp_date),
                    "branch": branch,
                    "revision": 0,
                    "pending": True,
                    "pending_operation_id": operation_id,
                }
            )
            self._persist_tracking_records([rec])
            self.invalidate_remote_tracking_cache(branch)
            self.last_message = (
                "Food item added locally and queued for synchronization."
            )
            return
        now_str = datetime.now().strftime("%Y-%m-%d")
        c = self.connection.cursor()
        c.execute(
            "\n                INSERT INTO tracked_products(material_number,quantity,production_date,expiry_date,created_at)\n                VALUES(?,?,?,?,?)\n            ",
            (mat_num, qty, prod_date, exp_date, now_str),
        )
        self.connection.commit()
        self.last_message = "Food item added."

    def _modify_cloud_tracked_product(
        self,
        operation: str,
        pid,
        qty=None,
        prod_date=None,
        exp_date=None,
        *,
        silent: bool = False,
    ) -> bool:
        pid_str = str(pid or "").strip()
        bid, doc_id = self._split_cloud_id(pid_str)
        if not self._require_cloud_doc_id(doc_id, silent=silent):
            return False
        try:
            branch = bid or self._pick_branch_for_write()
        except SERVICE_OPERATION_EXCEPTIONS as e:
            self.last_error = str(e)
            return self._show_error(str(e), silent=silent)
        if operation == "delete":
            return self._delete_cloud_tracked_product(branch, doc_id, silent=silent)
        if operation == "restore":
            return self._restore_cloud_tracked_product(branch, doc_id, silent=silent)
        if operation == "update":
            is_valid, parsed_qty = self._validate_tracking_update(
                qty, prod_date, exp_date, silent=silent
            )
            if not is_valid:
                return bool(parsed_qty)
            return self._update_cloud_tracked_product(
                branch,
                doc_id,
                qty=int(parsed_qty),
                prod_date=str(prod_date),
                exp_date=str(exp_date),
                silent=silent,
            )
        return self._show_error(_("Unknown operation."), silent=silent)

    def _modify_local_tracked_product(
        self,
        operation: str,
        pid,
        qty=None,
        prod_date=None,
        exp_date=None,
        *,
        silent: bool = False,
    ) -> bool:
        if not self._local_tracked_product_exists(pid):
            return self._show_error(_("Food item was not found."), silent=silent)
        if operation == "delete":
            return self._delete_local_tracked_product(pid, silent=silent)
        if operation == "update":
            is_valid, parsed_qty = self._validate_tracking_update(
                qty, prod_date, exp_date, silent=silent
            )
            if not is_valid:
                return bool(parsed_qty)
            return self._update_local_tracked_product(
                pid,
                qty=int(parsed_qty),
                prod_date=str(prod_date),
                exp_date=str(exp_date),
                silent=silent,
            )
        return self._show_error(_("Unknown operation."), silent=silent)

    def modify_tracked_product(
        self,
        operation: str,
        pid,
        qty=None,
        prod_date=None,
        exp_date=None,
        *,
        silent: bool = False,
    ) -> bool:
        self.last_message = ""
        self.last_error = ""
        op = str(operation or "").lower().strip()
        if self._cloud_service():
            return self._modify_cloud_tracked_product(
                op, pid, qty, prod_date, exp_date, silent=silent
            )
        return self._modify_local_tracked_product(
            op, pid, qty, prod_date, exp_date, silent=silent
        )


from domain.tracking_rows import deduplicate_tracking_records
import sqlite3


class TrackingQueryRepositoryMixin:

    def fetch_tracked_products(self, branch_filter_override: str | None = None):
        if self._cloud_service():
            allowed_branches = [
                str(b).strip() for b in self.allowed_branches() or [] if str(b).strip()
            ]
            allowed_branch_keys = {b.lower() for b in allowed_branches}
            can_view_all = bool(self.can_view_all_branches())
            branch_filter_raw = (
                branch_filter_override
                if branch_filter_override is not None
                else self.get_active_branch()
            )
            branch_filter_raw = str(branch_filter_raw or "").strip()
            cache_key = (
                "all"
                if can_view_all and branch_filter_raw.lower() in {"", "all", "*"}
                else (branch_filter_raw.lower() if branch_filter_raw else "")
            )
            if not can_view_all:
                if not allowed_branch_keys:
                    logger.warning(
                        "Tracked-product read blocked because the authenticated scope has no branches"
                    )
                    return []
                if cache_key in {"", "all"}:
                    cache_key = "scope_all"
                elif cache_key not in allowed_branch_keys:
                    logger.warning(
                        "Tracked-product read blocked for a branch outside the authenticated scope"
                    )
                    return []

            def _scoped_rows(rows):
                copied = deduplicate_tracking_records(rows)
                if can_view_all:
                    return copied
                return [
                    row
                    for row in copied
                    if str(row.get("branch") or "").strip().lower()
                    in allowed_branch_keys
                ]

            # All authenticated tracking reads come from the same persisted
            # baseline that LocalFirstSyncEngine installs and advances.  The
            # UI merely wakes that owner; it never opens a second list endpoint
            # that could observe a different cursor or branch scope.
            wake = getattr(self, "wake_local_sync", None)
            if callable(wake):
                wake()
            return _scoped_rows(self.load_local_tracking_baseline(cache_key))
        c = self.connection.cursor()
        c.execute(
            "\n                SELECT tp.id, tp.material_number, tp.quantity,\n                       tp.production_date, tp.expiry_date, tp.created_at,\n                       sp.name\n                FROM tracked_products tp\n                JOIN stored_products sp ON tp.material_number = sp.material_number\n            "
        )
        return [dict(r) for r in c.fetchall()]

    def fetch_tracked_products_local_newconn(self):
        connector = getattr(self, "_fresh_connection", None)
        if callable(connector):
            conn = connector.__call__()
        else:
            conn = sqlite3.connect(self.db_path, timeout=90.0)
        conn.row_factory = sqlite3.Row
        try:
            conn.execute("PRAGMA foreign_keys=ON")
            c = conn.cursor()
            c.execute(
                "\n                    SELECT tp.id, tp.material_number, tp.quantity,\n                           tp.production_date, tp.expiry_date, tp.created_at,\n                           sp.name\n                    FROM tracked_products tp\n                    JOIN stored_products sp ON tp.material_number = sp.material_number\n                    "
            )
            return [dict(r) for r in c.fetchall()]
        finally:
            try:
                conn.close()
            except SERVICE_OPERATION_EXCEPTIONS:
                logger.debug(
                    "DatabaseTrackingCatalogMixin.fetch_tracked_products_local_newconn fallback failed",
                    exc_info=True,
                )


import logging
from typing import Any

logger = logging.getLogger(__name__)


def clean_tracking_error_message(message: str) -> str:
    text = str(message or "").strip()
    if not text:
        return _("Operation failed.")
    lowered = text.lower()
    if "body.id" in lowered or "valid string" in lowered or "string_type" in lowered:
        return _("Server record id is missing. Refresh shelf-life data and try again.")
    if text.startswith(("[{", "{'", '{"')):
        return _("Server rejected the request. Refresh shelf-life data and try again.")
    return text


from dataclasses import dataclass


@dataclass(frozen=True, slots=True)
class TrackingUpdateValidation:
    ok: bool
    quantity: int | None = None
    error_message: str = ""
    dates_reversed: bool = False


def validate_tracking_update_fields(
    qty: Any, prod_date: Any, exp_date: Any
) -> TrackingUpdateValidation:
    try:
        parsed_qty = int(qty)
    except (TypeError, ValueError):
        parsed_qty = 0
    if parsed_qty <= 0:
        return TrackingUpdateValidation(
            ok=False, error_message=_("Quantity must be a positive integer.")
        )
    if not prod_date or not exp_date:
        return TrackingUpdateValidation(
            ok=False, error_message=_("Production and expiry dates are required.")
        )
    try:
        prod = datetime.strptime(str(prod_date), "%Y-%m-%d").date()
        exp = datetime.strptime(str(exp_date), "%Y-%m-%d").date()
    except (TypeError, ValueError):
        return TrackingUpdateValidation(
            ok=False, error_message=_("Invalid date format!")
        )
    return TrackingUpdateValidation(
        ok=True, quantity=parsed_qty, dates_reversed=prod > exp
    )


class TrackingFeedbackMixin:

    def _feedback_handler(self, key: str):
        handlers = getattr(self, "_ui_feedback_handlers", None)
        if isinstance(handlers, dict):
            callback = handlers.get(str(key or "").strip())
            if callable(callback):
                return callback
        return None

    def _notify_error(
        self, title: str, message: str, *, critical: bool = False
    ) -> None:
        callback = self._feedback_handler("error")
        if callback is not None:
            try:
                callback(title, message, critical=bool(critical))
                return
            except SERVICE_OPERATION_EXCEPTIONS:
                logger.exception("Database error feedback callback failed")
        logger.error("%s: %s", title, message)

    def _notify_info(self, title: str, message: str) -> None:
        callback = self._feedback_handler("info")
        if callback is not None:
            try:
                callback(title, message)
                return
            except SERVICE_OPERATION_EXCEPTIONS:
                logger.exception("Database info feedback callback failed")
        logger.info("%s: %s", title, message)

    def _confirm_action(self, title: str, message: str) -> bool:
        callback = self._feedback_handler("confirm")
        if callback is not None:
            try:
                return bool(callback(title, message))
            except SERVICE_OPERATION_EXCEPTIONS:
                logger.exception("Database confirmation callback failed")
        return False

    def _show_error(
        self, message: str, *, critical: bool = False, silent: bool = False
    ) -> bool:
        self.last_error = str(message or "").strip()
        if silent:
            return False
        self._notify_error(_("Error"), self.last_error, critical=critical)
        return False

    def _clean_user_error(self, message: str) -> str:
        return clean_tracking_error_message(message)

    def _show_cloud_operation_error(
        self, exc: Exception, *, silent: bool = False
    ) -> bool:
        logger.exception("Cloud tracking operation failed")
        return self._show_error(
            self._clean_user_error(str(exc)), critical=True, silent=silent
        )

    def _show_success(self, message: str, *, silent: bool = False) -> bool:
        self.last_message = str(message or "").strip()
        if not silent:
            self._notify_info(_("Success"), self.last_message)
        return True

    def _confirm_invalid_date_order(self) -> bool:
        return self._confirm_action(
            _("Confirm date order"),
            _("Production date is after expiry date. Do you want to proceed?"),
        )

    def _local_tracked_product_exists(self, pid) -> bool:
        c = self.connection.cursor()
        c.execute("SELECT 1 FROM tracked_products WHERE id=?", (pid,))
        return bool(c.fetchone())

    def _validate_tracking_update(
        self, qty=None, prod_date=None, exp_date=None, *, silent: bool = False
    ) -> tuple[bool, int | None]:
        validation = validate_tracking_update_fields(qty, prod_date, exp_date)
        if not validation.ok:
            return (False, self._show_error(validation.error_message, silent=silent))
        if validation.dates_reversed and (not self._confirm_invalid_date_order()):
            return (False, False)
        return (True, validation.quantity)


import logging
from data.tracking_baseline import TrackingLocalBaselineRepositoryMixin

logger = logging.getLogger(__name__)


class DatabaseTrackingCatalogMixin(
    TrackingFeedbackMixin,
    TrackingLocalBaselineRepositoryMixin,
    TrackingCatalogRepositoryMixin,
    TrackingCommandRepositoryMixin,
    TrackingQueryRepositoryMixin,
):
    """Composition surface for tracking persistence responsibilities."""
