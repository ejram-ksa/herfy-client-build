from __future__ import annotations

import json
import logging
import sqlite3
from collections.abc import Mapping
from datetime import datetime
from typing import Any

from application.dto import change_entity, change_operation, change_payload
from core.errors import SERVICE_OPERATION_EXCEPTIONS
from core.objects import safe_get
from core.strings import normalize_text
from domain.remote_ids import normalize_remote_id, split_cloud_id
from domain.tracking_rows import deduplicate_tracking_records, tracking_record_identity_keys
from data.tracking_cloud import build_tracking_record_id

logger = logging.getLogger(__name__)


def _record_source(row: Mapping[str, Any] | None) -> dict[str, Any]:
    source = dict(row or {})
    payload = source.get("payload")
    return dict(payload) if isinstance(payload, Mapping) else source


def _tracking_document_id(source: Mapping[str, Any], fallback: object = "") -> str:
    document_id = normalize_text(
        source.get("doc_id")
        or source.get("document_id")
        or fallback
        or source.get("id")
    )
    _branch, document_id = split_cloud_id(document_id)
    return document_id


def _tracking_branch(source: Mapping[str, Any], fallback: object = "") -> str:
    branch = normalize_text(
        source.get("branch") or source.get("branch_id") or fallback
    )
    if branch:
        return branch
    encoded_id = normalize_text(source.get("id"))
    encoded_branch, _document_id = split_cloud_id(encoded_id)
    return encoded_branch


def normalize_tracking_baseline_row(
    row: Mapping[str, Any] | None,
    *,
    fallback_document_id: object = "",
    fallback_branch: object = "",
) -> dict[str, Any] | None:
    """Convert every tracking input shape to the one local-baseline format."""

    source = _record_source(row)
    document_id = _tracking_document_id(source, fallback_document_id)
    branch = _tracking_branch(source, fallback_branch)
    if not document_id:
        return None
    normalized = dict(source)
    normalized["id"] = document_id
    normalized["doc_id"] = document_id
    normalized["branch"] = branch
    normalized["branch_id"] = branch
    return {
        "id": build_tracking_record_id(branch, document_id),
        "branch": branch,
        "material_number": normalize_text(normalized.get("material_number")),
        "expiry_date": normalize_text(
            normalized.get("expiry_date") or normalized.get("expiration_date")
        ),
        "payload": normalized,
    }


def write_tracking_baseline_row(
    conn: sqlite3.Connection,
    row: Mapping[str, Any] | None,
    *,
    fallback_document_id: object = "",
    fallback_branch: object = "",
    updated_at: str | None = None,
) -> str:
    """Upsert one record into the sole persisted tracking baseline."""

    normalized = normalize_tracking_baseline_row(
        row,
        fallback_document_id=fallback_document_id,
        fallback_branch=fallback_branch,
    )
    if normalized is None:
        return ""
    _remove_stale_tracking_identity_rows(conn, normalized)
    conn.execute(
        """
        INSERT OR REPLACE INTO cloud_tracked_products(
            id, branch, material_number, expiry_date, payload, updated_at
        ) VALUES (?, ?, ?, ?, ?, ?)
        """,
        (
            normalized["id"],
            normalized["branch"],
            normalized["material_number"],
            normalized["expiry_date"],
            json.dumps(normalized["payload"], ensure_ascii=False, sort_keys=True),
            updated_at or datetime.now().isoformat(timespec="seconds"),
        ),
    )
    return str(normalized["id"])


def _remove_stale_tracking_identity_rows(
    conn: sqlite3.Connection, normalized: Mapping[str, Any]
) -> None:
    """Keep one persisted record for each remote or business identity."""

    payload = normalized.get("payload")
    if not isinstance(payload, Mapping):
        return
    identities = set(tracking_record_identity_keys(payload))
    if not identities:
        return
    rows = conn.execute(
        """
        SELECT id, payload
          FROM cloud_tracked_products
         WHERE lower(branch)=lower(?)
           AND lower(material_number)=lower(?)
           AND expiry_date=?
        """,
        (
            str(normalized.get("branch") or ""),
            str(normalized.get("material_number") or ""),
            str(normalized.get("expiry_date") or ""),
        ),
    ).fetchall()
    for row in rows:
        row_id = str(row["id"] or "")
        if row_id == str(normalized["id"]):
            continue
        try:
            existing = json.loads(str(row["payload"] or "{}"))
        except (TypeError, ValueError, json.JSONDecodeError):
            continue
        if isinstance(existing, Mapping) and identities.intersection(
            tracking_record_identity_keys(existing)
        ):
            conn.execute("DELETE FROM cloud_tracked_products WHERE id=?", (row_id,))


def delete_tracking_baseline_row(
    conn: sqlite3.Connection,
    *,
    document_id: object,
    branch: object = "",
) -> None:
    """Delete all legacy or canonical representations of one tracking record."""

    document_text = normalize_text(document_id)
    encoded_branch, document_text = split_cloud_id(document_text)
    branch_text = normalize_text(branch) or encoded_branch
    if not document_text:
        return
    canonical_id = build_tracking_record_id(branch_text, document_text)
    if branch_text:
        conn.execute(
            """
            DELETE FROM cloud_tracked_products
             WHERE id=? OR (
                lower(branch)=lower(?) AND (
                    json_extract(payload, '$.doc_id')=?
                    OR json_extract(payload, '$.id')=?
                    OR id=?
                )
             )
            """,
            (canonical_id, branch_text, document_text, document_text, document_text),
        )
        return
    conn.execute(
        """
        DELETE FROM cloud_tracked_products
         WHERE id=?
            OR json_extract(payload, '$.doc_id')=?
            OR json_extract(payload, '$.id')=?
        """,
        (document_text, document_text, document_text),
    )


class TrackingLocalBaselineRepositoryMixin:
    """Repository operations for the single local tracking baseline.

    The SQLite table is the only client-side representation of synchronized
    tracking data.  There is deliberately no second in-memory list or record
    cache to drift from the cursor-owned local-first synchronizer.
    """

    def _stored_product_name_map(self) -> dict[str, str]:
        try:
            with self._db_lock:
                rows = self.connection.execute(
                    """
                    SELECT material_number, name
                      FROM stored_products
                     WHERE COALESCE(is_active, 1)=1
                    """
                ).fetchall()
            return {
                normalize_text(safe_get(row, "material_number", "")): normalize_text(
                    safe_get(row, "name", "")
                )
                for row in rows
                if normalize_text(safe_get(row, "material_number", ""))
            }
        except (sqlite3.Error, *SERVICE_OPERATION_EXCEPTIONS):
            logger.debug("Loading stored-product names failed", exc_info=True)
            return {}

    def _normalize_tracking_record(
        self,
        record: Mapping[str, Any] | None,
        *,
        stored_names: Mapping[str, Any] | None = None,
    ) -> dict[str, Any]:
        from data.tracking_cloud import normalize_cloud_tracking_record

        return normalize_cloud_tracking_record(
            record,
            stored_names=(
                stored_names if stored_names is not None else self._stored_product_name_map()
            ),
        )

    def _tracking_record_from_sync_item(
        self,
        item: Mapping[str, Any] | None,
        *,
        stored_names: Mapping[str, Any] | None = None,
    ) -> dict[str, Any]:
        from data.tracking_cloud import cloud_tracking_record_from_item

        return cloud_tracking_record_from_item(
            item,
            stored_names=(
                stored_names if stored_names is not None else self._stored_product_name_map()
            ),
        )

    def apply_remote_tracking_changes(self, changes: list[dict]) -> dict:
        upserts: list[dict] = []
        deletes: list[str] = []
        changed_branches: set[str] = set()
        stored_names = self._stored_product_name_map()
        for change in changes or []:
            if not isinstance(change, dict):
                continue
            entity = change_entity(change)
            if entity and entity not in {"tracking", "tracking_item", "tracked_product"}:
                continue
            payload = change_payload(change)
            operation = change_operation(change)
            branch = normalize_text(payload.get("branch") or payload.get("branch_id"))
            document_id = normalize_remote_id(payload) or normalize_text(
                change.get("entity_key")
            )
            if branch:
                changed_branches.add(branch)
            if operation == "delete":
                self._delete_persisted_tracking_record(document_id, branch)
                deleted_id = build_tracking_record_id(branch, document_id)
                if deleted_id:
                    deletes.append(deleted_id)
                continue
            record = self._tracking_record_from_sync_item(
                payload, stored_names=stored_names
            )
            if branch and not record.get("branch"):
                record["branch"] = branch
            if not record.get("doc_id"):
                continue
            if self._persist_tracking_records([record]):
                upserts.append(dict(record))
        return {
            "upserts": upserts,
            "deletes": deletes,
            "branches": sorted(changed_branches),
            "applied": bool(upserts or deletes),
        }

    def _persist_tracking_records(self, rows: list[Mapping[str, Any]]) -> bool:
        records = deduplicate_tracking_records(rows)
        if not records:
            return True
        try:
            with self._db_lock:
                conn = self._fresh_connection()
                try:
                    conn.execute("BEGIN IMMEDIATE")
                    now_text = datetime.now().isoformat(timespec="seconds")
                    for record in records:
                        write_tracking_baseline_row(
                            conn,
                            record,
                            updated_at=now_text,
                        )
                    conn.commit()
                    return True
                except (sqlite3.Error, *SERVICE_OPERATION_EXCEPTIONS):
                    conn.rollback()
                    raise
                finally:
                    conn.close()
        except (sqlite3.Error, *SERVICE_OPERATION_EXCEPTIONS):
            logger.exception("Persisting local tracking baseline failed")
            return False

    def replace_local_tracking_baseline(
        self, rows: list[Mapping[str, Any]] | None
    ) -> bool:
        try:
            with self._db_lock:
                conn = self._fresh_connection()
                try:
                    conn.execute("BEGIN IMMEDIATE")
                    conn.execute("DELETE FROM cloud_tracked_products")
                    now_text = datetime.now().isoformat(timespec="seconds")
                    for record in deduplicate_tracking_records(rows):
                        write_tracking_baseline_row(
                            conn,
                            record,
                            updated_at=now_text,
                        )
                    conn.commit()
                    return True
                except (sqlite3.Error, *SERVICE_OPERATION_EXCEPTIONS):
                    conn.rollback()
                    raise
                finally:
                    conn.close()
        except (sqlite3.Error, *SERVICE_OPERATION_EXCEPTIONS):
            logger.exception("Replacing local tracking baseline failed")
            return False

    def _delete_persisted_tracking_record(
        self, document_id: str, branch: str = ""
    ) -> None:
        try:
            with self._db_lock:
                conn = self._fresh_connection()
                try:
                    conn.execute("BEGIN IMMEDIATE")
                    delete_tracking_baseline_row(
                        conn,
                        document_id=document_id,
                        branch=branch,
                    )
                    conn.commit()
                except (sqlite3.Error, *SERVICE_OPERATION_EXCEPTIONS):
                    conn.rollback()
                    raise
                finally:
                    conn.close()
        except (sqlite3.Error, *SERVICE_OPERATION_EXCEPTIONS):
            logger.debug("Deleting local tracking baseline failed", exc_info=True)

    def _persisted_tracking_record(
        self, document_id: str, branch: str = ""
    ) -> dict[str, Any]:
        document_text = normalize_text(document_id)
        encoded_branch, document_text = split_cloud_id(document_text)
        branch_text = normalize_text(branch) or encoded_branch
        if not document_text:
            return {}
        try:
            conn = self._fresh_connection()
            try:
                if branch_text:
                    row = conn.execute(
                        """
                        SELECT payload FROM cloud_tracked_products
                         WHERE id=? OR (
                            lower(branch)=lower(?) AND (
                                json_extract(payload, '$.doc_id')=?
                                OR json_extract(payload, '$.id')=?
                            )
                         )
                         ORDER BY updated_at DESC
                         LIMIT 1
                        """,
                        (
                            build_tracking_record_id(branch_text, document_text),
                            branch_text,
                            document_text,
                            document_text,
                        ),
                    ).fetchone()
                else:
                    row = conn.execute(
                        """
                        SELECT payload FROM cloud_tracked_products
                         WHERE id=?
                            OR json_extract(payload, '$.doc_id')=?
                            OR json_extract(payload, '$.id')=?
                         ORDER BY updated_at DESC
                         LIMIT 1
                        """,
                        (document_text, document_text, document_text),
                    ).fetchone()
                if row is None:
                    return {}
                payload = json.loads(str(safe_get(row, "payload", "{}") or "{}"))
                if not isinstance(payload, dict):
                    return {}
                return self._normalize_tracking_record(payload)
            finally:
                conn.close()
        except (sqlite3.Error, TypeError, ValueError, json.JSONDecodeError, *SERVICE_OPERATION_EXCEPTIONS):
            logger.debug("Loading local tracking record failed", exc_info=True)
            return {}

    def load_local_tracking_baseline(self, scope_key: str) -> list[dict[str, Any]]:
        try:
            conn = self._fresh_connection()
            try:
                rows = conn.execute(
                    "SELECT payload FROM cloud_tracked_products ORDER BY updated_at DESC"
                ).fetchall()
            finally:
                conn.close()
        except (sqlite3.Error, *SERVICE_OPERATION_EXCEPTIONS):
            logger.debug("Loading local tracking baseline failed", exc_info=True)
            return []

        allowed = {
            str(branch).strip().lower()
            for branch in self.allowed_branches() or []
            if str(branch).strip()
        }
        wanted = normalize_text(scope_key).lower()
        stored_names = self._stored_product_name_map()
        result: list[dict[str, Any]] = []
        for db_row in rows:
            try:
                payload = json.loads(str(safe_get(db_row, "payload", "{}") or "{}"))
            except (TypeError, ValueError, json.JSONDecodeError):
                continue
            if not isinstance(payload, dict):
                continue
            record = self._normalize_tracking_record(payload, stored_names=stored_names)
            branch = normalize_text(record.get("branch")).lower()
            if wanted in {"", "all"}:
                result.append(record)
            elif wanted == "scope_all":
                if branch in allowed:
                    result.append(record)
            elif branch == wanted:
                result.append(record)
        return deduplicate_tracking_records(result)
