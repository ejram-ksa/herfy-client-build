from __future__ import annotations

# ruff: noqa: E402

import logging
import json
from core.booleans import parse_bool
from core.errors import SERVICE_OPERATION_EXCEPTIONS

logger = logging.getLogger(__name__)


class UsageLocalRepositoryMixin:

    def _emit_usage_event(self, action: str, payload=None):
        state = getattr(self, "app_state", None)
        if state is None:
            return
        data = dict(payload or {})
        data.setdefault("action", str(action or "").strip().lower())
        if str(action or "").strip().lower() == "delete":
            state.emit_item_deleted("usage", data)
        else:
            state.emit_item_updated("usage", data)

    def fetch_usage_products(self):
        with self._db_lock:
            conn = self._fresh_connection()
            try:
                c = conn.cursor()
                c.execute(
                    """
                    SELECT material, name, uom, revision, active
                      FROM usage_products
                     WHERE COALESCE(active, 1) = 1
                     ORDER BY material
                    """
                )
                return [dict(r) for r in c.fetchall()]
            finally:
                conn.close()

    def add_usage_product(
        self, material: str, name: str, uom: str = "", *, remote_first: bool = True
    ):
        del remote_first
        material = str(material or "").strip()
        name = str(name or material).strip()
        uom = str(uom or "").strip()
        if not material:
            raise RuntimeError("Material is required.")
        operation_id = ""
        # Keep the locally visible catalog record and its outbox entry inside
        # one critical section.  This prevents bootstrap/delta work from
        # observing the former without the latter.
        with self._db_lock:
            revision = self._usage_product_revision(material)
            self._upsert_usage_product_local(material, name, uom, revision=revision)
            if self._cloud_service() is not None:
                try:
                    operation_id = self._queue_sync_operation(
                        entity_type="usage_product",
                        entity_id=material,
                        action="upsert",
                        branch="",
                        payload={
                            "material": material,
                            "material_number": material,
                            "name": name,
                            "uom": uom,
                            "revision": revision,
                        },
                        base_revision=revision if revision > 0 else None,
                    )
                except SERVICE_OPERATION_EXCEPTIONS:
                    logger.debug("Usage product queueing skipped", exc_info=True)
        self._emit_usage_event(
            "upsert",
            {
                "material": material,
                "name": name,
                "uom": uom,
                "source": "queued" if operation_id else "local",
                "operation_id": operation_id,
            },
        )
        return {
            "status": "queued" if operation_id else "local",
            "queued": bool(operation_id),
            "operation_id": operation_id,
        }

    def delete_usage_product(self, material: str, *, remote_first: bool = True):
        del remote_first
        material = str(material or "").strip()
        if not material:
            return {"status": "skipped", "queued": False}
        operation_id = ""
        with self._db_lock:
            revision = self._usage_product_revision(material)
            self._delete_usage_product_local(material)
            if self._cloud_service() is not None:
                try:
                    user_id, device_id, _session_id = self._current_sync_identity()
                    discarded = False
                    if revision <= 0:
                        discarded = bool(
                            self.discard_unsent_operations_for_entity(
                                user_id=user_id,
                                device_id=device_id,
                                entity_type="usage_product",
                                entity_id=material,
                            )
                        )
                    if not discarded:
                        operation_id = self._queue_sync_operation(
                            entity_type="usage_product",
                            entity_id=material,
                            action="delete",
                            branch="",
                            payload={
                                "material": material,
                                "material_number": material,
                                "revision": revision,
                            },
                            base_revision=revision if revision > 0 else None,
                        )
                except SERVICE_OPERATION_EXCEPTIONS:
                    logger.debug("Usage product delete queueing skipped", exc_info=True)
        self._emit_usage_event(
            "delete",
            {
                "material": material,
                "source": "queued" if operation_id else "local",
                "operation_id": operation_id,
            },
        )
        return {
            "status": "queued" if operation_id else "local",
            "queued": bool(operation_id),
            "operation_id": operation_id,
        }

    def _usage_product_revision(self, material: str) -> int:
        with self._db_lock:
            row = self.connection.execute(
                "SELECT revision FROM usage_products WHERE material=?", (material,)
            ).fetchone()
        try:
            return max(0, int(safe_get(row, "revision", 0) or 0))
        except (TypeError, ValueError):
            return 0

    def _upsert_usage_product_local(
        self, material: str, name: str, uom: str = "", *, revision: int = 0
    ):
        with self._db_lock:
            conn = self._fresh_connection()
            try:
                c = conn.cursor()
                c.execute(
                    """
                    INSERT INTO usage_products(material, name, uom, revision, active)
                    VALUES(?, ?, COALESCE(NULLIF(?, ''), ''), ?, 1)
                    ON CONFLICT(material) DO UPDATE SET
                        name=excluded.name,
                        uom=COALESCE(NULLIF(excluded.uom, ''), usage_products.uom, ''),
                        revision=MAX(usage_products.revision, excluded.revision),
                        active=1
                    """,
                    (material, name, uom, max(0, int(revision or 0))),
                )
                conn.commit()
            finally:
                conn.close()

    def _delete_usage_product_local(self, material: str):
        with self._db_lock:
            conn = self._fresh_connection()
            try:
                conn.execute(
                    "UPDATE usage_products SET active=0 WHERE material=?", (material,)
                )
                conn.commit()
            finally:
                conn.close()

    def replace_usage_products(self, items, preserve_pending: bool = True):
        with self._db_lock:
            conn = self._fresh_connection()
            try:
                # A server catalog deletion is a tombstone, not a local hard
                # delete.  Retaining its revision lets a later reactivation use
                # the correct optimistic-concurrency base revision.
                conn.execute("UPDATE usage_products SET active=0")
                batch = []
                for it in items or []:
                    m = (
                        it.get("material")
                        or it.get("material_number")
                        or it.get("material_code")
                        or ""
                    ).strip()
                    if not m:
                        continue
                    n = (it.get("name") or it.get("material_name") or m).strip()
                    u = (it.get("uom") or it.get("unit") or "").strip()
                    try:
                        revision = max(0, int(it.get("revision") or 0))
                    except (TypeError, ValueError):
                        revision = 0
                    active = parse_bool(
                        it.get("active", it.get("is_active", True)), True
                    )
                    batch.append((m, n, u, revision, int(active)))
                if batch:
                    conn.executemany(
                        """
                        INSERT INTO usage_products(material,name,uom,revision,active)
                        VALUES(?,?,?,?,?)
                        ON CONFLICT(material) DO UPDATE SET
                            name=excluded.name,
                            uom=COALESCE(NULLIF(excluded.uom, ''), usage_products.uom, ''),
                            revision=MAX(usage_products.revision, excluded.revision),
                            active=excluded.active
                        """,
                        batch,
                    )
                if preserve_pending:
                    self._restore_generic_usage_overlays(conn)
                conn.commit()
            finally:
                conn.close()

    def _restore_generic_usage_overlays(self, conn) -> None:
        """Reapply local-first edits after a read-only catalog snapshot."""

        try:
            user_id, device_id, _session_id = self._current_sync_identity()
        except SERVICE_OPERATION_EXCEPTIONS:
            return
        rows = conn.execute(
            """
            SELECT action, entity_id, payload
              FROM pending_operations
             WHERE user_id=? AND device_id=? AND entity_type='usage_product'
               AND status IN ('pending', 'retry', 'in_flight')
             ORDER BY created_at, operation_id
            """,
            (user_id, device_id),
        ).fetchall()
        for row in rows:
            material = str(row["entity_id"] or "").strip()
            if not material:
                continue
            action = str(row["action"] or "upsert").strip().lower()
            if action == "delete":
                conn.execute(
                    "UPDATE usage_products SET active=0 WHERE material=?", (material,)
                )
                continue
            try:
                payload = json.loads(str(row["payload"] or "{}"))
            except (TypeError, ValueError, json.JSONDecodeError):
                payload = {}
            if not isinstance(payload, dict):
                payload = {}
            name = str(payload.get("name") or payload.get("material_name") or material)
            uom = str(payload.get("uom") or payload.get("unit") or "")
            try:
                revision = max(0, int(payload.get("revision") or 0))
            except (TypeError, ValueError):
                revision = 0
            conn.execute(
                """
                INSERT INTO usage_products(material,name,uom,revision,active)
                VALUES(?,?,?,?,1)
                ON CONFLICT(material) DO UPDATE SET
                    name=excluded.name,
                    uom=COALESCE(NULLIF(excluded.uom, ''), usage_products.uom, ''),
                    revision=MAX(usage_products.revision, excluded.revision),
                    active=1
                """,
                (material, name, uom, max(0, revision)),
            )

    def update_usage_uom_bulk(self, uom_map):
        if not uom_map:
            return
        with self._db_lock:
            conn = self._fresh_connection()
            try:
                cur = conn.cursor()
                for code, u in uom_map.items():
                    if not u:
                        continue
                    cur.execute(
                        "\nUPDATE usage_products\nSET uom=CASE WHEN IFNULL(uom,'')='' THEN ? ELSE uom END\nWHERE material=?\n",
                        (u, code),
                    )
                conn.commit()
            finally:
                conn.close()


import logging
from core.objects import safe_get
from core.strings import normalize_text

logger = logging.getLogger(__name__)


class UsageLegacyMigrationRepositoryMixin:
    """Read and retire pre-local-first usage outbox rows; never create them."""

    @staticmethod
    def _legacy_usage_table_exists(conn) -> bool:
        row = conn.execute(
            "SELECT 1 FROM sqlite_master WHERE type='table' AND name=?",
            ("usage_products_pending",),
        ).fetchone()
        return row is not None

    def pending_usage_changes_count(self) -> int:
        with self._db_lock:
            conn = self._fresh_connection()
            try:
                try:
                    user_id, device_id, _session_id = self._current_sync_identity()
                except SERVICE_OPERATION_EXCEPTIONS:
                    return 0
                row = conn.execute(
                    """
                    SELECT COUNT(*) AS cnt
                      FROM pending_operations
                     WHERE user_id=? AND device_id=?
                       AND entity_type IN ('usage', 'usage_product', 'usage_products', 'catalog_usage')
                       AND status IN ('pending', 'retry', 'in_flight')
                    """,
                    (user_id, device_id),
                ).fetchone()
                return int(safe_get(row, "cnt", 0) or 0)
            finally:
                conn.close()

    def _read_pending_usage_rows(self, conn=None):
        owns = conn is None
        conn = conn or self._fresh_connection()
        try:
            if not self._legacy_usage_table_exists(conn):
                return []
            cur = conn.cursor()
            cur.execute(
                "SELECT id,op,material,name,uom,created_at FROM usage_products_pending ORDER BY id ASC"
            )
            return [dict(r) for r in cur.fetchall()]
        finally:
            if owns:
                conn.close()

    def migrate_legacy_usage_operations(
        self, user_id: str, device_id: str, session_id: str
    ) -> int:
        """Move pre-2.18 usage rows into the shared idempotent outbox once."""

        user = str(user_id or "").strip()
        device = str(device_id or "").strip()
        if not user or not device:
            return 0
        with self._db_lock:
            rows = self._read_pending_usage_rows(self.connection)
            migrated = 0
            for row in rows:
                material = str(row.get("material") or "").strip()
                if not material:
                    self.connection.execute(
                        "DELETE FROM usage_products_pending WHERE id=?", (row.get("id"),)
                    )
                    continue
                current = self.connection.execute(
                    "SELECT revision FROM usage_products WHERE material=?", (material,)
                ).fetchone()
                revision = int(safe_get(current, "revision", 0) or 0)
                action = (
                    "delete"
                    if str(row.get("op") or "").strip().lower() == "delete"
                    else "upsert"
                )
                payload = {
                    "material": material,
                    "material_number": material,
                    "name": str(row.get("name") or material),
                    "uom": str(row.get("uom") or ""),
                    "revision": revision,
                }
                self.enqueue_pending_operation(
                    user_id=user,
                    device_id=device,
                    session_id=str(session_id or "").strip(),
                    entity_type="usage_product",
                    entity_id=material,
                    action=action,
                    branch_id="",
                    base_revision=revision if revision > 0 else None,
                    payload=payload,
                )
                self.connection.execute(
                    "DELETE FROM usage_products_pending WHERE id=?", (row.get("id"),)
                )
                migrated += 1
            self.connection.execute("DROP TABLE IF EXISTS usage_products_pending")
            self.connection.commit()
        return migrated

    def _usage_change_payload(self, change: dict) -> dict:
        payload = (
            change.get("payload") if isinstance(change.get("payload"), dict) else change
        )
        payload = dict(payload or {})
        key = normalize_text(change.get("entity_key") or change.get("key"))
        if key:
            payload.setdefault("material", key)
            payload.setdefault("material_number", key)
            payload.setdefault("material_code", key)
        return payload


from application.dto import catalog_product_display_name
from application.dto import change_entity, change_operation


class UsageSynchronizationRepositoryMixin:

    def apply_remote_usage_changes(self, changes: list[dict]) -> dict:
        upserts = 0
        deletes = 0
        with self._db_lock:
            conn = self._fresh_connection()
            try:
                for change in changes or []:
                    if not isinstance(change, dict):
                        continue
                    entity = change_entity(change)
                    if entity and entity not in {
                        "usage",
                        "usage_product",
                        "usage_products",
                        "catalog_usage",
                    }:
                        continue
                    payload = self._usage_change_payload(change)
                    material = normalize_text(
                        payload.get("material")
                        or payload.get("material_number")
                        or payload.get("material_code")
                    )
                    if not material:
                        continue
                    if self._has_local_outbox_overlay("usage_product", material):
                        continue
                    try:
                        revision = max(
                            0,
                            int(change.get("revision") or payload.get("revision") or 0),
                        )
                    except (TypeError, ValueError):
                        revision = 0
                    if change_operation(change) == "delete":
                        conn.execute(
                            """
                            INSERT INTO usage_products(material,name,uom,revision,active)
                            VALUES(?,?,?, ?, 0)
                            ON CONFLICT(material) DO UPDATE SET
                                revision=MAX(usage_products.revision, excluded.revision),
                                active=0
                            """,
                            (
                                material,
                                str(payload.get("name") or material),
                                str(payload.get("uom") or payload.get("unit") or ""),
                                revision,
                            ),
                        )
                        deletes += 1
                        continue
                    name = catalog_product_display_name(payload, material)
                    uom = normalize_text(
                        payload.get("uom")
                        or payload.get("unit")
                        or payload.get("unit_of_measure")
                    )
                    active = parse_bool(
                        payload.get("active", payload.get("is_active", True)), True
                    )
                    conn.execute(
                        """
                        INSERT INTO usage_products(material,name,uom,revision,active)
                        VALUES(?,?,?,?,?)
                        ON CONFLICT(material) DO UPDATE SET
                          name=excluded.name,
                          uom=COALESCE(NULLIF(excluded.uom,''), usage_products.uom, ''),
                          revision=MAX(usage_products.revision, excluded.revision),
                          active=excluded.active
                        """,
                        (material, name, uom, revision, int(active)),
                    )
                    upserts += 1
                conn.commit()
            finally:
                conn.close()
        if upserts or deletes:
            self._emit_usage_event(
                "delta", {"upserts": upserts, "deletes": deletes, "source": "server"}
            )
        return {
            "upserts": upserts,
            "deletes": deletes,
            "applied": bool(upserts or deletes),
        }

    def request_usage_catalog_reconciliation(self):
        """Wake LocalFirstSyncEngine and return the persisted usage catalog."""
        if self._cloud_service() is not None:
            wake = getattr(self, "wake_local_sync", None)
            if callable(wake):
                wake()
        return self.fetch_usage_products()

    def wake_usage_sync(self):
        """Wake the one LocalFirstSyncEngine that owns usage outbox delivery."""
        try:
            user_id, device_id, _session_id = self._current_sync_identity()
            summary = self.operation_summary(user_id, device_id)
        except SERVICE_OPERATION_EXCEPTIONS:
            summary = {}
        engine = getattr(self, "local_sync_engine", None)
        if engine is not None:
            engine.wake()
        return {
            "synced": 0,
            "remaining": int(summary.get("queued") or 0),
            "queued": int(summary.get("queued") or 0),
            "refreshed": False,
            "delegated": True,
        }


import logging

logger = logging.getLogger(__name__)


class DatabaseUsageCatalogMixin(
    UsageLocalRepositoryMixin,
    UsageLegacyMigrationRepositoryMixin,
    UsageSynchronizationRepositoryMixin,
):
    """Composition surface for usage catalog persistence and synchronization."""
