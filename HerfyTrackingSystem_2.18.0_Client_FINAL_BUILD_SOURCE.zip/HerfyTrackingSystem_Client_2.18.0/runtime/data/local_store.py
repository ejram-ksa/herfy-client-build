from __future__ import annotations

# ruff: noqa: E402

import logging
from core.errors import SERVICE_OPERATION_EXCEPTIONS

logger = logging.getLogger(__name__)


class DatabaseDefaultsMixin:

    def _apply_threshold_notification_migration_once(self) -> None:
        try:
            marker = self.get_setting("threshold_notification_state_initialized", "")
            if marker == "True":
                return
            self.clear_alert_states()
            self.set_setting("threshold_notification_state_initialized", "True")
        except SERVICE_OPERATION_EXCEPTIONS:
            logger.debug(
                "Threshold notification state initialization failed", exc_info=True
            )

    def ensure_default_settings(self):
        defaults = {
            "date_format": "yyyy-MM-dd",
            "language": "en",
            "enable_alerts": "True",
            "enable_tray_background": "True",
            "enable_desktop_notifications": "True",
            "enable_smart_notifications": "True",
            "enable_sounds": "True",
            "notifications_enabled": "True",
            "native_windows_toast_enabled": "True",
            "first_reminder_days": "21",
            "quiet_hours_enabled": "False",
            "quiet_hours_start": "22:00",
            "quiet_hours_end": "07:00",
            "group_notifications_by_branch": "True",
            "max_toasts_per_minute": "3",
            "show_branch_name_when_multiple_branches": "True",
            "expiry_expiring_soon_threshold_days": "21",
            "expiry_critical_threshold_days": "4",
            "expiry_critical_threshold_percent": "20",
            "expiry_enable_status_colors": "True",
            "expiry_enable_status_icons": "True",
            "notification_once_per_day": "True",
            "notification_repeat_interval_minutes": "240",
            "notification_duration_seconds": "8",
            "notification_max_per_cycle": "5",
            "notification_summary_threshold": "3",
            "monitoring_active_check_interval_minutes": "15",
            "monitoring_background_check_interval_minutes": "30",
            "notification_sound_default": "default.wav",
            "notification_sound_expired": "expired.wav",
            "notification_sound_today": "expires_today.wav",
            "notification_sound_critical": "expiry_critical.wav",
            "notification_sound_soon": "expiry_soon.wav",
            "font_size": "10",
            "font": "Segoe UI",
            "start_with_windows": "False",
            "tray_show_message_on_minimize": "False",
            "usage_hide_total_zero": "False",
            "immediate_server_sync": "True",
        }
        installer_defaults_applied = False
        try:
            from services.installer_defaults import merge_installer_defaults

            merged_defaults = merge_installer_defaults(defaults)
            installer_defaults_applied = merged_defaults != defaults
            defaults = merged_defaults
        except SERVICE_OPERATION_EXCEPTIONS:
            logger.debug("Installer defaults merge skipped", exc_info=True)
        for key, value in defaults.items():
            if not self.get_setting(key, None):
                self.set_setting(key, value)
        try:
            if installer_defaults_applied and (
                not self.get_setting("tray_settings_migrated_v2", None)
            ):
                self.set_setting("tray_settings_migrated_v2", "True")
            if not installer_defaults_applied and (
                not self.get_setting("tray_settings_migrated_v2", None)
            ):
                self.set_setting("enable_tray_background", "True")
                self.set_setting("tray_show_message_on_minimize", "False")
                self.set_setting("tray_settings_migrated_v2", "True")
        except SERVICE_OPERATION_EXCEPTIONS:
            logger.exception("Failed to apply tray settings migration")


class UIFeedbackHandlersMixin:

    def set_ui_feedback_handlers(self, *, error=None, info=None, confirm=None):
        self._ui_feedback_handlers = {
            "error": error if callable(error) else None,
            "info": info if callable(info) else None,
            "confirm": confirm if callable(confirm) else None,
        }


import json

from core.objects import safe_get


class DatabaseSchemaMixin:

    def create_tables(self):
        """Create tables."""
        c = self.connection.cursor()
        c.execute(
            "\n            CREATE TABLE IF NOT EXISTS stored_products(\n              material_number TEXT PRIMARY KEY,\n              name TEXT NOT NULL,\n              revision INTEGER NOT NULL DEFAULT 0,\n              is_active INTEGER NOT NULL DEFAULT 1\n            )\n        "
        )
        c.execute(
            "\n            CREATE TABLE IF NOT EXISTS tracked_products(\n              id INTEGER PRIMARY KEY AUTOINCREMENT,\n              material_number TEXT NOT NULL,\n              quantity INTEGER NOT NULL,\n              production_date TEXT NOT NULL,\n              expiry_date TEXT NOT NULL,\n              created_at TEXT,\n              FOREIGN KEY(material_number) REFERENCES stored_products(material_number) ON DELETE CASCADE\n            )\n        "
        )
        c.execute(
            "\n            CREATE TABLE IF NOT EXISTS settings(\n              key TEXT PRIMARY KEY,\n              value TEXT NOT NULL\n            )\n        "
        )
        c.execute(
            "\n            CREATE TABLE IF NOT EXISTS cloud_tracked_products(\n              id TEXT PRIMARY KEY,\n              branch TEXT DEFAULT '',\n              material_number TEXT DEFAULT '',\n              expiry_date TEXT DEFAULT '',\n              payload TEXT NOT NULL,\n              updated_at TEXT NOT NULL\n            )\n        "
        )
        c.execute(
            "\n            CREATE TABLE IF NOT EXISTS notify_log(\n              key TEXT PRIMARY KEY,\n              last_date TEXT NOT NULL\n            )\n        "
        )
        c.execute(
            "\n            CREATE TABLE IF NOT EXISTS alert_state(\n              key TEXT PRIMARY KEY,\n              last_date TEXT DEFAULT '',\n              last_notified_at REAL DEFAULT 0,\n              last_seen_at REAL DEFAULT 0,\n              fingerprint TEXT DEFAULT '',\n              severity_rank INTEGER DEFAULT 0,\n              status_text TEXT DEFAULT '',\n              notify_count INTEGER DEFAULT 0\n            )\n        "
        )
        c.execute(
            """
            CREATE TABLE IF NOT EXISTS notification_ledger (
              notification_key TEXT PRIMARY KEY,
              state TEXT NOT NULL,
              severity INTEGER NOT NULL,
              last_shown_at TEXT,
              last_payload_hash TEXT,
              shown_count INTEGER NOT NULL DEFAULT 0,
              acknowledged_at TEXT
            )
            """
        )
        c.execute(
            "\n            CREATE TABLE IF NOT EXISTS usage_products(\n              material TEXT PRIMARY KEY,\n              name TEXT,\n              uom TEXT,\n              revision INTEGER NOT NULL DEFAULT 0,\n              active INTEGER NOT NULL DEFAULT 1\n            )\n        "
        )
        c.execute(
            """
            CREATE TABLE IF NOT EXISTS pending_operations (
                operation_id TEXT PRIMARY KEY,
                user_id TEXT NOT NULL,
                device_id TEXT NOT NULL,
                session_id TEXT,
                entity_type TEXT NOT NULL,
                entity_id TEXT NOT NULL,
                action TEXT NOT NULL,
                branch_id TEXT NOT NULL DEFAULT '',
                base_revision INTEGER,
                payload TEXT NOT NULL,
                status TEXT NOT NULL DEFAULT 'pending',
                retry_count INTEGER NOT NULL DEFAULT 0,
                last_error TEXT,
                created_at TEXT NOT NULL,
                updated_at TEXT NOT NULL
            )
            """
        )
        c.execute(
            """
            CREATE INDEX IF NOT EXISTS idx_pending_operations_user_device_status
            ON pending_operations(user_id, device_id, status, created_at)
            """
        )
        c.execute(
            """
            CREATE TABLE IF NOT EXISTS sync_state (
                user_id TEXT NOT NULL,
                device_id TEXT NOT NULL,
                last_cursor INTEGER NOT NULL DEFAULT 0,
                baseline_ready INTEGER NOT NULL DEFAULT 0,
                scope_fingerprint TEXT NOT NULL DEFAULT '',
                updated_at TEXT NOT NULL,
                PRIMARY KEY (user_id, device_id)
            )
            """
        )
        c.execute(
            """
            CREATE TABLE IF NOT EXISTS applied_sync_events (
                user_id TEXT NOT NULL,
                device_id TEXT NOT NULL,
                cursor INTEGER NOT NULL,
                operation_id TEXT,
                applied_at TEXT NOT NULL,
                PRIMARY KEY (user_id, device_id, cursor)
            )
            """
        )
        c.execute(
            """
            CREATE UNIQUE INDEX IF NOT EXISTS ux_applied_sync_events_user_operation
            ON applied_sync_events(user_id, operation_id)
            WHERE operation_id IS NOT NULL AND operation_id <> ''
            """
        )
        c.execute(
            """
            CREATE TABLE IF NOT EXISTS shown_reminders (
                user_id TEXT NOT NULL,
                device_id TEXT NOT NULL,
                item_id TEXT NOT NULL,
                branch_id TEXT NOT NULL,
                threshold_days INTEGER NOT NULL,
                expiry_date TEXT NOT NULL,
                shown_at TEXT NOT NULL,
                PRIMARY KEY (
                    user_id, device_id, item_id, branch_id,
                    threshold_days, expiry_date
                )
            )
            """
        )
        c.execute(
            """
            CREATE TABLE IF NOT EXISTS user_device_settings (
                user_id TEXT NOT NULL,
                device_id TEXT NOT NULL,
                key TEXT NOT NULL,
                value TEXT NOT NULL,
                updated_at TEXT NOT NULL,
                PRIMARY KEY (user_id, device_id, key)
            )
            """
        )
        c.execute("PRAGMA table_info(tracked_products)")
        cols = [safe_get(x, "name", "") for x in c.fetchall()]
        if "created_at" not in cols:
            c.execute("ALTER TABLE tracked_products ADD COLUMN created_at TEXT")
        c.execute("PRAGMA table_info(stored_products)")
        stored_columns = {safe_get(x, "name", "") for x in c.fetchall()}
        if "revision" not in stored_columns:
            c.execute(
                "ALTER TABLE stored_products ADD COLUMN revision INTEGER NOT NULL DEFAULT 0"
            )
        if "is_active" not in stored_columns:
            c.execute(
                "ALTER TABLE stored_products ADD COLUMN is_active INTEGER NOT NULL DEFAULT 1"
            )
        c.execute("PRAGMA table_info(usage_products)")
        usage_columns = {safe_get(x, "name", "") for x in c.fetchall()}
        if "revision" not in usage_columns:
            c.execute(
                "ALTER TABLE usage_products ADD COLUMN revision INTEGER NOT NULL DEFAULT 0"
            )
        if "active" not in usage_columns:
            c.execute(
                "ALTER TABLE usage_products ADD COLUMN active INTEGER NOT NULL DEFAULT 1"
            )
        c.execute("PRAGMA table_info(sync_state)")
        sync_state_columns = {safe_get(x, "name", "") for x in c.fetchall()}
        if "baseline_ready" not in sync_state_columns:
            c.execute(
                "ALTER TABLE sync_state ADD COLUMN baseline_ready INTEGER NOT NULL DEFAULT 0"
            )
        if "scope_fingerprint" not in sync_state_columns:
            c.execute(
                "ALTER TABLE sync_state ADD COLUMN scope_fingerprint TEXT NOT NULL DEFAULT ''"
            )
        self.connection.commit()
        self._canonicalize_tracking_baseline_once()

    def _canonicalize_tracking_baseline_once(self) -> None:
        """Collapse historical tracking mirrors into the canonical local table."""

        marker = "tracking_baseline_canonical_2_18_0"
        if self.get_setting(marker, "") == "True":
            return
        from data.tracking_baseline import write_tracking_baseline_row

        conn = self.connection
        cursor = conn.cursor()
        try:
            cursor.execute("BEGIN IMMEDIATE")
            rows_to_write: list[tuple[dict, str]] = []
            existing_rows = cursor.execute(
                """
                SELECT payload, updated_at
                  FROM cloud_tracked_products
                 ORDER BY updated_at ASC
                """
            ).fetchall()
            has_v2 = cursor.execute(
                "SELECT 1 FROM sqlite_master WHERE type='table' AND name='tracking_records_v2'"
            ).fetchone()
            if has_v2:
                for row in cursor.execute(
                    """
                    SELECT branch_code, remote_id, payload_json, updated_at
                      FROM tracking_records_v2
                     ORDER BY updated_at ASC
                    """
                ).fetchall():
                    try:
                        payload = json.loads(str(row["payload_json"] or "{}"))
                    except (TypeError, ValueError, json.JSONDecodeError):
                        payload = {}
                    if isinstance(payload, dict):
                        payload.setdefault("branch", str(row["branch_code"] or ""))
                        payload.setdefault("doc_id", str(row["remote_id"] or ""))
                        rows_to_write.append((payload, str(row["updated_at"] or "")))
            for row in existing_rows:
                try:
                    payload = json.loads(str(row["payload"] or "{}"))
                except (TypeError, ValueError, json.JSONDecodeError):
                    continue
                if isinstance(payload, dict):
                    rows_to_write.append((payload, str(row["updated_at"] or "")))
            cursor.execute("DELETE FROM cloud_tracked_products")
            for payload, updated_at in sorted(rows_to_write, key=lambda item: item[1]):
                write_tracking_baseline_row(
                    conn,
                    payload,
                    updated_at=updated_at or None,
                )
            for table in (
                "tracking_records_v2",
                "tracking_remote_aliases",
                "tracking_sync_state",
            ):
                cursor.execute(f"DROP TABLE IF EXISTS {table}")
            cursor.execute(
                "INSERT OR REPLACE INTO settings(key,value) VALUES(?,?)",
                (marker, "True"),
            )
            conn.commit()
        except (Exception, *SERVICE_OPERATION_EXCEPTIONS):
            try:
                conn.rollback()
            except SERVICE_OPERATION_EXCEPTIONS:
                logger.debug("Tracking baseline canonicalization rollback failed", exc_info=True)
            logger.exception("Tracking baseline canonicalization failed")


class SerializedCursor:

    def __init__(self, cursor, lock):
        self._cursor = cursor
        self._lock = lock

    def execute(self, *args, **kwargs):
        with self._lock:
            return self._cursor.execute(*args, **kwargs)

    def executemany(self, *args, **kwargs):
        with self._lock:
            return self._cursor.executemany(*args, **kwargs)

    def fetchone(self, *args, **kwargs):
        with self._lock:
            return self._cursor.fetchone(*args, **kwargs)

    def fetchall(self, *args, **kwargs):
        with self._lock:
            return self._cursor.fetchall(*args, **kwargs)

    def __getattr__(self, name):
        return getattr(self._cursor, name)


class SerializedConnection:

    def __init__(self, connection, lock):
        self._connection = connection
        self._lock = lock

    def cursor(self, *args, **kwargs):
        with self._lock:
            return SerializedCursor(
                self._connection.cursor(*args, **kwargs), self._lock
            )

    def execute(self, *args, **kwargs):
        with self._lock:
            return self._connection.execute(*args, **kwargs)

    def executemany(self, *args, **kwargs):
        with self._lock:
            return self._connection.executemany(*args, **kwargs)

    def commit(self):
        with self._lock:
            return self._connection.commit()

    def rollback(self):
        with self._lock:
            return self._connection.rollback()

    def close(self):
        with self._lock:
            return self._connection.close()

    def __getattr__(self, name):
        return getattr(self._connection, name)


import logging
import sqlite3
import threading
from collections.abc import Callable
from typing import Any
from settings.config import db_file_path
from data.cloud_context import DatabaseCloudContextMixin
from data.settings_repo import DatabaseSettingsAlertMixin
from data.sync_repo import LocalSyncRepositoryMixin
from data.tracking_repository import DatabaseTrackingCatalogMixin
from data.usage_repository import DatabaseUsageCatalogMixin
from domain.runtime_state import RuntimeStateCore

logger = logging.getLogger(__name__)


class LocalDataStore(
    DatabaseCloudContextMixin,
    DatabaseTrackingCatalogMixin,
    DatabaseUsageCatalogMixin,
    DatabaseSettingsAlertMixin,
    LocalSyncRepositoryMixin,
    DatabaseSchemaMixin,
    DatabaseDefaultsMixin,
    UIFeedbackHandlersMixin,
):

    def __init__(self, app_state: Any | None = None):
        self.app_state = app_state or RuntimeStateCore()
        self.db_path = db_file_path()
        self.connection = None
        self._db_lock = threading.RLock()
        self._allowed_branches: list[str] = []
        self._active_branch: str = ""
        self._usage_refresh_event: threading.Event | None = None
        self._usage_refresh_result: list[dict[str, Any]] | None = None
        self._usage_refresh_started_at: float = 0.0
        self.last_message: str = ""
        self.last_error: str = ""
        self._ui_feedback_handlers: dict[str, Callable[..., Any] | None] = {
            "error": None,
            "info": None,
            "confirm": None,
        }
        self.connect()
        self.create_tables()
        self.ensure_default_settings()
        self._apply_threshold_notification_migration_once()

    def connect(self):
        raw_connection = sqlite3.connect(
            self.db_path, timeout=90.0, check_same_thread=False, isolation_level=None
        )
        raw_connection.row_factory = sqlite3.Row
        raw_connection.execute("PRAGMA foreign_keys=ON")
        raw_connection.execute("PRAGMA busy_timeout=60000")
        raw_connection.execute("PRAGMA journal_mode=WAL")
        raw_connection.execute("PRAGMA synchronous=NORMAL")
        raw_connection.execute("PRAGMA wal_autocheckpoint=500")
        raw_connection.execute("PRAGMA temp_store=MEMORY")
        raw_connection.execute("PRAGMA locking_mode=NORMAL")
        self.connection = SerializedConnection(raw_connection, self._db_lock)

    def _fresh_connection(self):
        conn = sqlite3.connect(self.db_path, timeout=90.0, isolation_level=None)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA foreign_keys=ON")
        conn.execute("PRAGMA busy_timeout=60000")
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA synchronous=NORMAL")
        conn.execute("PRAGMA wal_autocheckpoint=500")
        conn.execute("PRAGMA temp_store=MEMORY")
        conn.execute("PRAGMA locking_mode=NORMAL")
        return conn

    def close(self):
        try:
            if self.connection:
                self.connection.close()
        except SERVICE_OPERATION_EXCEPTIONS:
            logger.debug("LocalDataStore.close fallback failed", exc_info=True)


# --- package exports ---
__all__ = ["SerializedConnection", "SerializedCursor", "LocalDataStore"]
_SerializedCursor = SerializedCursor
_SerializedConnection = SerializedConnection
