from __future__ import annotations
import json
import sqlite3
from contextlib import closing
from datetime import datetime
from pathlib import Path
from domain.notification_models import AppNotification

_SCHEMA = """
CREATE TABLE IF NOT EXISTS notifications (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL,
    kind TEXT NOT NULL,
    title TEXT NOT NULL,
    message TEXT NOT NULL,
    severity TEXT NOT NULL,
    created_at TEXT NOT NULL,
    read_at TEXT NULL,
    deduplication_key TEXT NOT NULL,
    action_type TEXT NULL,
    action_payload TEXT NOT NULL DEFAULT '{}',
    expires_at TEXT NULL
);
CREATE UNIQUE INDEX IF NOT EXISTS ux_notifications_user_dedup
ON notifications(user_id, deduplication_key);
CREATE INDEX IF NOT EXISTS ix_notifications_user_unread
ON notifications(user_id, read_at, created_at DESC);
"""

class NotificationRepository:
    def __init__(self, database: Path) -> None:
        self.database = Path(database)
        self.database.parent.mkdir(parents=True, exist_ok=True)
        with closing(self._connect()) as conn:
            conn.executescript(_SCHEMA)

    def _connect(self) -> sqlite3.Connection:
        conn = sqlite3.connect(self.database, isolation_level=None)
        conn.row_factory = sqlite3.Row
        return conn

    def add(self, value: AppNotification) -> bool:
        payload = json.dumps(value.action_payload, ensure_ascii=False, separators=(",", ":"))
        with closing(self._connect()) as conn:
            cursor = conn.execute(
                """INSERT OR IGNORE INTO notifications
                (id,user_id,kind,title,message,severity,created_at,read_at,deduplication_key,action_type,action_payload,expires_at)
                VALUES (?,?,?,?,?,?,?,?,?,?,?,?)""",
                (
                    value.id, value.user_id, value.kind, value.title, value.message,
                    value.severity, value.created_at.isoformat(),
                    value.read_at.isoformat() if value.read_at else None,
                    value.deduplication_key, value.action_type, payload,
                    value.expires_at.isoformat() if value.expires_at else None,
                ),
            )
            return cursor.rowcount == 1

    def unread_count(self, user_id: str) -> int:
        with closing(self._connect()) as conn:
            row = conn.execute(
                "SELECT COUNT(*) AS n FROM notifications WHERE user_id=? AND read_at IS NULL",
                (user_id,),
            ).fetchone()
            return int(row["n"])

    def list_for_user(self, user_id: str, limit: int = 500) -> list[AppNotification]:
        with closing(self._connect()) as conn:
            rows = conn.execute(
                "SELECT * FROM notifications WHERE user_id=? ORDER BY created_at DESC LIMIT ?",
                (user_id, int(limit)),
            ).fetchall()
        return [self._from_row(row) for row in rows]

    def mark_read(self, user_id: str, notification_id: str) -> None:
        now = datetime.now().astimezone().isoformat()
        with closing(self._connect()) as conn:
            conn.execute(
                "UPDATE notifications SET read_at=COALESCE(read_at,?) WHERE user_id=? AND id=?",
                (now, user_id, notification_id),
            )

    def mark_all_read(self, user_id: str) -> None:
        now = datetime.now().astimezone().isoformat()
        with closing(self._connect()) as conn:
            conn.execute(
                "UPDATE notifications SET read_at=? WHERE user_id=? AND read_at IS NULL",
                (now, user_id),
            )

    def delete(self, user_id: str, notification_id: str) -> None:
        with closing(self._connect()) as conn:
            conn.execute("DELETE FROM notifications WHERE user_id=? AND id=?", (user_id, notification_id))

    def clear_user(self, user_id: str) -> None:
        with closing(self._connect()) as conn:
            conn.execute("DELETE FROM notifications WHERE user_id=?", (user_id,))

    @staticmethod
    def _from_row(row: sqlite3.Row) -> AppNotification:
        return AppNotification(
            id=row["id"], user_id=row["user_id"], kind=row["kind"],
            title=row["title"], message=row["message"], severity=row["severity"],
            created_at=datetime.fromisoformat(row["created_at"]),
            read_at=datetime.fromisoformat(row["read_at"]) if row["read_at"] else None,
            deduplication_key=row["deduplication_key"],
            action_type=row["action_type"],
            action_payload=json.loads(row["action_payload"] or "{}"),
            expires_at=datetime.fromisoformat(row["expires_at"]) if row["expires_at"] else None,
        )
