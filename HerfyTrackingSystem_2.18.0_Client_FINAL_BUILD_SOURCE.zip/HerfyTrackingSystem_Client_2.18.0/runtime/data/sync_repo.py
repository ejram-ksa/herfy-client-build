from __future__ import annotations

import json
import sqlite3
import uuid
from datetime import UTC, datetime
from typing import Any, Callable

from data.tracking_baseline import (
    delete_tracking_baseline_row,
    write_tracking_baseline_row,
)


def _utc_now() -> str:
    return datetime.now(UTC).isoformat()


class LocalSyncRepositoryMixin:
    """SQLite persistence for user/device scoped local-first synchronization."""

    def local_sync_is_authoritative(self) -> bool:
        """Whether the authenticated local-first worker owns remote reads/writes.

        Repository callers use this boundary to avoid starting an unrelated
        catalog or tracking refresh while the single cursor-owning worker is
        installing a baseline or applying deltas.
        """

        engine = getattr(self, "local_sync_engine", None)
        return bool(engine is not None and getattr(engine, "running", False))

    def wake_local_sync(self) -> bool:
        """Ask the authoritative worker to reconcile without opening new I/O."""

        engine = getattr(self, "local_sync_engine", None)
        if engine is None or not getattr(engine, "running", False):
            return False
        wake = getattr(engine, "wake", None)
        if callable(wake):
            wake()
        return True

    def enqueue_pending_operation(
        self,
        *,
        user_id: str,
        device_id: str,
        session_id: str,
        entity_type: str,
        entity_id: str,
        action: str,
        payload: dict[str, Any],
        branch_id: str = "",
        base_revision: int | None = None,
        operation_id: str = "",
    ) -> str:
        user = str(user_id or "").strip()
        device = str(device_id or "").strip()
        if not user or not device:
            raise ValueError("user_id and device_id are required")
        entity = str(entity_type or "").strip().lower()
        entity_key = str(entity_id or "").strip()
        if not entity or not entity_key:
            raise ValueError("entity_type and entity_id are required")
        normalized_action = str(action or "").strip().lower()
        if normalized_action not in {"create", "update", "upsert", "delete", "restore"}:
            raise ValueError(f"Unsupported sync action: {normalized_action or '<empty>'}")
        requested_id = str(operation_id or "").strip()
        op_id = requested_id or str(uuid.uuid4())
        now = _utc_now()
        serialized = json.dumps(payload or {}, ensure_ascii=False, sort_keys=True)
        with self._db_lock:
            # A pending operation has never left this device, so it is safe to
            # fold a newer local edit into it.  Do not fold retry/in-flight
            # operations: their request may already have reached the server and
            # operation_id must keep the exact original request for idempotency.
            if not requested_id:
                existing = self.connection.execute(
                    """
                    SELECT operation_id
                      FROM pending_operations
                     WHERE user_id = ? AND device_id = ?
                       AND entity_type = ? AND entity_id = ?
                       AND status = 'pending'
                     ORDER BY created_at DESC, operation_id DESC
                     LIMIT 1
                    """,
                    (user, device, entity, entity_key),
                ).fetchone()
                if existing:
                    op_id = str(existing["operation_id"])
                    self.connection.execute(
                        """
                        UPDATE pending_operations
                           SET session_id = ?, action = ?, branch_id = ?,
                               base_revision = ?, payload = ?, last_error = '',
                               updated_at = ?
                         WHERE operation_id = ?
                        """,
                        (
                            str(session_id or "").strip(),
                            str(action or "").strip().lower(),
                            str(branch_id or "").strip(),
                            base_revision,
                            serialized,
                            now,
                            op_id,
                        ),
                    )
                    self.connection.commit()
                    return op_id
            self.connection.execute(
                """
                INSERT INTO pending_operations(
                    operation_id, user_id, device_id, session_id,
                    entity_type, entity_id, action, branch_id,
                    base_revision, payload, status, retry_count,
                    last_error, created_at, updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending', 0, '', ?, ?)
                ON CONFLICT(operation_id) DO NOTHING
                """,
                (
                    op_id,
                    user,
                    device,
                    str(session_id or "").strip(),
                    entity,
                    entity_key,
                    normalized_action,
                    str(branch_id or "").strip(),
                    base_revision,
                    serialized,
                    now,
                    now,
                ),
            )
            self.connection.commit()
        return op_id

    @staticmethod
    def _decode_operation_rows(rows: list[Any]) -> list[dict[str, Any]]:
        result: list[dict[str, Any]] = []
        for row in rows:
            item = dict(row)
            try:
                payload = json.loads(str(item.get("payload") or "{}"))
            except (TypeError, ValueError, json.JSONDecodeError):
                payload = {}
            item["payload"] = payload if isinstance(payload, dict) else {}
            result.append(item)
        return result

    def pending_operations(
        self, user_id: str, device_id: str, *, limit: int = 50
    ) -> list[dict[str, Any]]:
        with self._db_lock:
            rows = self.connection.execute(
                """
                SELECT *
                  FROM pending_operations
                 WHERE user_id = ? AND device_id = ?
                   AND status IN ('pending', 'retry')
                 ORDER BY created_at, operation_id
                 LIMIT ?
                """,
                (
                    str(user_id or "").strip(),
                    str(device_id or "").strip(),
                    max(1, min(int(limit or 50), 50)),
                ),
            ).fetchall()
        return self._decode_operation_rows(rows)

    def claim_pending_operations(
        self, user_id: str, device_id: str, *, limit: int = 50
    ) -> list[dict[str, Any]]:
        """Atomically reserve one ordered operation per entity for delivery.

        The reservation prevents a second local edit from changing an operation
        whose HTTP request may already be in flight.  Selecting only the first
        operation for each entity preserves revision ordering without blocking
        unrelated entities in the same sync cycle.
        """

        user = str(user_id or "").strip()
        device = str(device_id or "").strip()
        wanted = max(1, min(int(limit or 50), 50))
        with self._db_lock:
            self.connection.execute("BEGIN IMMEDIATE")
            try:
                rows = self.connection.execute(
                    """
                    SELECT *
                      FROM pending_operations
                     WHERE user_id = ? AND device_id = ?
                       AND status IN ('pending', 'retry')
                     ORDER BY created_at, operation_id
                     LIMIT ?
                    """,
                    (user, device, wanted * 5),
                ).fetchall()
                selected: list[Any] = []
                seen: set[tuple[str, str]] = set()
                for row in rows:
                    key = (
                        str(row["entity_type"] or "").strip().lower(),
                        str(row["entity_id"] or "").strip(),
                    )
                    if key in seen:
                        continue
                    seen.add(key)
                    selected.append(row)
                    if len(selected) >= wanted:
                        break
                if selected:
                    self.connection.executemany(
                        """
                        UPDATE pending_operations
                           SET status = 'in_flight', updated_at = ?
                         WHERE operation_id = ? AND user_id = ? AND device_id = ?
                           AND status IN ('pending', 'retry')
                        """,
                        [
                            (_utc_now(), str(row["operation_id"]), user, device)
                            for row in selected
                        ],
                    )
                self.connection.commit()
            except Exception:
                self.connection.rollback()
                raise
        return self._decode_operation_rows(selected)

    def recover_inflight_operations(self, user_id: str, device_id: str) -> int:
        """Make interrupted idempotent operations eligible for a safe retry."""

        with self._db_lock:
            changed = self.connection.execute(
                """
                UPDATE pending_operations
                   SET status = 'retry',
                       last_error = CASE
                           WHEN COALESCE(last_error, '') = ''
                               THEN 'Sync worker restarted before the server response was received.'
                           ELSE last_error
                       END,
                       updated_at = ?
                 WHERE user_id = ? AND device_id = ? AND status = 'in_flight'
                """,
                (
                    _utc_now(),
                    str(user_id or "").strip(),
                    str(device_id or "").strip(),
                ),
            ).rowcount
            self.connection.commit()
        return int(changed or 0)

    def mark_operation_completed(
        self, operation_id: str, user_id: str, device_id: str
    ) -> None:
        with self._db_lock:
            self.connection.execute(
                """
                UPDATE pending_operations
                   SET status = 'completed', last_error = '', updated_at = ?
                 WHERE operation_id = ? AND user_id = ? AND device_id = ?
                """,
                (
                    _utc_now(),
                    str(operation_id or "").strip(),
                    str(user_id or "").strip(),
                    str(device_id or "").strip(),
                ),
            )
            self.connection.commit()

    def mark_operation_retry(
        self, operation_id: str, user_id: str, device_id: str, error: str
    ) -> None:
        with self._db_lock:
            self.connection.execute(
                """
                UPDATE pending_operations
                   SET status = 'retry',
                       retry_count = retry_count + 1,
                       last_error = ?,
                       updated_at = ?
                 WHERE operation_id = ? AND user_id = ? AND device_id = ?
                """,
                (
                    str(error or "")[:500],
                    _utc_now(),
                    str(operation_id or "").strip(),
                    str(user_id or "").strip(),
                    str(device_id or "").strip(),
                ),
            )
            self.connection.commit()

    def mark_operation_blocked(
        self,
        operation_id: str,
        user_id: str,
        device_id: str,
        *,
        status: str,
        error: str,
    ) -> None:
        """Stop retrying a conflict or a request the server permanently rejected."""

        resolved_status = str(status or "").strip().lower()
        if resolved_status not in {"conflict", "rejected"}:
            raise ValueError("Blocked sync status must be conflict or rejected")
        with self._db_lock:
            self.connection.execute(
                """
                UPDATE pending_operations
                   SET status = ?, last_error = ?, updated_at = ?
                 WHERE operation_id = ? AND user_id = ? AND device_id = ?
                """,
                (
                    resolved_status,
                    str(error or "")[:500],
                    _utc_now(),
                    str(operation_id or "").strip(),
                    str(user_id or "").strip(),
                    str(device_id or "").strip(),
                ),
            )
            self.connection.commit()

    def rebase_following_operations(
        self,
        *,
        user_id: str,
        device_id: str,
        entity_type: str,
        entity_id: str,
        server_revision: int,
        except_operation_id: str,
    ) -> int:
        """Advance unsent successors after an acknowledged entity revision."""

        revision = max(0, int(server_revision or 0))
        if revision <= 0:
            return 0
        user = str(user_id or "").strip()
        device = str(device_id or "").strip()
        entity = str(entity_type or "").strip().lower()
        key = str(entity_id or "").strip()
        skipped = str(except_operation_id or "").strip()
        with self._db_lock:
            rows = self.connection.execute(
                """
                SELECT operation_id, payload
                  FROM pending_operations
                 WHERE user_id = ? AND device_id = ?
                   AND entity_type = ? AND entity_id = ?
                   AND operation_id <> ?
                   AND status IN ('pending', 'retry')
                """,
                (user, device, entity, key, skipped),
            ).fetchall()
            updated = 0
            for row in rows:
                try:
                    payload = json.loads(str(row["payload"] or "{}"))
                except (TypeError, ValueError, json.JSONDecodeError):
                    payload = {}
                if not isinstance(payload, dict):
                    payload = {}
                payload["revision"] = revision
                self.connection.execute(
                    """
                    UPDATE pending_operations
                       SET base_revision = ?, payload = ?, updated_at = ?
                     WHERE operation_id = ?
                    """,
                    (
                        revision,
                        json.dumps(payload, ensure_ascii=False, sort_keys=True),
                        _utc_now(),
                        str(row["operation_id"]),
                    ),
                )
                updated += 1
            self.connection.commit()
        return updated

    def block_dependent_operations(
        self,
        *,
        user_id: str,
        device_id: str,
        entity_type: str,
        entity_id: str,
        status: str,
        error: str,
        except_operation_id: str,
    ) -> int:
        """Keep later edits behind a failed revision from being sent blindly."""

        resolved_status = str(status or "").strip().lower()
        if resolved_status not in {"conflict", "rejected"}:
            raise ValueError("Blocked sync status must be conflict or rejected")
        with self._db_lock:
            changed = self.connection.execute(
                """
                UPDATE pending_operations
                   SET status = ?, last_error = ?, updated_at = ?
                 WHERE user_id = ? AND device_id = ?
                   AND entity_type = ? AND entity_id = ?
                   AND operation_id <> ?
                   AND status IN ('pending', 'retry')
                """,
                (
                    resolved_status,
                    str(error or "")[:500],
                    _utc_now(),
                    str(user_id or "").strip(),
                    str(device_id or "").strip(),
                    str(entity_type or "").strip().lower(),
                    str(entity_id or "").strip(),
                    str(except_operation_id or "").strip(),
                ),
            ).rowcount
            self.connection.commit()
        return int(changed or 0)

    def operation_summary(self, user_id: str, device_id: str) -> dict[str, int]:
        """Return persistent outbox state suitable for a user-visible indicator."""

        counts = {
            "pending": 0,
            "retry": 0,
            "in_flight": 0,
            "conflict": 0,
            "rejected": 0,
            "queued": 0,
            "review": 0,
        }
        with self._db_lock:
            rows = self.connection.execute(
                """
                SELECT status, COUNT(*) AS count
                  FROM pending_operations
                 WHERE user_id = ? AND device_id = ?
                   AND status IN ('pending', 'retry', 'in_flight', 'conflict', 'rejected')
                 GROUP BY status
                """,
                (str(user_id or "").strip(), str(device_id or "").strip()),
            ).fetchall()
        for row in rows:
            status = str(row["status"] or "").strip().lower()
            if status in counts:
                counts[status] = int(row["count"] or 0)
        counts["queued"] = counts["pending"] + counts["retry"] + counts["in_flight"]
        counts["review"] = counts["conflict"] + counts["rejected"]
        return counts

    def blocked_operations(
        self, user_id: str, device_id: str, *, limit: int = 100
    ) -> list[dict[str, Any]]:
        with self._db_lock:
            rows = self.connection.execute(
                """
                SELECT *
                  FROM pending_operations
                 WHERE user_id = ? AND device_id = ?
                   AND status IN ('conflict', 'rejected')
                 ORDER BY updated_at DESC, operation_id DESC
                 LIMIT ?
                """,
                (
                    str(user_id or "").strip(),
                    str(device_id or "").strip(),
                    max(1, min(int(limit or 100), 250)),
                ),
            ).fetchall()
        return self._decode_operation_rows(rows)

    def discard_blocked_operation(
        self, operation_id: str, user_id: str, device_id: str
    ) -> bool:
        with self._db_lock:
            changed = self.connection.execute(
                """
                UPDATE pending_operations
                   SET status = 'discarded', updated_at = ?
                 WHERE operation_id = ? AND user_id = ? AND device_id = ?
                   AND status IN ('conflict', 'rejected')
                """,
                (
                    _utc_now(),
                    str(operation_id or "").strip(),
                    str(user_id or "").strip(),
                    str(device_id or "").strip(),
                ),
            ).rowcount
            self.connection.commit()
        return bool(changed)

    def discard_unsent_operations_for_entity(
        self,
        *,
        user_id: str,
        device_id: str,
        entity_type: str,
        entity_id: str,
    ) -> int:
        """Cancel only operations that are provably still local and unsent."""

        with self._db_lock:
            changed = self.connection.execute(
                """
                UPDATE pending_operations
                   SET status = 'discarded', updated_at = ?
                 WHERE user_id = ? AND device_id = ?
                   AND entity_type = ? AND entity_id = ?
                   AND status = 'pending'
                """,
                (
                    _utc_now(),
                    str(user_id or "").strip(),
                    str(device_id or "").strip(),
                    str(entity_type or "").strip().lower(),
                    str(entity_id or "").strip(),
                ),
            ).rowcount
            self.connection.commit()
        return int(changed or 0)

    def has_pending_operation_for_entity(
        self,
        *,
        user_id: str,
        device_id: str,
        entity_type: str,
        entity_id: str,
        conn: sqlite3.Connection | None = None,
    ) -> bool:
        query = """
            SELECT 1 FROM pending_operations
             WHERE user_id = ? AND device_id = ?
               AND entity_type = ? AND entity_id = ?
               AND status IN ('pending', 'retry', 'in_flight')
             LIMIT 1
        """
        params = (
            str(user_id or "").strip(),
            str(device_id or "").strip(),
            str(entity_type or "").strip().lower(),
            str(entity_id or "").strip(),
        )
        if conn is not None:
            return conn.execute(query, params).fetchone() is not None
        with self._db_lock:
            return self.connection.execute(query, params).fetchone() is not None

    @staticmethod
    def _baseline_int(value: Any, default: int = 0) -> int:
        try:
            return max(0, int(value if value is not None else default))
        except (TypeError, ValueError):
            return max(0, int(default))

    @staticmethod
    def _baseline_active(value: Any, default: bool = True) -> int:
        if value is None:
            return int(bool(default))
        if isinstance(value, bool):
            return int(value)
        return int(str(value).strip().lower() not in {"0", "false", "no", "off", ""})

    @classmethod
    def _write_stored_baseline_row(
        cls,
        conn: sqlite3.Connection,
        row: dict[str, Any],
        *,
        active_default: bool = True,
    ) -> None:
        material = str(
            row.get("material_number")
            or row.get("material")
            or row.get("entity_id")
            or ""
        ).strip()
        if not material:
            return
        name = str(row.get("name") or row.get("material_name") or material).strip()
        revision = cls._baseline_int(row.get("revision"))
        active = cls._baseline_active(
            row.get("is_active", row.get("active")), active_default
        )
        conn.execute(
            """
            INSERT INTO stored_products(material_number, name, revision, is_active)
            VALUES (?, ?, ?, ?)
            ON CONFLICT(material_number) DO UPDATE SET
                name=excluded.name,
                revision=MAX(stored_products.revision, excluded.revision),
                is_active=excluded.is_active
            """,
            (material, name or material, revision, active),
        )

    @classmethod
    def _write_usage_baseline_row(
        cls,
        conn: sqlite3.Connection,
        row: dict[str, Any],
        *,
        active_default: bool = True,
    ) -> None:
        material = str(
            row.get("material")
            or row.get("material_number")
            or row.get("entity_id")
            or ""
        ).strip()
        if not material:
            return
        name = str(row.get("name") or row.get("material_name") or material).strip()
        uom = str(row.get("uom") or row.get("unit") or "").strip()
        revision = cls._baseline_int(row.get("revision"))
        active = cls._baseline_active(
            row.get("active", row.get("is_active")), active_default
        )
        conn.execute(
            """
            INSERT INTO usage_products(material, name, uom, revision, active)
            VALUES (?, ?, ?, ?, ?)
            ON CONFLICT(material) DO UPDATE SET
                name=excluded.name,
                uom=CASE
                    WHEN excluded.uom <> '' THEN excluded.uom
                    ELSE usage_products.uom
                END,
                revision=MAX(usage_products.revision, excluded.revision),
                active=excluded.active
            """,
            (material, name or material, uom, revision, active),
        )

    def needs_sync_bootstrap(self, user_id: str, device_id: str) -> bool:
        with self._db_lock:
            row = self.connection.execute(
                """
                SELECT baseline_ready FROM sync_state
                 WHERE user_id=? AND device_id=?
                """,
                (str(user_id or "").strip(), str(device_id or "").strip()),
            ).fetchone()
        return not bool(row and int(row["baseline_ready"] or 0))

    def ensure_sync_scope(
        self, user_id: str, device_id: str, scope_fingerprint: str
    ) -> bool:
        """Invalidate a cursor when server authority or branch scope changes.

        A cursor is only meaningful for the precise set of entities visible to
        that user and device.  Reusing it after a role, branch or server change
        can silently skip data that has just become visible.
        """

        user = str(user_id or "").strip()
        device = str(device_id or "").strip()
        fingerprint = str(scope_fingerprint or "").strip()
        if not user or not device:
            raise ValueError("user_id and device_id are required")
        with self._db_lock:
            self.connection.execute("BEGIN IMMEDIATE")
            try:
                current = self.connection.execute(
                    """
                    SELECT scope_fingerprint FROM sync_state
                     WHERE user_id=? AND device_id=?
                    """,
                    (user, device),
                ).fetchone()
                if current and str(current["scope_fingerprint"] or "") == fingerprint:
                    self.connection.commit()
                    return False
                self.connection.execute(
                    "DELETE FROM applied_sync_events WHERE user_id=? AND device_id=?",
                    (user, device),
                )
                self.connection.execute(
                    """
                    INSERT INTO sync_state(
                        user_id, device_id, last_cursor, baseline_ready,
                        scope_fingerprint, updated_at
                    ) VALUES (?, ?, 0, 0, ?, ?)
                    ON CONFLICT(user_id, device_id) DO UPDATE SET
                        last_cursor=0,
                        baseline_ready=0,
                        scope_fingerprint=excluded.scope_fingerprint,
                        updated_at=excluded.updated_at
                    """,
                    (user, device, fingerprint, _utc_now()),
                )
                self.connection.commit()
                return True
            except Exception:
                self.connection.rollback()
                raise

    def mark_sync_bootstrap_ready(
        self, user_id: str, device_id: str, *, cursor: int | None = None
    ) -> None:
        user = str(user_id or "").strip()
        device = str(device_id or "").strip()
        with self._db_lock:
            current = self.connection.execute(
                "SELECT last_cursor FROM sync_state WHERE user_id=? AND device_id=?",
                (user, device),
            ).fetchone()
            resolved_cursor = self._baseline_int(
                cursor,
                self._baseline_int(current["last_cursor"] if current else 0),
            )
            self.connection.execute(
                """
                INSERT INTO sync_state(
                    user_id, device_id, last_cursor, baseline_ready, updated_at
                ) VALUES (?, ?, ?, 1, ?)
                ON CONFLICT(user_id, device_id) DO UPDATE SET
                    last_cursor=excluded.last_cursor,
                    baseline_ready=1,
                    updated_at=excluded.updated_at
                """,
                (user, device, resolved_cursor, _utc_now()),
            )
            self.connection.commit()

    def apply_sync_bootstrap(
        self,
        *,
        user_id: str,
        device_id: str,
        baseline: dict[str, Any],
    ) -> dict[str, Any]:
        """Atomically install a server baseline while retaining local edits.

        The server snapshot is authoritative for all included entity families.
        Pending, retrying and in-flight local operations are deliberately
        replayed last, so an older snapshot never erases an offline change the
        user can still see and resolve.
        """

        if not isinstance(baseline, dict):
            raise ValueError("sync bootstrap payload must be an object")
        user = str(user_id or "").strip()
        device = str(device_id or "").strip()
        if not user or not device:
            raise ValueError("user_id and device_id are required")
        included = baseline.get("included")
        included = included if isinstance(included, dict) else {}
        include_tracking = bool(
            self._baseline_active(
                included.get("tracking", "tracking_items" in baseline)
            )
        )
        include_stored = bool(
            self._baseline_active(
                included.get("stored_products", "stored_products" in baseline)
            )
        )
        include_usage = bool(
            self._baseline_active(
                included.get("usage_products", "usage_products" in baseline)
            )
        )
        tracking_rows = [
            row for row in baseline.get("tracking_items") or [] if isinstance(row, dict)
        ]
        stored_rows = [
            row
            for row in baseline.get("stored_products") or []
            if isinstance(row, dict)
        ]
        usage_rows = [
            row for row in baseline.get("usage_products") or [] if isinstance(row, dict)
        ]
        cursor = self._baseline_int(baseline.get("next_cursor", baseline.get("cursor")))
        domains: list[str] = []

        with self._db_lock:
            conn = self._fresh_connection()
            try:
                conn.execute("BEGIN IMMEDIATE")
                pending = self._decode_operation_rows(
                    conn.execute(
                        """
                        SELECT * FROM pending_operations
                         WHERE user_id=? AND device_id=?
                           AND status IN ('pending', 'retry', 'in_flight')
                         ORDER BY created_at, operation_id
                        """,
                        (user, device),
                    ).fetchall()
                )

                # A changed role or scope can remove an entire domain.  Do
                # not leave the prior user's cached data (or sendable edits)
                # visible merely because that domain is absent from the new
                # baseline.  The explicit `included: false` contract means
                # access was denied; mark affected local work reviewable and
                # purge the scoped copy before rendering the new session.
                def reject_excluded(entity_types: tuple[str, ...], reason: str) -> None:
                    placeholders = ",".join("?" for _ in entity_types)
                    conn.execute(
                        f"""
                        UPDATE pending_operations
                           SET status='rejected', last_error=?, updated_at=?
                         WHERE user_id=? AND device_id=?
                           AND entity_type IN ({placeholders})
                           AND status IN ('pending', 'retry', 'in_flight')
                        """,
                        [reason, _utc_now(), user, device, *entity_types],
                    )

                if "tracking" in included and not include_tracking:
                    conn.execute("DELETE FROM cloud_tracked_products")
                    reject_excluded(
                        ("tracking_item", "tracked_product", "tracking"),
                        "Tracking access is no longer granted for this session.",
                    )
                    domains.append("tracking")
                if "stored_products" in included and not include_stored:
                    conn.execute("DELETE FROM stored_products")
                    reject_excluded(
                        ("stored_product", "catalog_product", "product"),
                        "Catalog access is no longer granted for this session.",
                    )
                    domains.append("stored_products")
                if "usage_products" in included and not include_usage:
                    conn.execute("DELETE FROM usage_products")
                    reject_excluded(
                        ("usage", "usage_product", "usage_products", "catalog_usage"),
                        "Usage catalog access is no longer granted for this session.",
                    )
                    domains.append("usage_products")

                if include_tracking:
                    conn.execute("DELETE FROM cloud_tracked_products")
                    for row in tracking_rows:
                        write_tracking_baseline_row(
                            conn,
                            row,
                            fallback_document_id=(
                                row.get("entity_id") or row.get("entity_key") or ""
                            ),
                            fallback_branch=row.get("branch_id") or "",
                            updated_at=_utc_now(),
                        )
                    for operation in pending:
                        entity = str(operation.get("entity_type") or "").strip().lower()
                        if entity not in {
                            "tracking_item",
                            "tracked_product",
                            "tracking",
                        }:
                            continue
                        item_id = str(operation.get("entity_id") or "").strip()
                        if not item_id:
                            continue
                        if (
                            str(operation.get("action") or "").strip().lower()
                            == "delete"
                        ):
                            delete_tracking_baseline_row(
                                conn,
                                document_id=item_id,
                                branch=str(operation.get("branch_id") or ""),
                            )
                            continue
                        payload = dict(operation.get("payload") or {})
                        payload.setdefault("id", item_id)
                        payload.setdefault("doc_id", item_id)
                        payload.setdefault(
                            "branch_id", operation.get("branch_id") or ""
                        )
                        write_tracking_baseline_row(
                            conn,
                            payload,
                            fallback_document_id=item_id,
                            fallback_branch=operation.get("branch_id") or "",
                            updated_at=_utc_now(),
                        )
                    domains.append("tracking")

                if include_stored:
                    conn.execute("UPDATE stored_products SET is_active=0")
                    for row in stored_rows:
                        self._write_stored_baseline_row(conn, row)
                    for operation in pending:
                        if str(
                            operation.get("entity_type") or ""
                        ).strip().lower() not in {
                            "stored_product",
                            "catalog_product",
                            "product",
                        }:
                            continue
                        material = str(operation.get("entity_id") or "").strip()
                        if not material:
                            continue
                        payload = dict(operation.get("payload") or {})
                        payload.setdefault("material_number", material)
                        payload.setdefault(
                            "revision", operation.get("base_revision") or 0
                        )
                        if (
                            str(operation.get("action") or "").strip().lower()
                            == "delete"
                        ):
                            payload["is_active"] = False
                        else:
                            payload["is_active"] = True
                        self._write_stored_baseline_row(conn, payload)
                    domains.append("stored_products")

                if include_usage:
                    conn.execute("UPDATE usage_products SET active=0")
                    for row in usage_rows:
                        self._write_usage_baseline_row(conn, row)
                    for operation in pending:
                        if str(
                            operation.get("entity_type") or ""
                        ).strip().lower() not in {
                            "usage",
                            "usage_product",
                            "usage_products",
                            "catalog_usage",
                        }:
                            continue
                        material = str(operation.get("entity_id") or "").strip()
                        if not material:
                            continue
                        payload = dict(operation.get("payload") or {})
                        payload.setdefault("material", material)
                        payload.setdefault(
                            "revision", operation.get("base_revision") or 0
                        )
                        if (
                            str(operation.get("action") or "").strip().lower()
                            == "delete"
                        ):
                            payload["active"] = False
                        else:
                            payload["active"] = True
                        self._write_usage_baseline_row(conn, payload)
                    domains.append("usage_products")

                conn.execute(
                    "DELETE FROM applied_sync_events WHERE user_id=? AND device_id=?",
                    (user, device),
                )
                conn.execute(
                    """
                    INSERT INTO sync_state(
                        user_id, device_id, last_cursor, baseline_ready, updated_at
                    ) VALUES (?, ?, ?, 1, ?)
                    ON CONFLICT(user_id, device_id) DO UPDATE SET
                        last_cursor=excluded.last_cursor,
                        baseline_ready=1,
                        updated_at=excluded.updated_at
                    """,
                    (user, device, cursor, _utc_now()),
                )
                conn.commit()
            except Exception:
                conn.rollback()
                raise
            finally:
                conn.close()
        return {
            "cursor": cursor,
            "domains": domains,
            "tracking": len(tracking_rows) if include_tracking else 0,
            "stored_products": len(stored_rows) if include_stored else 0,
            "usage_products": len(usage_rows) if include_usage else 0,
        }

    def request_full_reconcile(self, user_id: str, device_id: str) -> None:
        """Replay the authoritative event log after a discarded blocked change."""

        user = str(user_id or "").strip()
        device = str(device_id or "").strip()
        with self._db_lock:
            self.connection.execute("BEGIN IMMEDIATE")
            try:
                self.connection.execute(
                    "DELETE FROM applied_sync_events WHERE user_id = ? AND device_id = ?",
                    (user, device),
                )
                self.connection.execute(
                    """
                    INSERT INTO sync_state(
                        user_id, device_id, last_cursor, baseline_ready, updated_at
                    ) VALUES (?, ?, 0, 0, ?)
                    ON CONFLICT(user_id, device_id) DO UPDATE SET
                        last_cursor = 0,
                        baseline_ready = 0,
                        updated_at = excluded.updated_at
                    """,
                    (user, device, _utc_now()),
                )
                self.connection.commit()
            except Exception:
                self.connection.rollback()
                raise

    def sync_cursor_for(self, user_id: str, device_id: str) -> int:
        with self._db_lock:
            row = self.connection.execute(
                """
                SELECT last_cursor FROM sync_state
                 WHERE user_id = ? AND device_id = ?
                """,
                (
                    str(user_id or "").strip(),
                    str(device_id or "").strip(),
                ),
            ).fetchone()
        return int(row["last_cursor"] if row else 0)

    def set_sync_cursor_for(self, user_id: str, device_id: str, cursor: int) -> None:
        with self._db_lock:
            self.connection.execute(
                """
                INSERT INTO sync_state(user_id, device_id, last_cursor, updated_at)
                VALUES (?, ?, ?, ?)
                ON CONFLICT(user_id, device_id) DO UPDATE SET
                    last_cursor = MAX(sync_state.last_cursor, excluded.last_cursor),
                    updated_at = excluded.updated_at
                """,
                (
                    str(user_id or "").strip(),
                    str(device_id or "").strip(),
                    max(0, int(cursor or 0)),
                    _utc_now(),
                ),
            )
            self.connection.commit()

    def apply_sync_events(
        self,
        *,
        user_id: str,
        device_id: str,
        events: list[dict[str, Any]],
        apply_event: Callable[[sqlite3.Connection, dict[str, Any]], None],
    ) -> int:
        user = str(user_id or "").strip()
        device = str(device_id or "").strip()
        ordered = sorted(
            (dict(event) for event in events if isinstance(event, dict)),
            key=lambda event: int(event.get("cursor") or 0),
        )
        highest = self.sync_cursor_for(user, device)
        conn = self._fresh_connection()
        try:
            conn.execute("BEGIN IMMEDIATE")
            for event in ordered:
                cursor = int(event.get("cursor") or 0)
                if cursor <= 0:
                    continue
                operation_id = str(event.get("operation_id") or "").strip()
                inserted = conn.execute(
                    """
                    INSERT OR IGNORE INTO applied_sync_events(
                        user_id, device_id, cursor, operation_id, applied_at
                    ) VALUES (?, ?, ?, ?, ?)
                    """,
                    (user, device, cursor, operation_id or None, _utc_now()),
                ).rowcount
                if inserted:
                    apply_event(conn, event)
                highest = max(highest, cursor)
            conn.execute(
                """
                INSERT INTO sync_state(user_id, device_id, last_cursor, updated_at)
                VALUES (?, ?, ?, ?)
                ON CONFLICT(user_id, device_id) DO UPDATE SET
                    last_cursor = MAX(sync_state.last_cursor, excluded.last_cursor),
                    updated_at = excluded.updated_at
                """,
                (user, device, highest, _utc_now()),
            )
            conn.commit()
            return highest
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    def reminder_was_shown(
        self,
        *,
        user_id: str,
        device_id: str,
        item_id: str,
        branch_id: str,
        threshold_days: int,
        expiry_date: str,
    ) -> bool:
        with self._db_lock:
            row = self.connection.execute(
                """
                SELECT 1 FROM shown_reminders
                 WHERE user_id=? AND device_id=? AND item_id=? AND branch_id=?
                   AND threshold_days=? AND expiry_date=?
                """,
                (
                    str(user_id or "").strip(),
                    str(device_id or "").strip(),
                    str(item_id or "").strip(),
                    str(branch_id or "").strip(),
                    int(threshold_days),
                    str(expiry_date or "").strip(),
                ),
            ).fetchone()
        return row is not None

    def mark_reminder_shown(
        self,
        *,
        user_id: str,
        device_id: str,
        item_id: str,
        branch_id: str,
        threshold_days: int,
        expiry_date: str,
    ) -> bool:
        with self._db_lock:
            inserted = self.connection.execute(
                """
                INSERT OR IGNORE INTO shown_reminders(
                    user_id, device_id, item_id, branch_id,
                    threshold_days, expiry_date, shown_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    str(user_id or "").strip(),
                    str(device_id or "").strip(),
                    str(item_id or "").strip(),
                    str(branch_id or "").strip(),
                    int(threshold_days),
                    str(expiry_date or "").strip(),
                    _utc_now(),
                ),
            ).rowcount
            self.connection.commit()
        return bool(inserted)

    def user_device_setting(
        self, user_id: str, device_id: str, key: str, default: str = ""
    ) -> str:
        with self._db_lock:
            row = self.connection.execute(
                """
                SELECT value FROM user_device_settings
                 WHERE user_id=? AND device_id=? AND key=?
                """,
                (
                    str(user_id or "").strip(),
                    str(device_id or "").strip(),
                    str(key or "").strip(),
                ),
            ).fetchone()
        return str(row["value"] if row else default)

    def set_user_device_setting(
        self, user_id: str, device_id: str, key: str, value: Any
    ) -> None:
        with self._db_lock:
            self.connection.execute(
                """
                INSERT INTO user_device_settings(user_id, device_id, key, value, updated_at)
                VALUES (?, ?, ?, ?, ?)
                ON CONFLICT(user_id, device_id, key) DO UPDATE SET
                    value=excluded.value, updated_at=excluded.updated_at
                """,
                (
                    str(user_id or "").strip(),
                    str(device_id or "").strip(),
                    str(key or "").strip(),
                    str(value),
                    _utc_now(),
                ),
            )
            self.connection.commit()
