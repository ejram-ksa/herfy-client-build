# Herfy Tracking System 2.18.0 — GitHub Auto Build

This repository package contains the approved Windows client source archive and a GitHub Actions workflow that validates, builds, and packages the Windows application and installer automatically on every relevant push to `main`.

The source archive is verified before extraction using SHA-256:

`836a90a4e16716b7106e6aaa323d2f88f70350f96228f980872fa23385100814`

Expected artifact: `HerfyTrackingSystem-2.18.0-Windows`.
