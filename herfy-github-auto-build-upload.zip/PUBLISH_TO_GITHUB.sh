#!/usr/bin/env bash
set -euo pipefail

EXPECTED_REPO="ejram-ksa/herfy-client-build"
SOURCE_ZIP="source/HerfyTrackingSystem_2.18.0_RELEASE_SOURCE.zip"
EXPECTED_SHA256="836a90a4e16716b7106e6aaa323d2f88f70350f96228f980872fa23385100814"
WORKFLOW=".github/workflows/build-windows.yml"

if ! git rev-parse --is-inside-work-tree >/dev/null 2>&1; then
  echo "ERROR: Run this command inside the GitHub Codespace for ${EXPECTED_REPO}." >&2
  exit 1
fi

REMOTE_URL="$(git remote get-url origin 2>/dev/null || true)"
case "$REMOTE_URL" in
  *"${EXPECTED_REPO}"*) ;;
  *)
    echo "ERROR: Wrong repository. Expected ${EXPECTED_REPO}; origin=${REMOTE_URL:-missing}" >&2
    exit 1
    ;;
esac

[[ -f "$SOURCE_ZIP" ]] || { echo "ERROR: Missing $SOURCE_ZIP" >&2; exit 1; }
[[ -f "$WORKFLOW" ]] || { echo "ERROR: Missing $WORKFLOW" >&2; exit 1; }

ACTUAL_SHA256="$(sha256sum "$SOURCE_ZIP" | awk '{print $1}')"
if [[ "$ACTUAL_SHA256" != "$EXPECTED_SHA256" ]]; then
  echo "ERROR: Source SHA256 mismatch." >&2
  echo "expected=$EXPECTED_SHA256" >&2
  echo "actual=$ACTUAL_SHA256" >&2
  exit 1
fi

git config user.name "ejram-ksa"
git config user.email "217879652+ejram-ksa@users.noreply.github.com"

git add "$WORKFLOW" "$SOURCE_ZIP" README.md PUBLISH_TO_GITHUB.sh
if git diff --cached --quiet; then
  echo "No repository changes detected. The required files are already committed."
else
  git commit -m "Build Herfy Tracking System 2.18.0"
fi

git push origin HEAD:main

echo "HERFY_GITHUB_UPLOAD_OK"
echo "GitHub Actions will start automatically from the push to main."
