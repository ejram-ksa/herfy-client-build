"""Package entry point for running Herfy Tracking System from the source root."""

from __future__ import annotations
from main import main

if __name__ == "__main__":
    raise SystemExit(main())
