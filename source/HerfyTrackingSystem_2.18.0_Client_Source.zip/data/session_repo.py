from __future__ import annotations
import logging
from dataclasses import dataclass
from core.errors import SERVICE_OPERATION_EXCEPTIONS
from core.booleans import parse_bool
from domain.access_policy import PermissionContext
from pathlib import Path
from typing import TYPE_CHECKING, Any
from settings.config import runtime_cache_path
from data.secure_store import read_secure_json, write_secure_json
from core.files import read_json_dict, write_json_dict

if TYPE_CHECKING:
    from domain.user import AuthSession, UserProfile
logger = logging.getLogger(__name__)


def _safe_int(value: Any, default: int) -> int:
    try:
        return int(float(value))
    except (TypeError, ValueError, OverflowError):
        return int(default)


@dataclass
class StoredSessionSnapshot:
    remember: bool = False
    token: str = ""
    refresh_token: str = ""
    expires_in: int = 3600
    username: str = ""
    role: str = ""
    branches: list[str] | None = None
    saved_at: int = 0
    device_id: str = ""
    permission_context_payload: dict[str, Any] | None = None

    def to_dict(self) -> dict[str, Any]:
        return {
            "remember": bool(self.remember),
            "token": str(self.token or "").strip(),
            "refresh_token": str(self.refresh_token or "").strip(),
            "expires_in": int(self.expires_in or 3600),
            "username": str(self.username or "").strip(),
            "role": str(self.role or "").strip(),
            "branches": [
                str(item).strip() for item in self.branches or [] if str(item).strip()
            ],
            "saved_at": int(self.saved_at or 0),
            "device_id": str(self.device_id or "").strip(),
            "permission_context": (
                self.permission_context_payload
                if isinstance(self.permission_context_payload, dict)
                else {}
            ),
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any] | None) -> StoredSessionSnapshot:
        payload = data if isinstance(data, dict) else {}
        branches = (
            payload.get("branches") if isinstance(payload.get("branches"), list) else []
        )
        return cls(
            remember=parse_bool(payload.get("remember"), False),
            token=str(payload.get("token") or "").strip(),
            refresh_token=str(payload.get("refresh_token") or "").strip(),
            expires_in=_safe_int(payload.get("expires_in") or 3600, 3600),
            username=str(payload.get("username") or "").strip(),
            role=str(payload.get("role") or "").strip(),
            branches=[str(item).strip() for item in branches if str(item).strip()],
            saved_at=_safe_int(payload.get("saved_at") or 0, 0),
            device_id=str(payload.get("device_id") or "").strip(),
            permission_context_payload=(
                payload.get("permission_context")
                if isinstance(payload.get("permission_context"), dict)
                else {}
            ),
        )


@dataclass
class LoginFormState:
    username: str = ""
    remember: bool = False

    def to_dict(self) -> dict[str, Any]:
        return {
            "username": str(self.username or "").strip(),
            "remember": bool(self.remember),
        }

    @classmethod
    def from_dict(cls, data: dict[str, Any] | None) -> LoginFormState:
        payload = data if isinstance(data, dict) else {}
        return cls(
            username=str(payload.get("username") or "").strip(),
            remember=parse_bool(payload.get("remember"), False),
        )


class SessionStore:

    def __init__(
        self,
        session_file: str | Path | None = None,
        login_state_file: str | Path | None = None,
    ):
        self.session_file = Path(
            session_file or runtime_cache_path("session/session.json")
        )
        self.login_state_file = Path(
            login_state_file or runtime_cache_path("session/login_state.json")
        )
        self.session_file.parent.mkdir(parents=True, exist_ok=True)
        self.login_state_file.parent.mkdir(parents=True, exist_ok=True)

    def load_snapshot(self) -> StoredSessionSnapshot | None:
        try:
            payload = read_secure_json(self.session_file)
            snapshot = StoredSessionSnapshot.from_dict(payload)
            if not snapshot.remember:
                return None
            if not snapshot.refresh_token:
                return None
            return snapshot
        except SERVICE_OPERATION_EXCEPTIONS:
            logger.warning("Stored session snapshot was ignored", exc_info=True)
            return None

    def load_login_form_state(self) -> LoginFormState | None:
        payload = read_json_dict(self.login_state_file)
        state = LoginFormState.from_dict(payload)
        if state.username or state.remember:
            return state
        snapshot = self.load_snapshot()
        if snapshot is not None:
            return LoginFormState(
                username=snapshot.username, remember=snapshot.remember
            )
        return None

    def save_login_form_state(
        self, *, username: str = "", remember: bool = False
    ) -> None:
        state = LoginFormState(
            username=str(username or "").strip(), remember=bool(remember)
        )
        write_json_dict(self.login_state_file, state.to_dict(), ensure_ascii=False)

    def save(
        self,
        *,
        session: AuthSession,
        profile: UserProfile | None,
        remember: bool,
        permission_context: PermissionContext | None = None,
        saved_at: int = 0,
    ) -> None:
        username = str(
            getattr(profile, "username", "") or getattr(session, "uid", "") or ""
        ).strip()
        self.save_login_form_state(username=username, remember=bool(remember))
        if not remember:
            self.clear()
            return
        del permission_context
        refresh_token = str(getattr(session, "refresh_token", "") or "").strip()
        if not refresh_token:
            self.clear()
            return
        snapshot = StoredSessionSnapshot(
            remember=True,
            token="",
            refresh_token=refresh_token,
            expires_in=int(getattr(session, "expires_in", 3600) or 3600),
            username=username,
            role="",
            branches=[],
            saved_at=int(saved_at or 0),
            device_id=str(getattr(session, "device_id", "") or "").strip(),
            permission_context_payload={},
        )
        write_secure_json(self.session_file, snapshot.to_dict(), ensure_ascii=False)

    def clear(self) -> None:
        try:
            if self.session_file.exists():
                self.session_file.unlink()
        except SERVICE_OPERATION_EXCEPTIONS:
            logger.debug("SessionStore.clear fallback failed", exc_info=True)
