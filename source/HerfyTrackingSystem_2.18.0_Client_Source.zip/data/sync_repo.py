from __future__ import annotations

import json
import sqlite3
import uuid
from datetime import UTC, datetime
from typing import Any, Callable


def _utc_now() -> str:
    return datetime.now(UTC).isoformat()


class LocalSyncRepositoryMixin:
    """SQLite persistence for user/device scoped local-first synchronization."""

    def enqueue_pending_operation(
        self,
        *,
        user_id: str,
        device_id: str,
        session_id: str,
        entity_type: str,
        entity_id: str,
        action: str,
        payload: dict[str, Any],
        branch_id: str = "",
        base_revision: int | None = None,
        operation_id: str = "",
    ) -> str:
        user = str(user_id or "").strip()
        device = str(device_id or "").strip()
        if not user or not device:
            raise ValueError("user_id and device_id are required")
        op_id = str(operation_id or "").strip() or str(uuid.uuid4())
        now = _utc_now()
        serialized = json.dumps(payload or {}, ensure_ascii=False, sort_keys=True)
        with self._db_lock:
            self.connection.execute(
                """
                INSERT INTO pending_operations(
                    operation_id, user_id, device_id, session_id,
                    entity_type, entity_id, action, branch_id,
                    base_revision, payload, status, retry_count,
                    last_error, created_at, updated_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, 'pending', 0, '', ?, ?)
                ON CONFLICT(operation_id) DO NOTHING
                """,
                (
                    op_id,
                    user,
                    device,
                    str(session_id or "").strip(),
                    str(entity_type or "").strip(),
                    str(entity_id or "").strip(),
                    str(action or "").strip().lower(),
                    str(branch_id or "").strip(),
                    base_revision,
                    serialized,
                    now,
                    now,
                ),
            )
            self.connection.commit()
        return op_id

    def pending_operations(
        self, user_id: str, device_id: str, *, limit: int = 50
    ) -> list[dict[str, Any]]:
        with self._db_lock:
            rows = self.connection.execute(
                """
                SELECT *
                  FROM pending_operations
                 WHERE user_id = ? AND device_id = ?
                   AND status IN ('pending', 'retry')
                 ORDER BY created_at, operation_id
                 LIMIT ?
                """,
                (
                    str(user_id or "").strip(),
                    str(device_id or "").strip(),
                    max(1, min(int(limit or 50), 50)),
                ),
            ).fetchall()
        result: list[dict[str, Any]] = []
        for row in rows:
            item = dict(row)
            try:
                item["payload"] = json.loads(str(item.get("payload") or "{}"))
            except json.JSONDecodeError:
                item["payload"] = {}
            result.append(item)
        return result

    def mark_operation_completed(
        self, operation_id: str, user_id: str, device_id: str
    ) -> None:
        with self._db_lock:
            self.connection.execute(
                """
                UPDATE pending_operations
                   SET status = 'completed', last_error = '', updated_at = ?
                 WHERE operation_id = ? AND user_id = ? AND device_id = ?
                """,
                (
                    _utc_now(),
                    str(operation_id or "").strip(),
                    str(user_id or "").strip(),
                    str(device_id or "").strip(),
                ),
            )
            self.connection.commit()

    def mark_operation_retry(
        self, operation_id: str, user_id: str, device_id: str, error: str
    ) -> None:
        with self._db_lock:
            self.connection.execute(
                """
                UPDATE pending_operations
                   SET status = 'retry',
                       retry_count = retry_count + 1,
                       last_error = ?,
                       updated_at = ?
                 WHERE operation_id = ? AND user_id = ? AND device_id = ?
                """,
                (
                    str(error or "")[:500],
                    _utc_now(),
                    str(operation_id or "").strip(),
                    str(user_id or "").strip(),
                    str(device_id or "").strip(),
                ),
            )
            self.connection.commit()

    def sync_cursor_for(self, user_id: str, device_id: str) -> int:
        with self._db_lock:
            row = self.connection.execute(
                """
                SELECT last_cursor FROM sync_state
                 WHERE user_id = ? AND device_id = ?
                """,
                (
                    str(user_id or "").strip(),
                    str(device_id or "").strip(),
                ),
            ).fetchone()
        return int(row["last_cursor"] if row else 0)

    def set_sync_cursor_for(
        self, user_id: str, device_id: str, cursor: int
    ) -> None:
        with self._db_lock:
            self.connection.execute(
                """
                INSERT INTO sync_state(user_id, device_id, last_cursor, updated_at)
                VALUES (?, ?, ?, ?)
                ON CONFLICT(user_id, device_id) DO UPDATE SET
                    last_cursor = MAX(sync_state.last_cursor, excluded.last_cursor),
                    updated_at = excluded.updated_at
                """,
                (
                    str(user_id or "").strip(),
                    str(device_id or "").strip(),
                    max(0, int(cursor or 0)),
                    _utc_now(),
                ),
            )
            self.connection.commit()

    def apply_sync_events(
        self,
        *,
        user_id: str,
        device_id: str,
        events: list[dict[str, Any]],
        apply_event: Callable[[sqlite3.Connection, dict[str, Any]], None],
    ) -> int:
        user = str(user_id or "").strip()
        device = str(device_id or "").strip()
        ordered = sorted(
            (dict(event) for event in events if isinstance(event, dict)),
            key=lambda event: int(event.get("cursor") or 0),
        )
        highest = self.sync_cursor_for(user, device)
        conn = self._fresh_connection()
        try:
            conn.execute("BEGIN IMMEDIATE")
            for event in ordered:
                cursor = int(event.get("cursor") or 0)
                if cursor <= 0:
                    continue
                operation_id = str(event.get("operation_id") or "").strip()
                inserted = conn.execute(
                    """
                    INSERT OR IGNORE INTO applied_sync_events(
                        user_id, device_id, cursor, operation_id, applied_at
                    ) VALUES (?, ?, ?, ?, ?)
                    """,
                    (user, device, cursor, operation_id or None, _utc_now()),
                ).rowcount
                if inserted:
                    apply_event(conn, event)
                highest = max(highest, cursor)
            conn.execute(
                """
                INSERT INTO sync_state(user_id, device_id, last_cursor, updated_at)
                VALUES (?, ?, ?, ?)
                ON CONFLICT(user_id, device_id) DO UPDATE SET
                    last_cursor = MAX(sync_state.last_cursor, excluded.last_cursor),
                    updated_at = excluded.updated_at
                """,
                (user, device, highest, _utc_now()),
            )
            conn.commit()
            return highest
        except Exception:
            conn.rollback()
            raise
        finally:
            conn.close()

    def reminder_was_shown(
        self,
        *,
        user_id: str,
        device_id: str,
        item_id: str,
        branch_id: str,
        threshold_days: int,
        expiry_date: str,
    ) -> bool:
        with self._db_lock:
            row = self.connection.execute(
                """
                SELECT 1 FROM shown_reminders
                 WHERE user_id=? AND device_id=? AND item_id=? AND branch_id=?
                   AND threshold_days=? AND expiry_date=?
                """,
                (
                    str(user_id or "").strip(),
                    str(device_id or "").strip(),
                    str(item_id or "").strip(),
                    str(branch_id or "").strip(),
                    int(threshold_days),
                    str(expiry_date or "").strip(),
                ),
            ).fetchone()
        return row is not None

    def mark_reminder_shown(
        self,
        *,
        user_id: str,
        device_id: str,
        item_id: str,
        branch_id: str,
        threshold_days: int,
        expiry_date: str,
    ) -> bool:
        with self._db_lock:
            inserted = self.connection.execute(
                """
                INSERT OR IGNORE INTO shown_reminders(
                    user_id, device_id, item_id, branch_id,
                    threshold_days, expiry_date, shown_at
                ) VALUES (?, ?, ?, ?, ?, ?, ?)
                """,
                (
                    str(user_id or "").strip(),
                    str(device_id or "").strip(),
                    str(item_id or "").strip(),
                    str(branch_id or "").strip(),
                    int(threshold_days),
                    str(expiry_date or "").strip(),
                    _utc_now(),
                ),
            ).rowcount
            self.connection.commit()
        return bool(inserted)

    def user_device_setting(
        self, user_id: str, device_id: str, key: str, default: str = ""
    ) -> str:
        with self._db_lock:
            row = self.connection.execute(
                """
                SELECT value FROM user_device_settings
                 WHERE user_id=? AND device_id=? AND key=?
                """,
                (
                    str(user_id or "").strip(),
                    str(device_id or "").strip(),
                    str(key or "").strip(),
                ),
            ).fetchone()
        return str(row["value"] if row else default)

    def set_user_device_setting(
        self, user_id: str, device_id: str, key: str, value: Any
    ) -> None:
        with self._db_lock:
            self.connection.execute(
                """
                INSERT INTO user_device_settings(user_id, device_id, key, value, updated_at)
                VALUES (?, ?, ?, ?, ?)
                ON CONFLICT(user_id, device_id, key) DO UPDATE SET
                    value=excluded.value, updated_at=excluded.updated_at
                """,
                (
                    str(user_id or "").strip(),
                    str(device_id or "").strip(),
                    str(key or "").strip(),
                    str(value),
                    _utc_now(),
                ),
            )
            self.connection.commit()
