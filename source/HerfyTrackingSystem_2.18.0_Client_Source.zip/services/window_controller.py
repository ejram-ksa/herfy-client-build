from __future__ import annotations

import logging
from dataclasses import dataclass
from enum import Enum
from typing import Any

from core.errors import UI_OPERATION_EXCEPTIONS

logger = logging.getLogger(__name__)


class WindowState(str, Enum):
    CREATED = "CREATED"
    VISIBLE = "VISIBLE"
    MINIMIZED = "MINIMIZED"
    TRAY_HIDDEN = "TRAY_HIDDEN"
    RESTORING = "RESTORING"
    SHUTTING_DOWN = "SHUTTING_DOWN"


@dataclass(frozen=True, slots=True)
class ActivationCommand:
    command: str = "activate"
    route: str | None = None
    tracking_key: dict[str, Any] | None = None


class WindowController:
    def __init__(self, window: Any) -> None:
        self.window = window
        self.state = WindowState.CREATED

    def show(self) -> None:
        self.window.show()
        self.state = WindowState.VISIBLE
        self._log("window.transition")

    def hide_to_tray(self) -> None:
        self.window.hide()
        self.state = WindowState.TRAY_HIDDEN
        self._log("window.transition")

    def restore(self, command: ActivationCommand | None = None) -> None:
        self.state = WindowState.RESTORING
        restore = getattr(self.window, "_restore_from_tray", None)
        if callable(restore):
            restore()
        else:
            if hasattr(self.window, "showNormal") and self.window.isMinimized():
                self.window.showNormal()
            elif hasattr(self.window, "show") and (not self.window.isVisible()):
                self.window.show()
            if hasattr(self.window, "raise_"):
                self.window.raise_()
            if hasattr(self.window, "activateWindow"):
                self.window.activateWindow()
        self._activate_route(command)
        self.state = WindowState.VISIBLE
        self._log("window.transition")

    def shutting_down(self) -> None:
        self.state = WindowState.SHUTTING_DOWN
        self._log("window.transition")

    def _activate_route(self, command: ActivationCommand | None) -> None:
        if command is None or command.route != "tracking":
            return
        opener = getattr(self.window, "open_tracking_record", None)
        if callable(opener):
            try:
                opener(command.tracking_key or {})
            except UI_OPERATION_EXCEPTIONS:
                logger.debug("Tracking activation route failed", exc_info=True)

    def _log(self, event: str) -> None:
        logger.info(event, extra={"state": self.state.value})


def window_controller(window: Any) -> WindowController:
    existing = getattr(window, "_window_controller", None)
    if isinstance(existing, WindowController):
        return existing
    created = WindowController(window)
    setattr(window, "_window_controller", created)
    return created
