from __future__ import annotations

import json
import logging
import threading
import time
from dataclasses import dataclass
from typing import Any, Callable

logger = logging.getLogger(__name__)


@dataclass(frozen=True, slots=True)
class SyncIdentity:
    user_id: str
    device_id: str
    session_id: str
    generation: int


class LocalFirstSyncEngine:
    """One background delta-sync worker bound to one authenticated identity."""

    def __init__(
        self,
        repository: Any,
        *,
        on_changes: Callable[[dict[str, Any]], None] | None = None,
        generation_is_current: Callable[[int], bool] | None = None,
    ) -> None:
        self.repository = repository
        self.on_changes = on_changes
        self.generation_is_current = generation_is_current
        self._lock = threading.RLock()
        self._wake = threading.Event()
        self._stop = threading.Event()
        self._thread: threading.Thread | None = None
        self._identity: SyncIdentity | None = None
        self._api_client: Any | None = None
        self._allowed_branches: tuple[str, ...] = ()
        self._all_branches = False
        self._backoff_seconds = 1.0

    @property
    def running(self) -> bool:
        thread = self._thread
        return bool(thread and thread.is_alive() and not self._stop.is_set())

    def start(
        self,
        *,
        user_id: str,
        device_id: str,
        session_id: str,
        generation: int,
        api_client: Any,
        allowed_branches: list[str] | tuple[str, ...],
        all_branches: bool,
    ) -> None:
        identity = SyncIdentity(
            user_id=str(user_id or "").strip(),
            device_id=str(device_id or "").strip(),
            session_id=str(session_id or "").strip(),
            generation=int(generation),
        )
        if not identity.user_id or not identity.device_id or api_client is None:
            raise ValueError("Authenticated user, device, and API client are required")
        self.stop()
        with self._lock:
            self._identity = identity
            self._api_client = api_client
            self._allowed_branches = tuple(
                dict.fromkeys(
                    str(branch or "").strip()
                    for branch in allowed_branches or ()
                    if str(branch or "").strip()
                )
            )
            self._all_branches = bool(all_branches)
            self._backoff_seconds = 1.0
            self._stop.clear()
            self._wake.set()
            self._thread = threading.Thread(
                target=self._run,
                name=f"herfy-sync-{identity.user_id}",
                daemon=True,
            )
            self._thread.start()

    def stop(self, timeout: float = 4.0) -> None:
        with self._lock:
            thread = self._thread
            self._stop.set()
            self._wake.set()
        if thread and thread.is_alive() and thread is not threading.current_thread():
            thread.join(timeout=max(0.0, float(timeout)))
        with self._lock:
            self._thread = None
            self._api_client = None
            self._identity = None
            self._allowed_branches = ()
            self._all_branches = False
            self._wake.clear()

    def wake(self) -> None:
        if self.running:
            self._wake.set()

    def _identity_is_current(self, identity: SyncIdentity) -> bool:
        current = self._identity
        if current != identity or self._stop.is_set():
            return False
        checker = self.generation_is_current
        return bool(checker(identity.generation)) if callable(checker) else True

    def _run(self) -> None:
        while not self._stop.is_set():
            self._wake.wait(timeout=30.0)
            self._wake.clear()
            identity = self._identity
            if identity is None or not self._identity_is_current(identity):
                continue
            try:
                changed = self.sync_once(identity)
                self._backoff_seconds = 1.0
                if changed and callable(self.on_changes):
                    self.on_changes(changed)
            except Exception as exc:  # background boundary
                logger.warning("Background sync failed: %s", type(exc).__name__)
                wait_for = min(self._backoff_seconds, 60.0)
                self._backoff_seconds = min(wait_for * 2.0, 60.0)
                self._stop.wait(wait_for)

    def sync_once(self, identity: SyncIdentity | None = None) -> dict[str, Any]:
        identity = identity or self._identity
        api_client = self._api_client
        if identity is None or api_client is None:
            return {"pushed": 0, "pulled": 0}
        if not self._identity_is_current(identity):
            return {"pushed": 0, "pulled": 0, "stale": True}

        pending = self.repository.pending_operations(
            identity.user_id, identity.device_id, limit=50
        )
        pushed = 0
        if pending:
            payloads = [self._pending_payload(row, identity) for row in pending]
            try:
                result = api_client.push_sync_changes(payloads)
            except Exception as exc:
                for row in pending:
                    self.repository.mark_operation_retry(
                        row["operation_id"],
                        identity.user_id,
                        identity.device_id,
                        str(exc),
                    )
                raise
            accepted = {
                str(item.get("operation_id") or "").strip()
                for item in (result.get("results") or result.get("changes") or [])
                if isinstance(item, dict)
                and str(item.get("status") or "ok").lower()
                in {"ok", "accepted", "duplicate", "idempotent"}
            }
            if not accepted and bool(result.get("ok", False)):
                accepted = {str(row["operation_id"]) for row in pending}
            for row in pending:
                op_id = str(row["operation_id"])
                if op_id in accepted:
                    self.repository.mark_operation_completed(
                        op_id, identity.user_id, identity.device_id
                    )
                    pushed += 1
                else:
                    self.repository.mark_operation_retry(
                        op_id,
                        identity.user_id,
                        identity.device_id,
                        "Server did not acknowledge operation",
                    )

        if not self._identity_is_current(identity):
            return {"pushed": pushed, "pulled": 0, "stale": True}

        cursor = self.repository.sync_cursor_for(
            identity.user_id, identity.device_id
        )
        branch_ids = [] if self._all_branches else list(self._allowed_branches)
        pulled_payload = api_client.pull_sync_changes(
            cursor=cursor,
            branch_ids=branch_ids,
        )
        events = pulled_payload.get("events")
        if not isinstance(events, list):
            events = pulled_payload.get("changes")
        if not isinstance(events, list):
            events = []

        next_cursor = self.repository.apply_sync_events(
            user_id=identity.user_id,
            device_id=identity.device_id,
            events=events,
            apply_event=self._apply_event,
        )
        server_cursor = int(
            pulled_payload.get("next_cursor")
            or pulled_payload.get("cursor")
            or next_cursor
            or 0
        )
        self.repository.set_sync_cursor_for(
            identity.user_id, identity.device_id, max(next_cursor, server_cursor)
        )
        return {
            "pushed": pushed,
            "pulled": len(events),
            "cursor": max(next_cursor, server_cursor),
            "events": events,
        }

    @staticmethod
    def _pending_payload(
        row: dict[str, Any], identity: SyncIdentity
    ) -> dict[str, Any]:
        payload = row.get("payload") if isinstance(row.get("payload"), dict) else {}
        return {
            "operation_id": str(row.get("operation_id") or ""),
            "user_id": identity.user_id,
            "device_id": identity.device_id,
            "session_id": identity.session_id,
            "entity_type": str(row.get("entity_type") or ""),
            "entity_id": str(row.get("entity_id") or ""),
            "entity_key": str(row.get("entity_id") or ""),
            "action": str(row.get("action") or "upsert"),
            "operation": str(row.get("action") or "upsert"),
            "branch_id": str(row.get("branch_id") or ""),
            "base_revision": row.get("base_revision"),
            "payload": dict(payload),
        }

    @staticmethod
    def _apply_event(conn, event: dict[str, Any]) -> None:
        entity_type = str(event.get("entity_type") or "").strip().lower()
        if entity_type not in {"tracking", "tracking_item", "tracked_product"}:
            return
        payload = event.get("payload") if isinstance(event.get("payload"), dict) else {}
        entity_id = str(
            event.get("entity_id")
            or event.get("entity_key")
            or payload.get("id")
            or ""
        ).strip()
        branch = str(
            event.get("branch_id")
            or payload.get("branch_id")
            or payload.get("branch")
            or ""
        ).strip()
        action = str(
            event.get("action") or event.get("operation") or "upsert"
        ).strip().lower()
        if not entity_id:
            return
        if action == "delete":
            conn.execute(
                """
                DELETE FROM cloud_tracked_products
                 WHERE id=? OR (
                    json_extract(payload, '$.id')=?
                    AND lower(branch)=lower(?)
                 )
                """,
                (entity_id, entity_id, branch),
            )
            return
        normalized = dict(payload)
        normalized["id"] = entity_id
        normalized["doc_id"] = entity_id
        normalized["branch"] = branch
        normalized["branch_id"] = branch
        normalized["revision"] = int(
            event.get("revision") or payload.get("revision") or 0
        )
        now = time.strftime("%Y-%m-%dT%H:%M:%S")
        conn.execute(
            """
            INSERT OR REPLACE INTO cloud_tracked_products(
                id, branch, material_number, expiry_date, payload, updated_at
            ) VALUES (?, ?, ?, ?, ?, ?)
            """,
            (
                entity_id,
                branch,
                str(normalized.get("material_number") or ""),
                str(normalized.get("expiry_date") or ""),
                json.dumps(normalized, ensure_ascii=False, sort_keys=True),
                now,
            ),
        )
