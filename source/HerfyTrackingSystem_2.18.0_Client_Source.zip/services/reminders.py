from __future__ import annotations

from collections import deque
from dataclasses import dataclass
from datetime import date, datetime, time
from threading import RLock
from typing import Iterable


def normalize_first_reminder_days(value: object) -> int:
    if value is None or value == "":
        return 30
    try:
        parsed = int(value)
    except (TypeError, ValueError):
        return 30
    return min(365, max(1, parsed))


def build_reminder_thresholds(first_reminder_days: object) -> list[int]:
    first = normalize_first_reminder_days(first_reminder_days)
    thresholds = [first]
    if first > 60:
        thresholds.append(60)
    if first > 30:
        thresholds.append(30)
    if first > 14:
        thresholds.append(14)
    if first > 7:
        thresholds.append(7)
    if first > 3:
        thresholds.append(3)
    if first > 1:
        thresholds.append(1)
    thresholds.extend([0, -1])
    return sorted(set(thresholds), reverse=True)


def parse_date_only(value: object) -> date:
    text = str(value or "").strip()
    if not text:
        raise ValueError("expiry date is required")
    return date.fromisoformat(text[:10])


def days_until_expiry(expiry_date: object, *, today: date | None = None) -> int:
    """Date-only calculation; time-of-day and UTC offsets are irrelevant."""
    current = today or datetime.now().astimezone().date()
    return (parse_date_only(expiry_date) - current).days


def threshold_reached(days_left: int, thresholds: Iterable[int]) -> int | None:
    candidates = sorted({int(value) for value in thresholds}, reverse=True)
    if days_left < 0:
        return -1 if -1 in candidates else None
    return days_left if days_left in candidates else None


def branch_is_allowed(
    branch_id: str,
    *,
    scope_branches: Iterable[str] | None,
    all_branches: bool,
) -> bool:
    if bool(all_branches):
        return True
    wanted = str(branch_id or "").strip().casefold()
    allowed = {
        str(branch or "").strip().casefold()
        for branch in scope_branches or ()
        if str(branch or "").strip()
    }
    return bool(wanted and wanted in allowed)


def _parse_clock(value: str, fallback: time) -> time:
    try:
        return time.fromisoformat(str(value or "").strip())
    except ValueError:
        return fallback


def is_quiet_hours(
    *,
    enabled: bool,
    start: str,
    end: str,
    now: datetime | None = None,
) -> bool:
    if not enabled:
        return False
    current = (now or datetime.now().astimezone()).time().replace(tzinfo=None)
    start_time = _parse_clock(start, time(22, 0))
    end_time = _parse_clock(end, time(7, 0))
    if start_time == end_time:
        return True
    if start_time < end_time:
        return start_time <= current < end_time
    return current >= start_time or current < end_time


@dataclass(frozen=True, slots=True)
class ReminderKey:
    user_id: str
    device_id: str
    item_id: str
    branch_id: str
    threshold_days: int
    expiry_date: str


class ToastRateLimiter:
    def __init__(self) -> None:
        self._lock = RLock()
        self._shown: deque[float] = deque()

    def allow(self, max_per_minute: int, *, monotonic_now: float) -> bool:
        limit = min(60, max(1, int(max_per_minute or 3)))
        with self._lock:
            cutoff = monotonic_now - 60.0
            while self._shown and self._shown[0] <= cutoff:
                self._shown.popleft()
            if len(self._shown) >= limit:
                return False
            self._shown.append(monotonic_now)
            return True

    def clear(self) -> None:
        with self._lock:
            self._shown.clear()
