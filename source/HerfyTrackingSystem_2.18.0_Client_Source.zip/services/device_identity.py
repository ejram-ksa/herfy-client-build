from __future__ import annotations

import os
import uuid
from pathlib import Path

from settings.config import app_data_path


def get_or_create_device_id() -> str:
    """Return a stable, non-secret installation identifier."""
    path = Path(app_data_path("device", "device_id.txt"))
    try:
        value = path.read_text(encoding="utf-8").strip()
        if value:
            uuid.UUID(value)
            return value
    except (OSError, ValueError):
        pass
    value = str(uuid.uuid4())
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(value + "\n", encoding="utf-8")
    try:
        os.chmod(path, 0o600)
    except OSError:
        pass
    return value
