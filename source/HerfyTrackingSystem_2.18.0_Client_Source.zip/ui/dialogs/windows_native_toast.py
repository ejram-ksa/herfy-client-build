from __future__ import annotations

import base64
import html
import json
import logging
import subprocess
import sys
from pathlib import Path
from typing import Any
from urllib.parse import urlencode

from settings.config import APP_DESKTOP_APP_ID

logger = logging.getLogger(__name__)


def _powershell_executable() -> str:
    system_root = Path(__import__("os").environ.get("SystemRoot", r"C:\Windows"))
    candidate = system_root / "System32" / "WindowsPowerShell" / "v1.0" / "powershell.exe"
    return str(candidate if candidate.exists() else "powershell.exe")


def _launch_uri(payload: dict[str, Any]) -> str:
    branch = str(payload.get("branch") or payload.get("branch_id") or "").strip()
    item_id = str(
        payload.get("item_id")
        or payload.get("id")
        or payload.get("tracking_id")
        or ""
    ).strip()
    query = urlencode({"branch": branch, "item_id": item_id})
    return "herfy://tracking" + (f"?{query}" if query else "")


class WindowsNativeToast:
    """Best-effort Windows Runtime toast sender.

    No server token or credential is ever passed to PowerShell. The launch
    payload contains only a branch/item navigation hint.
    """

    def __init__(self, main_window: Any) -> None:
        self._main_window = main_window
        self._children: list[subprocess.Popen] = []

    @property
    def available(self) -> bool:
        return sys.platform.startswith("win")

    def show(self, title: str, message: str, payload: dict[str, Any] | None = None) -> bool:
        if not self.available:
            return False
        safe_payload = dict(payload or {})
        launch = _launch_uri(safe_payload)
        title_xml = html.escape(str(title or "Herfy Tracking Reminder"), quote=True)
        message_xml = html.escape(str(message or ""), quote=True)
        launch_xml = html.escape(launch, quote=True)
        app_id = str(APP_DESKTOP_APP_ID or "Herfy.TrackingSystem").replace("'", "''")
        xml = (
            f'<toast activationType="protocol" launch="{launch_xml}">'
            '<visual><binding template="ToastGeneric">'
            f'<text>{title_xml}</text><text>{message_xml}</text>'
            '</binding></visual><audio silent="true"/></toast>'
        )
        xml_ps = xml.replace("'", "''")
        script = f"""
$ErrorActionPreference = 'Stop'
[Windows.UI.Notifications.ToastNotificationManager, Windows.UI.Notifications, ContentType = WindowsRuntime] > $null
[Windows.Data.Xml.Dom.XmlDocument, Windows.Data.Xml.Dom.XmlDocument, ContentType = WindowsRuntime] > $null
$xml = New-Object Windows.Data.Xml.Dom.XmlDocument
$xml.LoadXml('{xml_ps}')
$toast = New-Object Windows.UI.Notifications.ToastNotification $xml
[Windows.UI.Notifications.ToastNotificationManager]::CreateToastNotifier('{app_id}').Show($toast)
"""
        encoded = base64.b64encode(script.encode("utf-16-le")).decode("ascii")
        try:
            creation_flags = int(getattr(subprocess, "CREATE_NO_WINDOW", 0))
            proc = subprocess.Popen(
                [
                    _powershell_executable(),
                    "-NoProfile",
                    "-NonInteractive",
                    "-ExecutionPolicy",
                    "Bypass",
                    "-EncodedCommand",
                    encoded,
                ],
                stdin=subprocess.DEVNULL,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                close_fds=True,
                creationflags=creation_flags,
            )
            self._children = [p for p in self._children if p.poll() is None]
            self._children.append(proc)
            return True
        except (OSError, ValueError):
            logger.exception("Windows native toast launch failed")
            return False

    def close(self) -> None:
        self._children = [p for p in self._children if p.poll() is None]
