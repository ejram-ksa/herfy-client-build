from __future__ import annotations
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .admin_page import AdminDashboardDialog
    from ui.views.home import HomeDashboardPage, HomePage
    from .login_page import LoginPage
    from .settings_page import SettingsDialog, SettingsPage
    from ui.views.tracking_view import TrackingPage
    from .usage_page import UsagePage
__all__ = [
    "AdminDashboardDialog",
    "HomeDashboardPage",
    "HomePage",
    "LoginPage",
    "SettingsDialog",
    "SettingsPage",
    "TrackingPage",
    "UsagePage",
]


def __getattr__(name: str):
    if name == "AdminDashboardDialog":
        from .admin_page import AdminDashboardDialog

        return AdminDashboardDialog
    if name in {"HomeDashboardPage", "HomePage"}:
        from ui.views.home import HomeDashboardPage, HomePage

        return {"HomeDashboardPage": HomeDashboardPage, "HomePage": HomePage}[name]
    if name == "LoginPage":
        from .login_page import LoginPage

        return LoginPage
    if name in {"SettingsDialog", "SettingsPage"}:
        from .settings_page import SettingsDialog, SettingsPage

        return {"SettingsDialog": SettingsDialog, "SettingsPage": SettingsPage}[name]
    if name == "TrackingPage":
        from ui.views.tracking_view import TrackingPage

        return TrackingPage
    if name == "UsagePage":
        from .usage_page import UsagePage

        return UsagePage
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
