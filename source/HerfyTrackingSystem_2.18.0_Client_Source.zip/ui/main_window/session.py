from __future__ import annotations
from ui.main_window.actions import AppLifecycleControllerMixin
from ui.main_window.session_controller import SessionAuthControllerMixin
from ui.main_window.session_controller import SessionRestoreControllerMixin


class MainWindowSessionMixin(
    SessionAuthControllerMixin,
    SessionRestoreControllerMixin,
    AppLifecycleControllerMixin,
):
    pass
