from __future__ import annotations
from typing import Any
from ui.layout.tables import polish_tables
from ui.layout.text import polish_text_visibility


def polish_interface(root: Any, *, window_width: int | None = None) -> None:
    polish_text_visibility(root)
    polish_tables(root, window_width=window_width)
