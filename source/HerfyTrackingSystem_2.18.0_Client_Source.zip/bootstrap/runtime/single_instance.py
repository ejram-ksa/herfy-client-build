from __future__ import annotations
from contextlib import suppress
import hashlib
import json
import logging
from pathlib import Path
import sys
import threading
from dataclasses import dataclass
from typing import Any
from urllib.parse import parse_qs, urlparse
from bootstrap.qt.runtime import qt_timer_class
from settings.config import APP_DESKTOP_APP_ID, runtime_cache_path
from core.errors import UI_OPERATION_EXCEPTIONS, STATE_OPERATION_EXCEPTIONS
from services.window_controller import ActivationCommand, window_controller

logger = logging.getLogger(__name__)
_CONNECT_TIMEOUT_MS = 650
_CONNECT_ATTEMPTS = 8
_CONNECT_DELAY_SECONDS = 0.18
_SOCKET_CLEANUP_MS = 2200


def _foreground_requested(argv: list[str] | tuple[str, ...] | None) -> bool:
    args = list(sys.argv[1:] if argv is None else argv)
    background_flags = {"--tray", "--background"}
    return not any(
        (str(argument).strip().lower() in background_flags for argument in args)
    )


def activation_command_from_argv(
    argv: list[str] | tuple[str, ...] | None,
) -> dict[str, Any] | None:
    for argument in list(sys.argv[1:] if argv is None else argv):
        text = str(argument or "").strip()
        if not text.lower().startswith("herfy://tracking"):
            continue
        parsed = urlparse(text)
        query = parse_qs(parsed.query)
        branch = str((query.get("branch") or [""])[0]).strip()
        item_id = str((query.get("item_id") or [""])[0]).strip()
        return {
            "command": "activate",
            "route": "tracking",
            "tracking_key": {"branch_id": branch, "item_id": item_id},
        }
    return None


@dataclass
class SingleInstanceRuntime:
    lock: Any
    server: Any = None

    @property
    def acquired(self) -> bool:
        return self.lock is not None

    def start_server(self, window: Any) -> Any:
        if self.lock is None:
            return None
        self.server = start_ipc_server(window)
        return self.server

    def cleanup(self, window: Any) -> None:
        cleanup(window, self.lock)


def _qt_local_socket_classes():
    from PyQt5.QtNetwork import QLocalServer, QLocalSocket

    return (QLocalServer, QLocalSocket)


def server_name() -> str:
    try:
        scope = hashlib.sha256(
            str(runtime_cache_path("app.lock")).encode("utf-8", "ignore")
        ).hexdigest()[:12]
    except STATE_OPERATION_EXCEPTIONS:
        scope = "default"
    base = f"{APP_DESKTOP_APP_ID}.{scope}.single-instance"
    return "".join((char if char.isalnum() or char in "._-" else "_" for char in base))


def request_running_instance_reveal(
    *, reveal: bool = True, command: dict[str, Any] | None = None
) -> bool:
    payload = command or {
        "command": "activate" if reveal else "ping",
        "route": None,
        "tracking_key": None,
    }
    command_bytes = (json.dumps(payload, separators=(",", ":")) + "\n").encode("utf-8")
    for attempt in range(_CONNECT_ATTEMPTS):
        socket = None
        try:
            _QLocalServer, QLocalSocket = _qt_local_socket_classes()
            socket = QLocalSocket()
            socket.connectToServer(server_name())
            if not socket.waitForConnected(_CONNECT_TIMEOUT_MS):
                with suppress(UI_OPERATION_EXCEPTIONS):
                    socket.abort()
            else:
                socket.write(command_bytes)
                socket.flush()
                written = bool(socket.waitForBytesWritten(_CONNECT_TIMEOUT_MS))
                acknowledged = bool(socket.waitForReadyRead(_CONNECT_TIMEOUT_MS))
                if acknowledged:
                    try:
                        ack = (
                            bytes(socket.readAll())
                            .decode("utf-8", "ignore")
                            .strip()
                            .upper()
                        )
                        if ack and ack != "OK":
                            logger.debug("Unexpected single-instance ACK: %s", ack)
                    except UI_OPERATION_EXCEPTIONS:
                        logger.debug("Single-instance ACK read failed", exc_info=True)
                with suppress(UI_OPERATION_EXCEPTIONS):
                    socket.disconnectFromServer()
                if written:
                    return True
        except (ModuleNotFoundError, *UI_OPERATION_EXCEPTIONS):
            logger.debug("Unable to notify running instance", exc_info=True)
            return False
        finally:
            if socket is not None:
                with suppress(UI_OPERATION_EXCEPTIONS):
                    socket.close()
                with suppress(UI_OPERATION_EXCEPTIONS):
                    socket.deleteLater()
        if attempt + 1 < _CONNECT_ATTEMPTS:
            threading.Event().wait(_CONNECT_DELAY_SECONDS)
    return False


def _lock_owner_pid(lock: Any) -> int | None:
    try:
        info = lock.getLockInfo()
    except (
        AttributeError,
        TypeError,
        ValueError,
        RuntimeError,
        *UI_OPERATION_EXCEPTIONS,
    ):
        return None
    try:
        if isinstance(info, tuple) and info:
            if len(info) >= 2 and isinstance(info[0], bool):
                return int(info[1]) if info[0] and info[1] else None
            return int(info[0])
        pid = getattr(info, "pid", None)
        return int(pid) if pid else None
    except (TypeError, ValueError):
        return None


def _windows_process_is_alive(pid: int | None) -> bool | None:
    if not sys.platform.startswith("win") or not pid or int(pid) <= 0:
        return None
    try:
        import ctypes
        from ctypes import wintypes

        process_query_limited_information = 4096
        still_active = 259
        kernel32 = ctypes.windll.kernel32
        kernel32.OpenProcess.argtypes = [wintypes.DWORD, wintypes.BOOL, wintypes.DWORD]
        kernel32.OpenProcess.restype = wintypes.HANDLE
        kernel32.GetExitCodeProcess.argtypes = [
            wintypes.HANDLE,
            ctypes.POINTER(wintypes.DWORD),
        ]
        kernel32.GetExitCodeProcess.restype = wintypes.BOOL
        kernel32.CloseHandle.argtypes = [wintypes.HANDLE]
        kernel32.CloseHandle.restype = wintypes.BOOL
        kernel32.GetLastError.argtypes = []
        kernel32.GetLastError.restype = wintypes.DWORD
        handle = kernel32.OpenProcess(
            process_query_limited_information, False, wintypes.DWORD(int(pid))
        )
        if not handle:
            # ERROR_INVALID_PARAMETER is returned when the PID no longer exists.
            # Access denied and other failures are indeterminate and must never
            # authorize removal of a potentially live process lock.
            error_code = int(kernel32.GetLastError())
            return False if error_code == 87 else None
        try:
            exit_code = wintypes.DWORD(0)
            if not kernel32.GetExitCodeProcess(handle, ctypes.byref(exit_code)):
                return None
            return int(exit_code.value) == still_active
        finally:
            kernel32.CloseHandle(handle)
    except (AttributeError, ImportError, OSError, RuntimeError, TypeError, ValueError):
        logger.debug("Unable to inspect single-instance lock owner", exc_info=True)
        return None


def _try_recover_dead_instance_lock(lock: Any) -> bool:
    owner_pid = _lock_owner_pid(lock)
    alive = _windows_process_is_alive(owner_pid)
    if alive is True:
        return False
    if alive is False:
        try:
            if lock.removeStaleLockFile() and lock.tryLock(250):
                logger.info(
                    "Recovered single-instance lock from dead owner process: %s",
                    owner_pid,
                )
                return True
        except UI_OPERATION_EXCEPTIONS:
            logger.debug(
                "Dead single-instance stale-lock API recovery failed", exc_info=True
            )
        try:
            Path(runtime_cache_path("app.lock")).unlink(missing_ok=True)
            if lock.tryLock(250):
                logger.info(
                    "Recovered single-instance lock by removing dead owner lock file: %s",
                    owner_pid,
                )
                return True
        except (OSError, RuntimeError, TypeError, ValueError, *UI_OPERATION_EXCEPTIONS):
            logger.debug(
                "Dead single-instance lock-file recovery failed", exc_info=True
            )
    return False


def _try_reacquire_instance_lock(lock: Any) -> bool:
    try:
        if lock.tryLock(250):
            return True
    except UI_OPERATION_EXCEPTIONS:
        logger.debug("Second instance lock retry failed", exc_info=True)
    return _try_recover_dead_instance_lock(lock)


def _force_windows_foreground(window: Any) -> None:
    if not sys.platform.startswith("win"):
        return
    try:
        import ctypes
        from ctypes import wintypes

        hwnd = wintypes.HWND(int(window.winId()))
        user32 = ctypes.windll.user32
        kernel32 = ctypes.windll.kernel32
        sw_restore = 9
        sw_show = 5
        asfw_any = -1
        user32.ShowWindow.argtypes = [wintypes.HWND, ctypes.c_int]
        user32.ShowWindow.restype = wintypes.BOOL
        user32.BringWindowToTop.argtypes = [wintypes.HWND]
        user32.BringWindowToTop.restype = wintypes.BOOL
        user32.SetActiveWindow.argtypes = [wintypes.HWND]
        user32.SetActiveWindow.restype = wintypes.HWND
        user32.SetForegroundWindow.argtypes = [wintypes.HWND]
        user32.SetForegroundWindow.restype = wintypes.BOOL
        user32.GetForegroundWindow.restype = wintypes.HWND
        user32.GetWindowThreadProcessId.argtypes = [
            wintypes.HWND,
            ctypes.POINTER(wintypes.DWORD),
        ]
        user32.GetWindowThreadProcessId.restype = wintypes.DWORD
        user32.AttachThreadInput.argtypes = [
            wintypes.DWORD,
            wintypes.DWORD,
            wintypes.BOOL,
        ]
        user32.AttachThreadInput.restype = wintypes.BOOL
        kernel32.GetCurrentThreadId.restype = wintypes.DWORD
        if hasattr(user32, "AllowSetForegroundWindow"):
            user32.AllowSetForegroundWindow.argtypes = [wintypes.DWORD]
            user32.AllowSetForegroundWindow.restype = wintypes.BOOL
            with suppress(OSError, RuntimeError, TypeError, ValueError):
                user32.AllowSetForegroundWindow(wintypes.DWORD(asfw_any & 4294967295))
        if hasattr(user32, "IsIconic") and user32.IsIconic(hwnd):
            user32.ShowWindow(hwnd, sw_restore)
        else:
            user32.ShowWindow(hwnd, sw_show)
        try:
            foreground = user32.GetForegroundWindow()
            current_thread = kernel32.GetCurrentThreadId()
            foreground_pid = wintypes.DWORD(0)
            foreground_thread = user32.GetWindowThreadProcessId(
                foreground, ctypes.byref(foreground_pid)
            )
            if foreground_thread and foreground_thread != current_thread:
                attached = bool(
                    user32.AttachThreadInput(current_thread, foreground_thread, True)
                )
                try:
                    user32.BringWindowToTop(hwnd)
                    user32.SetActiveWindow(hwnd)
                    user32.SetForegroundWindow(hwnd)
                finally:
                    if attached:
                        user32.AttachThreadInput(
                            current_thread, foreground_thread, False
                        )
            else:
                user32.BringWindowToTop(hwnd)
                user32.SetActiveWindow(hwnd)
                user32.SetForegroundWindow(hwnd)
        except (AttributeError, OSError, RuntimeError, TypeError, ValueError):
            logger.debug(
                "Windows thread-input foreground activation skipped", exc_info=True
            )
        user32.SetForegroundWindow(hwnd)
    except (AttributeError, ImportError, OSError, RuntimeError, TypeError, ValueError):
        logger.debug("Windows foreground activation fallback failed", exc_info=True)


def reveal_window(window: Any) -> None:
    try:
        window_controller(window).restore()
        _force_windows_foreground(window)
    except UI_OPERATION_EXCEPTIONS:
        logger.exception("Failed to reveal running application instance")


def _parse_activation_payload(payload: str) -> ActivationCommand | None:
    text = str(payload or "").strip()
    if not text:
        return None
    if text.upper() in {"RAISE", "SHOW", "RESTORE", "OPEN"}:
        return ActivationCommand(command="activate")
    if text.upper() == "PING":
        return ActivationCommand(command="ping")
    try:
        data = json.loads(text)
    except json.JSONDecodeError:
        return None
    if not isinstance(data, dict):
        return None
    return ActivationCommand(
        command=str(data.get("command") or "activate"),
        route=str(data.get("route") or "") or None,
        tracking_key=(
            data.get("tracking_key")
            if isinstance(data.get("tracking_key"), dict)
            else None
        ),
    )


def start_ipc_server(window: Any) -> Any:
    try:
        QLocalServer, _QLocalSocket = _qt_local_socket_classes()
        QTimer = qt_timer_class()
        name = server_name()
        with suppress(UI_OPERATION_EXCEPTIONS):
            QLocalServer.removeServer(name)
        server = QLocalServer(window)
        user_access = getattr(QLocalServer, "UserAccessOption", None)
        if user_access is not None and hasattr(server, "setSocketOptions"):
            with suppress(UI_OPERATION_EXCEPTIONS):
                server.setSocketOptions(user_access)

        def _dispose_socket(sock: Any) -> None:
            if bool(getattr(sock, "_herfy_disposed", False)):
                return
            with suppress(UI_OPERATION_EXCEPTIONS):
                setattr(sock, "_herfy_disposed", True)
            with suppress(UI_OPERATION_EXCEPTIONS):
                sock.disconnectFromServer()
            with suppress(UI_OPERATION_EXCEPTIONS):
                sock.close()
            with suppress(UI_OPERATION_EXCEPTIONS):
                sock.deleteLater()

        def _handle_connection() -> None:
            while server.hasPendingConnections():
                socket = server.nextPendingConnection()

                def _read_request(sock=socket) -> None:
                    try:
                        payload = (
                            bytes(sock.readAll()).decode("utf-8", "ignore").strip()
                        )
                        command = _parse_activation_payload(
                            payload.replace("\r", "\n").split("\n", 1)[0]
                        )
                        if (
                            command is not None
                            and command.command
                            in {"activate", "raise", "show", "restore", "open"}
                            and not bool(getattr(window, "_closing_completely", False))
                        ):
                            window_controller(window).restore(command)
                            _force_windows_foreground(window)
                            logger.info("single_instance.activation_received")
                        with suppress(UI_OPERATION_EXCEPTIONS):
                            sock.write(b"OK\n")
                            sock.flush()
                        QTimer.singleShot(60, lambda sock=sock: _dispose_socket(sock))
                    except UI_OPERATION_EXCEPTIONS:
                        logger.debug(
                            "Single-instance request handling failed", exc_info=True
                        )
                        _dispose_socket(sock)

                QTimer.singleShot(
                    _SOCKET_CLEANUP_MS, lambda sock=socket: _dispose_socket(sock)
                )
                socket.readyRead.connect(_read_request)
                if socket.bytesAvailable() > 0:
                    QTimer.singleShot(0, _read_request)

        server.newConnection.connect(_handle_connection)
        if not server.listen(name):
            logger.warning(
                "Single-instance IPC listen failed: %s", server.errorString()
            )
            with suppress(UI_OPERATION_EXCEPTIONS):
                QLocalServer.removeServer(name)
            if not server.listen(name):
                logger.warning(
                    "Single-instance IPC retry failed: %s", server.errorString()
                )
                return None
        setattr(window, "_single_instance_server", server)
        setattr(window, "_single_instance_server_name", name)
        return server
    except (ModuleNotFoundError, *UI_OPERATION_EXCEPTIONS):
        logger.debug("Single-instance IPC server unavailable", exc_info=True)
        return None


def acquire_lock(argv: list[str] | tuple[str, ...] | None = None) -> Any:
    from PyQt5.QtCore import QLockFile

    lock = QLockFile(runtime_cache_path("app.lock"))
    lock.setStaleLockTime(30000)
    if lock.tryLock(1500):
        return lock
    activation = activation_command_from_argv(argv)
    if request_running_instance_reveal(
        reveal=_foreground_requested(argv),
        command=activation,
    ):
        logger.info("Forwarded startup request to the running application instance.")
        return None
    if _try_reacquire_instance_lock(lock):
        logger.info("Recovered startup after stale single-instance handoff.")
        return lock
    logger.info("Application already running; foreground IPC endpoint did not answer.")
    return None


def acquire_runtime(
    argv: list[str] | tuple[str, ...] | None = None,
) -> SingleInstanceRuntime:
    return SingleInstanceRuntime(acquire_lock(argv))


def cleanup(window: Any, lock: Any) -> None:
    if lock is None:
        return
    if bool(getattr(window, "_single_instance_cleaned", False)):
        return
    with suppress(UI_OPERATION_EXCEPTIONS):
        setattr(window, "_single_instance_cleaned", True)
    server = getattr(window, "_single_instance_server", None)
    if server is not None:
        try:
            server.close()
        except UI_OPERATION_EXCEPTIONS:
            logger.exception("Single-instance IPC cleanup failed")
        with suppress(UI_OPERATION_EXCEPTIONS):
            server.deleteLater()
        with suppress(UI_OPERATION_EXCEPTIONS):
            QLocalServer, _QLocalSocket = _qt_local_socket_classes()
            name = getattr(window, "_single_instance_server_name", None)
            QLocalServer.removeServer(name or server_name())
        with suppress(UI_OPERATION_EXCEPTIONS):
            setattr(window, "_single_instance_server", None)
        with suppress(UI_OPERATION_EXCEPTIONS):
            setattr(window, "_single_instance_server_name", None)
    try:
        lock.unlock()
    except UI_OPERATION_EXCEPTIONS:
        logger.exception("Lock cleanup during shutdown failed")
