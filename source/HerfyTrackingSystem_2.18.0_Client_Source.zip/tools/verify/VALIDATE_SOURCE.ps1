$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

$ProjectRoot = (Resolve-Path (Join-Path $PSScriptRoot '..\..')).Path
$Python = if ($env:HERFY_BUILD_PYTHON) { $env:HERFY_BUILD_PYTHON } else { 'python' }
$VersionData = Get-Content -Raw -Encoding UTF8 (Join-Path $ProjectRoot 'version.json') | ConvertFrom-Json
$Version = [string]$VersionData.app_version
if ([string]::IsNullOrWhiteSpace($Version)) { throw 'version.json does not contain app_version.' }

Push-Location $ProjectRoot
try {
    $env:PYTHONDONTWRITEBYTECODE = '1'
    $env:QT_QPA_PLATFORM = 'offscreen'

    $ReportedVersion = & $Python main.py --version
    if ($LASTEXITCODE -ne 0 -or [string]$ReportedVersion.Trim() -ne $Version) {
        throw "main.py --version mismatch. expected=$Version actual=$ReportedVersion"
    }

    $PreviousPycachePrefix = $env:PYTHONPYCACHEPREFIX
    $CompileCache = Join-Path $env:TEMP ('herfy-pycache-' + [Guid]::NewGuid().ToString('N'))
    $env:PYTHONPYCACHEPREFIX = $CompileCache
    try {
        & $Python -m compileall -q .
        if ($LASTEXITCODE -ne 0) { throw 'Python compileall failed.' }
    }
    finally {
        $env:PYTHONPYCACHEPREFIX = $PreviousPycachePrefix
        Remove-Item -LiteralPath $CompileCache -Recurse -Force -ErrorAction SilentlyContinue
    }

    foreach ($Verifier in @(
        'tools\verify\verify_source_hygiene.py',
        'tools\verify\verify_package_boundaries.py',
        'tools\verify\verify_architecture.py',
        'tools\verify\verify_server_authority_contract.py',
        'tools\verify\verify_update_install_contract.py',
        'tools\verify\verify_canonical_paths_and_update.py',
        'tools\verify\verify_deep_runtime_contract.py',
        'tools\verify\verify_runtime_imports.py',
        'tools\verify\verify_pyqt5_runtime_compat.py',
        'tools\verify\verify_tracking_monitoring_notifications_contract.py',
        'tools\verify\verify_usage_import_contract.py',
        'tools\verify\verify_notification_runtime_contract.py',
        'tools\verify\verify_full_source_contract.py'
    )) {
        & $Python $Verifier
        if ($LASTEXITCODE -ne 0) { throw "Validation failed: $Verifier" }
    }

    $QualityTargets = @(
        'main.py', '__main__.py', 'cli.py', 'runtime_health.py',
        'runtime_notification_health.py',
        'runtime_requirements.py', 'updater_agent.py', 'application',
        'bootstrap', 'core', 'data', 'domain', 'presentation', 'remote',
        'tools\verify', 'services', 'settings', 'ui'
    )
    & $Python -m ruff check --no-cache @QualityTargets
    if ($LASTEXITCODE -ne 0) { throw 'Ruff failed.' }
    & $Python -m black --check @QualityTargets
    if ($LASTEXITCODE -ne 0) { throw 'Black failed.' }

    foreach ($Forbidden in @(
        'ui\shell.py', 'ui\shell_cloud.py', 'presentation\logic.py'
    )) {
        if (Test-Path -LiteralPath (Join-Path $ProjectRoot $Forbidden)) {
            throw "Blocked file remains: $Forbidden"
        }
    }

    $VersionedWrappers = @(
        Get-ChildItem -LiteralPath $ProjectRoot -File -Filter '00_BUILD_AND_PUBLISH_*.cmd'
    )
    if ($VersionedWrappers.Count -gt 0) {
        throw "Version-specific build wrappers remain: $($VersionedWrappers.Name -join ', ')"
    }

    Write-Host "HERFY_SOURCE_VALIDATION_OK version=$Version"
}
finally {
    Pop-Location
}
