from __future__ import annotations

import ast
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]


def require(condition: bool, message: str) -> None:
    if not condition:
        raise SystemExit(message)


config = (ROOT / "settings" / "config.py").read_text(encoding="utf-8")
logging_setup = (ROOT / "settings" / "logging_setup.py").read_text(encoding="utf-8")
updater = (ROOT / "updater_agent.py").read_text(encoding="utf-8")
installer = (ROOT / "installer" / "HerfyTrackingSystem.iss").read_text(
    encoding="utf-8"
)
updates = (ROOT / "services" / "updates.py").read_text(encoding="utf-8")
migration = (ROOT / "settings" / "runtime_migration.py").read_text(encoding="utf-8")
version_data = (ROOT / "version.json").read_text(encoding="utf-8")
guard = (ROOT / "installer" / "pyinstaller" / "runtime_path_guard.py").read_text(
    encoding="utf-8"
)

require('os.environ.get("APPDATA")' in config, "Roaming APPDATA is not canonical")
require("LOCALAPPDATA" not in config, "LOCALAPPDATA path drift remains in config")
require(
    "LOCALAPPDATA" not in logging_setup, "LOCALAPPDATA path drift remains in logging"
)
require(
    "migrate_previous_localappdata(target)" in config, "Roaming migration is not called"
)
require(
    'os.environ.get("LOCALAPPDATA")' in migration,
    "Previous LOCALAPPDATA migration source is missing",
)
require(
    '"updates_base_url": "https://herfy.online"' in version_data,
    "Static update host is not canonical",
)
require("_assert_no_source_shadowing" in guard, "Frozen source-shadow guard is missing")
require(
    "DefaultDirName={autopf}\\Herfy Tracking System" in installer,
    "Installer path is not canonical",
)
require(
    "UsePreviousAppDir=yes" in installer,
    "Installer does not preserve the existing path",
)
require("AppMutex=Herfy.TrackingSystem" in installer, "Installer/app mutex is missing")
require(
    "expected_restart = (root / APP_EXE_NAME).resolve()" in updater,
    "Updater restart target is not canonical",
)
require(
    "Restart target must be the existing HerfyTrackingSystem.exe" in updater,
    "Updater permits path drift",
)
require(
    '"/RESTARTAPPLICATIONS"' in updates, "Installer update does not request restart"
)

for py in ROOT.rglob("*.py"):
    ast.parse(py.read_text(encoding="utf-8"), filename=str(py))

print("HERFY_CANONICAL_PATHS_UPDATE_OK")
