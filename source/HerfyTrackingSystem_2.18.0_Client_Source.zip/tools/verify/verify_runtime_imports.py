from __future__ import annotations

import importlib
import os
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
os.environ.setdefault("QT_QPA_PLATFORM", "offscreen")
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

CRITICAL_MODULES = (
    "main",
    "application.ports",
    "bootstrap.runtime.dependency_container",
    "services.sync",
    "ui.main_window",
    "ui.main_window.window",
    "ui.main_window.cloud",
    "ui.views.tracking_support",
    "presentation.updates.update_flow",
)


def main() -> int:
    for name in CRITICAL_MODULES:
        importlib.import_module(name)
    ports = importlib.import_module("application.ports")
    sync = importlib.import_module("services.sync")
    for symbol in (
        "fetch_cloud_snapshot_payload",
        "configure_cloud_runtime",
    ):
        owner = sync if symbol == "fetch_cloud_snapshot_payload" else ports
        if not callable(getattr(owner, symbol, None)):
            raise RuntimeError(f"Missing runtime symbol: {owner.__name__}.{symbol}")
    print(f"HERFY_RUNTIME_IMPORTS_OK modules={len(CRITICAL_MODULES)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
