from __future__ import annotations

import ast
import hashlib
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]

SERVER_IMPORTS = {
    "alembic",
    "asyncpg",
    "fastapi",
    "gunicorn",
    "psycopg",
    "psycopg2",
    "psycopg_pool",
    "sqlalchemy",
    "uvicorn",
}
SERVER_PATH_PARTS = {
    "migrations",
    "scripts/deploy",
    "systemd",
}
SERVER_FILENAMES = {
    "run_server.py",
    "schema.sql",
    "seed.py",
    "stored_products.csv",
    "usage_products.csv",
}
SERVER_SUFFIXES = {".service", ".iss-server"}


def imported_roots(path: Path) -> set[str]:
    tree = ast.parse(path.read_text(encoding="utf-8-sig"), filename=str(path))
    roots: set[str] = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            roots.update(alias.name.split(".", 1)[0] for alias in node.names)
        elif isinstance(node, ast.ImportFrom) and node.module:
            roots.add(node.module.split(".", 1)[0])
    return roots


def main() -> int:
    errors: list[str] = []

    for path in sorted(ROOT.rglob("*")):
        if not path.is_file():
            continue
        relative = path.relative_to(ROOT)
        normalized = relative.as_posix().lower()

        if path.name.lower() in SERVER_FILENAMES:
            errors.append(f"server file in client package: {relative}")
        if path.suffix.lower() in SERVER_SUFFIXES:
            errors.append(f"server artifact in client package: {relative}")
        if any(part in normalized for part in SERVER_PATH_PARTS):
            errors.append(f"server path in client package: {relative}")

        if path.suffix.lower() == ".py":
            forbidden = sorted(imported_roots(path) & SERVER_IMPORTS)
            if forbidden:
                errors.append(
                    f"server imports in {relative}: {', '.join(forbidden)}"
                )

    manifest_path = ROOT / "MANIFEST.sha256.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    entries = manifest.get("files")
    if not isinstance(entries, list):
        errors.append("invalid MANIFEST.sha256.json")
        entries = []

    expected: dict[str, tuple[str, int]] = {}
    for entry in entries:
        relative = str(entry.get("path") or "")
        digest = str(entry.get("sha256") or "")
        size = int(entry.get("size") or 0)
        if not relative or relative in expected:
            errors.append(f"invalid manifest path: {relative!r}")
            continue
        expected[relative] = (digest, size)

    actual = {
        path.relative_to(ROOT).as_posix()
        for path in ROOT.rglob("*")
        if path.is_file() and path != manifest_path
    }
    if actual != set(expected):
        errors.append(
            "manifest file-set mismatch: "
            f"missing={sorted(set(expected) - actual)} "
            f"unexpected={sorted(actual - set(expected))}"
        )
    else:
        for relative, (digest, size) in expected.items():
            payload = (ROOT / relative).read_bytes()
            if hashlib.sha256(payload).hexdigest() != digest or len(payload) != size:
                errors.append(f"manifest mismatch: {relative}")

    requirements = (ROOT / "requirements.txt").read_text(encoding="utf-8").lower()
    for package_name in sorted(SERVER_IMPORTS):
        if package_name.lower() in requirements:
            errors.append(f"server dependency in requirements.txt: {package_name}")

    if errors:
        raise SystemExit("\n".join(errors))

    print("CLIENT_PACKAGE_BOUNDARY_OK")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
