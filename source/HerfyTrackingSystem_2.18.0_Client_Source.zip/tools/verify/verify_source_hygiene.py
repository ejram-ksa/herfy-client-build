from __future__ import annotations

import re
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
ALLOWED_TOP_LEVEL = {
    "__main__.py", "application", "bootstrap", "cli.py", "core", "data",
    "domain", "installer", "main.py", "presentation", "pyproject.toml",
    "remote", "requirements-build.txt", "requirements.txt", "resources",
    "runtime_health.py", "runtime_notification_health.py", "runtime_requirements.py",
    "services", "settings", "tools", "ui", "updater_agent.py", "version.json",
    "client-update-manifest.json", "MANIFEST.sha256.json",
}
FORBIDDEN_DIRS = {
    "__pycache__",
    ".ruff_cache",
    ".pytest_cache",
    ".mypy_cache",
    ".venv",
    "venv",
    "build",
    "dist",
    "publish",
    "output",
}
FORBIDDEN_SUFFIXES = {".pyc", ".pyo", ".log", ".tmp", ".bak"}
VERSIONED_RELEASE_FILENAME = re.compile(r"(?:^|[_-])\d+[._]\d+[._]\d+(?:[._-]|$)")
SECRET_PATTERNS = (
    re.compile(r"BEGIN (?:OPENSSH|RSA|EC) PRIVATE KEY", re.I),
    re.compile(
        r"(?i)(?:password|passwd|secret)\s*[=:]\s*['\"]?(?:123456|18016|2614|29429|Hus-)"
    ),
)


def main() -> int:
    errors: list[str] = []
    actual = {path.name for path in ROOT.iterdir()}
    unexpected = sorted(actual - ALLOWED_TOP_LEVEL)
    missing = sorted(ALLOWED_TOP_LEVEL - actual)
    if unexpected:
        errors.append(f"unexpected top-level entries: {unexpected}")
    if missing:
        errors.append(f"missing top-level entries: {missing}")

    for path in ROOT.rglob("*"):
        relative = path.relative_to(ROOT)
        if path.is_dir() and path.name in FORBIDDEN_DIRS:
            if str(relative).replace("\\", "/") != "tools/build":
                errors.append(f"forbidden directory: {relative}")
        if path.is_file() and path.suffix.lower() in FORBIDDEN_SUFFIXES:
            errors.append(f"forbidden artifact: {relative}")
        if path.is_file() and VERSIONED_RELEASE_FILENAME.search(path.name):
            errors.append(f"versioned release filename: {relative}")
        if path.is_file() and path.suffix.lower() in {
            ".py",
            ".ps1",
            ".cmd",
            ".iss",
            ".json",
            ".txt",
            ".toml",
        }:
            try:
                text = path.read_text(encoding="utf-8")
            except UnicodeDecodeError:
                continue
            for pattern in SECRET_PATTERNS:
                if pattern.search(text):
                    errors.append(f"possible embedded credential: {relative}")
                    break

    if errors:
        raise RuntimeError("HERFY_SOURCE_HYGIENE_FAILED\n - " + "\n - ".join(errors))
    print("HERFY_SOURCE_HYGIENE_OK")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
