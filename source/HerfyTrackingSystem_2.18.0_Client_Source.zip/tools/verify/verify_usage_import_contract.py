from __future__ import annotations

import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[2]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

from openpyxl import Workbook

from services.import_excel import parse_begining, parse_receipts_uom_from_colD
from services.usage_service import UsageService


MATERIAL = "1110000023"


class _UsageDatabase:
    def __init__(self) -> None:
        self.uom_updates: list[dict[str, str]] = []

    def refresh_usage_products_from_server(
        self, *, force_refresh: bool = False
    ) -> list[dict[str, str]]:
        assert force_refresh is True
        return [
            {
                "material": MATERIAL,
                "name": "Balloon Printed",
                "uom": "",
            }
        ]

    def fetch_usage_products(self) -> list[dict[str, str]]:
        return []

    def update_usage_uom_bulk(self, uom_map: dict[str, str]) -> None:
        self.uom_updates.append(dict(uom_map))


def _write_receipts(path: Path) -> None:
    workbook = Workbook()
    worksheet = workbook.active
    worksheet.append(["Material Number", "Description", "Receipts", "UOM"])
    worksheet.append([MATERIAL, "Balloon Printed", 5, "PCS"])
    workbook.save(path)
    workbook.close()


def _write_beginning(path: Path) -> None:
    workbook = Workbook()
    worksheet = workbook.active
    worksheet.append(["Material Number", "Description", "Beginning"])
    worksheet.append([MATERIAL, "Balloon Printed", 10])
    workbook.save(path)
    workbook.close()


def main() -> int:
    with tempfile.TemporaryDirectory(prefix="herfy-usage-contract-") as temp:
        root = Path(temp)
        receipts_path = root / "receipts.xlsx"
        beginning_path = root / "beginning.xlsx"
        _write_receipts(receipts_path)
        _write_beginning(beginning_path)

        receipts, uom_map = parse_receipts_uom_from_colD(str(receipts_path))
        beginning = parse_begining(str(beginning_path))

        assert receipts[MATERIAL]["uom"] == "PCS"
        assert receipts[MATERIAL]["receipts"] == 5.0
        assert uom_map == {MATERIAL: "PCS"}
        assert beginning[MATERIAL]["qty"] == 10.0
        assert "uom" not in beginning[MATERIAL]

        database = _UsageDatabase()
        rows = UsageService(database).compute_rows(
            str(receipts_path),
            str(beginning_path),
        )
        assert len(rows) == 1
        row = rows[0]
        assert row["material"] == MATERIAL
        assert row["uom"] == "PCS"
        assert row["receipts"] == 5.0
        assert row["begin"] == 10.0
        assert row["total"] == 15.0
        assert database.uom_updates == [{MATERIAL: "PCS"}]

    print("USAGE_IMPORT_CONTRACT_OK source=receipts beginning=uom-independent")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
