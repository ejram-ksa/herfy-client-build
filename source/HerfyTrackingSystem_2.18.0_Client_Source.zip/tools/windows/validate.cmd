@echo off
setlocal
cd /d "%~dp0\..\.."
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%CD%\tools\verify\VALIDATE_SOURCE.ps1"
exit /b %ERRORLEVEL%
